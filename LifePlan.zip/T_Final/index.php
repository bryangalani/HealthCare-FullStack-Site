<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css" >

    <!-- Meu estilo CSS-->
    <link rel = "stylesheet" href="myStyle/css/myPersonalStyles.css">

    <!-- Font-awesome -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">

    <!-- Meu Javascript -->
    <script src="myJavascript/myInteractions.js"></script>
    
    <title>LifePlan</title>
  </head>
  <body>

  
    <!--Php-->
    <?php
                    include 'myPhp/functions.php';
                    session_start();

                    if($_SESSION['statusLogado'] == ""){
                        $_SESSION['statusLogado'] = "Visitante";
                    }
                    

                    if($_SERVER["REQUEST_METHOD"] == "POST"){
                        $xmlFile = simplexml_load_file("./bancoDados/dadosLogin.xml") or die("Erro!");
                    
                        if($xmlFile == false){
                            echo "Falha ao carregar o Xml: ";
                            foreach(libxml_get_errors() as $error){
                                echo "<br>" . $error->message;
                            }
                        }

                        $administradores = $xmlFile->children()[0];
                        $medicos = $xmlFile->children()[1];
                        $laboratorios  =$xmlFile->children()[2];
                        $pacientes = $xmlFile->children()[3];

                        $senhaLogin = $emailLogin = "";

                        $emailLogin = test_input($_POST["emailLoginMod"]);
                        $senhaLogin = test_input($_POST["senhaLoginMod"]);
                        
                        for($index = 0; $index <=3 ; $index++){
                            switch($index){
                                case 0: //adm
                                    foreach($administradores->children() as $adm){ 
                                        if($adm->email == $emailLogin && $adm->senha == $senhaLogin){
            
                                            $_SESSION['statusLogado'] = "Administrador";
                                            $_SESSION['profile'] = "profileAdm.php";
                                            $index = 5; //quebra loop
                                            break;
                                        }
                                    }
                                    break;
                                case 1: //med
                                    foreach($medicos->children() as $med){ 
                                        
                                        if($med->email == $emailLogin && $med->senha == $senhaLogin){
            
                                            $_SESSION['statusLogado'] = "Médico";
                                            $_SESSION['profile'] = "profileMed.php";
                                            $index = 5; //quebra loop
                                            break;
                                        }
                                    }
                                    break;
                                case 2: //lab
                                    foreach($laboratorios->children() as $lab){ 
                                        
                                        if($lab->email == $emailLogin && $lab->senha == $senhaLogin){
            
                                            $_SESSION['statusLogado'] = "Laboratorio";
                                            $_SESSION['profile'] = "profileLab.php";
                                            $index = 5; //quebra loop
                                            break;
                                        }
                                    }
                                    break;
                                case 3: //paciente
                                    foreach($pacientes->children() as $pac){ 
                                        
                                        if($pac->email == $emailLogin && $pac->senha == $senhaLogin){
                                            $_SESSION['statusLogado'] = "Paciente";
                                            $_SESSION['profile'] = "profilePac.php";
                                            break;
                                        }else{
                                            $_SESSION['statusLogado'] = "Visitante";
                                            $_SESSION['profile'] = "signUp.php";
                                        }
                                    }
                            }
                        }

                        $_SESSION['emailLogado'] = $emailLogin;
                    }

                    if($_SESSION['statusLogado'] != "Visitante"){
                        $botaoSair = '<button type="button" id="botaoSair"class="btn btn-danger" style="width:75px;" onclick="logOut()">Sair</button>';
                    }else{
                        $botaoSair = "";
                        $_SESSION['emailLogado'] = "";
                    }

                    if($_SESSION['statusLogado'] == "Administrador"){
                        $_SESSION['profile'] = "profileAdm.php";
                    }else if($_SESSION['statusLogado'] == "Médico"){
                        $_SESSION['profile'] = "profileMed.php";
                    }else if($_SESSION['statusLogado'] == "Laboratorio"){
                        $_SESSION['profile'] = "profileLab.php";
                    }else if($_SESSION['statusLogado'] == "Paciente"){
                        $_SESSION['profile'] = "profilePac.php";
                    }else{
                        $_SESSION['profile'] = "signUp.php";
                    }

                ?>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-success" id="home">

<div class="container">

    <a class="navbar-brand h1 mb-0" href="index.php"><i class="fa fa-heartbeat text-ligth" aria-hidden="true"></i> LifePlan</a>

    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSite">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="system.php">Sistema</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="plans.php">Planos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="index.php#faleConosco">Fale conosco</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="imp.php">Imprensa</a>
            </li>
        </ul>

        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">

                <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="navDrop" >
                    Social
                </a>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="https://www.facebook.com/">Facebook</a>
                    <a class="dropdown-item" href="https://www.instagram.com/">Instagram</a>
                    <a class="dropdown-item" href="https://twitter.com/">Twitter</a>
                </div>
            </li>
           

            <li class="nav-item mr-4">
                <a type="button" class="nav-link" href="<?php echo $_SESSION['profile']?>"> Perfil <?php echo $_SESSION['statusLogado']?></a>
            </li>
        </ul>

        <form class="form-inline">                    
            <button type="button" class="btn btn-light" data-toggle="modal" data-target="#siteModal">Login</button>
        </form>

    </div>
</div>
</nav>

    <!-- Carousel -->
    <div id="carouselSite" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
            <li data-target="#carouselSite" data-slide-to="1"></li>
            <li data-target="#carouselSite" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/carousel_01.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_02.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_03.jpg" class="img-fluid d-block w
                -100">
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Posterior</span>
        </a>

    </div>

    
    
    <!-- Conteudo -->
    <div class="container">

        <div class="row">

            <div class="col-12 text-center mt-5">
                <h1 class="display-4"> <i class="fa fa-plus-square text-success" aria-hidden="true"></i> A LifePlan</h1>
                <p>Vá além dos horizontes</p>
            </div>

        </div>


        <!-- ScrollSpy -->
        <div class="row mb-5">

            <div class="col-sm-6 col-md-4 mb-3">

                <nav id="navbarVertical" class="navbar navbar-light  bg-light">
                    <nav class="nav nav-pills flex-column ">
                        
                        <a class="nav-link" href="#item1">A LifePlan</a>
                        
                        <nav class="nav nav-pills flex-column">

                            <a class="nav-link ml-3" href="#item1-1">Pacientes</a>
                            
                            <a class="nav-link ml-3" href="#item1-2">Médicos e Laboratórios</a>

                        </nav>

                        <a class="nav-link mt-2" href="#item2">Parcerias</a>

                        <a class="nav-link mt-2" href="#item3">Dúvidas Frequentes</a>
                        <nav class="nav nav-pills flex-column">

                            <a class="nav-link ml-3" href="#item3-1">Quem pode se associar?</a>
                            
                            <a class="nav-link ml-3" href="#item3-2">Posso cancelar a qualquer momento?</a>

                        </nav>

                    </nav>

                </nav>

            </div>

            <div class="col-sm-6 col-md-8 ">

                <div data-spy="scroll" data-target="#navbarVertical" data-offset="0" class="myscrollspySite">
                    
                    <h4 id="item1">A LifePlan</h4>
                    <p>A LifePlan surgiu com o intuito de proporcionar um sistema de plano de saúde para você e sua familia através de planos familiares e individuais, que vão desde os econômicos até os planos premium. A LifePlan possui um suporte direto ao cliente via Site, proporcionando a visualização de todas suas consultas e exames médico. Além disso a com a afiliação LifePlan você recebe diversos cupons de desconto em tratamentos variados como Acupuntura, Homeopatia, entre outros. Não fique fora dessa, entre em contato conosco agora mesmo!</p>

                    <h5 id="item1-1">Paciente</h5>
                    <p>Se você deseja fazer parte como um Paciente, entre em contato conosco agora mesmo através do formulário disponível nesta pagina. Pacientes tem acesso completo online a todos seus exames e consultas, desta forma nenhum paciente percisa ir até o laboratório para visualizarseu resultado. Todos pacientes, recebem muitas vantagens ao participar do LifePlan recebendo descontos especiais em diversos serviços. </p>

                    <h5 id="item1-2">Médicos e Laboratórios</h5>
                    <p>O cadastro de Médicos e Laboratórios filiados a LifePlan devem ser feitos diretamente pelo formulário. Assim que avaliarmos os dados entraremos em contato com maiores informações. Associa seu consultório ou seu laboratório agora mesmo e receba um banco de pacientes que poderam frequentar seu espaço de trabalho. </p>

                    <h4 id="item2">Parcerias</h4>
                    <p>A LifePlan possui parcerias com diversos consultórios, trazendo novidades na area de saúde. Todo mês trazemos 3 tipos de tratamentos opicionais a nossos clientes, além de descontos e materiais informativos. Se você deseja ser um parceiro LifePlan, entre em contato agora mesmo.</p>

                    <h4 id="item3">Dúvidas Frequentes</h4>
                    <p>Apresentamos dois tópicos perguntados frequentemente. Se você possui mais duvidas, entre em contato pelo formulário ou por nossas redes sociais, te responderemos em até 48 horas. Não perca tempo, entre em contato conosco o mais rapido possivel e tiraremos todas as suas dúvidas.</p>

                    <h5 id="item3-1">Quem pode se associar?</h5>
                    <p>Todos podem se associar, sejam pacientes em busca de planos individuais ou familiares. Médicos ou Laboratórios que desejam fazer parte da LifePlan, ou até mesmo consultórios que buscam parcerias para divulgação e desenvolvimento.</p>

                    <h5 id="item3-2">Posso cancelar a qualquer momento?</h5>
                    <p>Sim, qualquer de nossos planos podem ser cancelados a qualquer momentos por parcientes, sem nenhum custo adicional. Realizamos a cobrança automaticamente, todo dia 10, para realziar o cancelamento deve-se pedir o desligamento até o dia 5 para o cancelamento do mês posterior e não atual.</p>

                </div>

            </div>
        </div>

        <!-- Cards -->
        <div class="row justify-content-sm-center">

            <div class="col-sm-6 col-md-4">

                <div class="card mb-3">

                    <img class="card-img-top" src="images/card_01.jpg" alt="">

                    <div class="card-body" style="text-align: justify;">
                        <h4 class="card-title">Ervas Medicinais</h4>
                        <h6 class="card-subtitle mb-2 text-muted">Cura ou tratamento de várias doenças</h6>
                        <p class="card-text">As substâncias encontradas nas plantas que permitem a cura ou tratamento de doenças variam de espécie para espécie e normalmente estão relacionadas com a defesa da planta e com a atração de polinizadores. Essas substâncias, quando possuem ação farmacológica, dão à planta a classificação de medicinal.</p> 
                    <!-- 
                    </div>
                    
                    <div class="list-group list-group-flush">
                        <a href="#" class="list-group-item list-group-item-action">Boldo</a>
                        <a href="#" class="list-group-item list-group-item-action">Hortelã</a>
                    </div>

                  
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">Boldo</li>
                        <li class="list-group-item">Hortelã</li>
                    </ul>
                    
                    <div class="card-body">
                    -->
                       <a class="card-link" href="https://saude.abril.com.br/bem-estar/conheca-e-saiba-usar-37-plantas-medicinais/">Veja Saúde</a>
                        <a class="card-link" href="https://mundoeducacao.uol.com.br/saude-bem-estar/plantas-medicinais.htm">Mundo Educação</a>
                    </div> 
              

                </div>
            </div>
            <div class="col-sm-6 col-md-4 ">

                <div class="card mb-3">
                    <img class="card-img-top" src="images/card_02.jpg" alt="">

                    <div class="card-body "style="text-align: justify;">
                        <h4 class="card-title">Homeopatia</h4>
                        <h6 class="card-subtitle mb-2 text-muted">Terapia alternativa pseudocientífica</h6>
                        <p class="card-text"> A terapia, diz que o homem, além do corpo físico, também tem um princípio vital. O tratamento homeopático utiliza o princípio de que o “semelhante cura semelhante”.  Isso quer dizer que as mesmas substâncias que causam os sintomas  podem, também,  ser utilizadas para o tratamento ou  alívio de vários tipos de doenças.</p> 
                        <a class="card-link" href="https://www.uol.com.br/vivabem/noticias/redacao/2020/02/10/homeopatia-ainda-divide-opinioes-sobre-sua-eficacia-mas-e-aceita-no-brasil.htm">Uol</a>
                        <a class="card-link" href="https://homeopatiabrasil.com.br/o-que-e-homeopatia-e-para-que-serve/">Homeopatia Brasil</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-4 mb-3">

                <div class="card mb-3">

                    <img class="card-img-top" src="images/card_03.jpg" alt="">
                    <div class="card-body" style="text-align: justify;">
                        <h4 class="card-title">Acupuntura</h4>
                        <h6 class="card-subtitle mb-2 text-muted">Medicina tradicional chinesa</h6>
                        <p class="card-text">A medicina chinesa acredita que as doenças são resultado do desequilíbrio dos canais de energia do organismo, e a acupuntura atua de forma a fazer o ajuste de yin e yang. A medicina ocidental, acredita que os efeitos acontecem devido à estimulação de substâncias que atuam por todo o organismo. </p> 
                        <a class="card-link" href="https://medprev.online/blog/beneficios-da-acupuntura.html">Med Prev</a>
                        <a class="card-link" href="https://www.center-ao.com.br/tudo-sobre-acupuntura/o-que-e-acupuntura/">Center AO</a>
                    </div>
                    <div class="card-footer text-muted">
                        20% de Desconto!
                    </div>

                </div>
            </div>
        </div>

    </div>

    <!-- Jumbotron-->
    <div class="jumbotron jumbotron-fluid">

        <div class="container">
            <div class="row">
                <div class="col-12 text-center">

                    <h1 class="display-4"><i class="fa fa-youtube-play text-success" aria-hidden="true"></i>Atualidades</h1>
                    <p class="lead">Covid-19</p>
                    <hr>

                </div>
            </div>

            <div class="row">

                <div class="col-12">
                    <ul class="nav nav-pills justify-content-center mb-3" id="pills-nav" role="tablist">

                        <li class="nav-item">
                            <a class="nav-link active" id="nav-pills-01" data-toggle="pill" href="#nav-item-01">Sintomas</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" id="nav-pills-02" data-toggle="pill" href="#nav-item-02">Orientações</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="nav-pills-03" data-toggle="pill" href="#nav-item-03">Tratamento</a>
                        </li>

                    </ul>

                    <div class="tab-content" id="nav-pills-content">

                        <div class="tab-pane fade show active" id="nav-item-01" role="tabpanel">

                            <div class="row">
                                <div class="col-sm-6">

                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/5irurU8AWac" frameborder="0"></iframe>

                                    </div>

                                </div>

                                <div class="col-sm-6">
                                   <p>Em geral, uma pessoa que tem alguma condição que às vezes provoca falta de ar conhece as características do que sente. Outra dica para diferenciar a covid-19 de outras doenças que causam dificuldade para respirar é observar os sintomas associados.</p>
                                </div>

                            </div>

                        </div>

                        <div class="tab-pane fade" id="nav-item-02" role="tabpanel">

                            <div class="row">
                                <div class="col-sm-6">

                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/9loHh2xjSRw" frameborder="0"></iframe>

                                    </div>

                                </div>

                                <div class="col-sm-6">
                                   <p>Com a rapidez da disseminação do novo coronavírus, é importante entender que as informações sobre a pandemia podem mudar em dias ou semanas.</p>
                                </div>

                            </div>

                        </div>

                        <div class="tab-pane fade" id="nav-item-03" role="tabpanel">

                            <div class="row">
                                <div class="col-sm-6">

                                    <div class="embed-responsive embed-responsive-16by9">
                                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/mizw0iFR8IQ" frameborder="0"></iframe>

                                    </div>

                                </div>

                                <div class="col-sm-6">
                                   <p>Apesar de não possuir tratamento específico, o controle dos sintomas é essencial para que não haja complicações graves por conta de infecção pelo novo coronavírus.</p>
                                </div>

                            </div>

                        </div>


                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- Formulario -->
    <div class="container">

        <div class="row">

            <div class="col-12 text-center my-5">
                <h1 class="display-4"><i class="fa fa-paper-plane text-success" aria-hidden="true" id="faleConosco"></i> Fale conosco</h1>
                <p class="lead">Envie sua mensagem</p>
                <hr>

            </div> 
            
        </div>

        <div class="row justify-content-center mb-5">

            <div class="col-sm-12 col-md-10 col-lg-8">

                <form>

                    <div class="form-row">

                        <div class="form-group col-sm-6">

                            <label for="inputNome">Nome:</label>
                            <input type="text" class="form-control" id="inputNome" placeholder="Digite aqui seu nome...">

                        </div>

                        <div class="form-group col-sm-6">

                            <label for="inputSobrenome">Sobrenome</label>
                            <input type="text" class="form-control" id="inputSobrenome" placeholder="Digite aqui seu sobrenome...">

                        </div>

                    </div>
                    <div class="form-row">

                        <div class="form-group col-sm-12">

                            <label for="inputEnd">Endereço</label>
                            <input type="text" class="form-control" id="inputEnd" placeholder="Digite aqui seu endereço...">

                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-sm-6">

                            <label for="inputCid">Cidade</label>
                            <input type="text" id="inputCid" class="form-control" placeholder="Digite aqui sua cidade...">

                        </div>

                        <div class="form-group col-sm-4">

                            <label for="inputEst">Estado</label>
                            <select id="inputEst" class="form-control">
                                <option selected>Escolha...</option>
                                <option value="AC">Acre</option>
                                <option value="AL">Alagoas</option>
                                <option value="AP">Amapá</option>
                                <option value="AM">Amazonas</option>
                                <option value="BA">Bahia</option>
                                <option value="CE">Ceará</option>
                                <option value="DF">Distrito Federal</option>
                                <option value="ES">Espírito Santo</option>
                                <option value="GO">Goiás</option>
                                <option value="MA">Maranhão</option>
                                <option value="MT">Mato Grosso</option>
                                <option value="MS">Mato Grosso do Sul</option>
                                <option value="MG">Minas Gerais</option>
                                <option value="PA">Pará</option>
                                <option value="PB">Paraíba</option>
                                <option value="PR">Paraná</option>
                                <option value="PE">Pernambuco</option>
                                <option value="PI">Piauí</option>
                                <option value="RJ">Rio de Janeiro</option>
                                <option value="RN">Rio Grande do Norte</option>
                                <option value="RS">Rio Grande do Sul</option>
                                <option value="RO">Rondônia</option>
                                <option value="RR">Roraima</option>
                                <option value="SC">Santa Catarina</option>
                                <option value="SP">São Paulo</option>
                                <option value="SE">Sergipe</option>
                                <option value="TO">Tocantins</option>
                            </select>

                        </div>

                        <div class="form-group col-sm-2">

                            <label for="inputCep">CEP</label>
                            <input type="text" id="inputCep" placeholder="Digite aqui..." class="form-control">

                        </div>

                    </div>

                    <div class="form-row">

                        <div class="form-group col-sm-12">
                            <label for="InputEmail1">Email</label>
                            <input type="email" class="form-control" id="InputEmail1" aria-describedby="emailHelp" placeholder="Digite aqui seu email...">
                            <small id="emailHelp" class="form-text text-muted">Nós nunca compartilharemos seu e-mail.</small>
                          </div>
                        
                    </div>

                    <div class="form-row">

                        <div class="form-group col-sm-12">

                            <div class="form-check">

                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox"> Desejo receber novidades por e-mail
                                </label>

                            </div>
                            
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-sm-12">
                            <label for="textAreaMsg">Digite sua mensagem</label>
                            <textarea class="form-control" id="textAreaMsg" rows="3" placeholder="Digite aqui sua mensagem..."></textarea>
                        </div>
                    </div>



                    <div class="form-row justify-content-center">
                        <div class="form-group">
                            <button type="submit" class="btn btn-success" data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie seu formulario para analise">
                                Enviar
                            </button>
                        </div>

                    </div>


                </form>


            </div>

        </div>




<!-- Footer -->
<div class="container">
        <div class="row mb-5">

            <div class="col-12 mb-3"><hr></div>

            <div class="col-sm-4" style="text-align: justify;">

                <h3>A LifePlan</h3>
                <p>Plano de saúde familiar e individual</p>
                <p>A LifePlan foi fundada em 2020 por 2 estudantes de engenharia da computação, Bryan Galani e Frederico Bender. A LifePlan visa proporcionar o plano de saúde ideal para voçe e sua familia, além de auxiliar o contato entre médico e paciente. Utilize nosso site para realizar consultas e exames. </p>

            </div>
            <div class="col-sm-4">
                <h3>Menu</h3>
                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="system.php">Sistema</a>

                    <a class="list-group-item list-group-item-action" href="plans.php">Planos</a>

                    <a class="list-group-item list-group-item-action" href="index.php#faleConosco">Fale Conosco</a>

                    <a class="list-group-item list-group-item-action" href="imp.php">Imprensa</a>
                </div>

            </div>
            <div class="col-sm-4">

                <h3>Social</h3>

                <div class="btn-group-vertical btn-block btn-group-lg" role="group">
                    <a class="btn btn-outline-success"  href="https://www.facebook.com/"><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>

                    <a class="btn btn-outline-success" href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a>

                    <a class="btn btn-outline-success" href="https://twitter.com/"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
                </div>


            </div>

            <div class="col-12 mt-5">

                <blockquote class="blockquote text-center">

                    <p class="mb-0">"Nada pior para a saúde que viver de aparências e fachadas. São pessoas com muito verniz e pouca raiz. Seu destino é a farmácia, o hospital, a dor."</p>
                    <footer class="blockquote-footer">Drauzio Varella <cite title="Source title">Médico, Cientista e Escritor</cite></footer>

                </blockquote>

            </div>

        </div>
    
    </div>




    <!-- Modal -->
    <div class="modal fade" id="siteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            

                <div class="modal-header">
                        <h4 class="modal-title w-100 text-center" >Login</h4>

                        <button type="button" class="close text-end" data-dismiss="modal" style="position: absolute; right: 15px;">
                            <span> &times; </span>
                        </button>    
                </div>

                <div class="modal-body">
                    
                   <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                        <div class="form-group mt-2">
                            <label for="emailLogin"><i class="fa fa-at" aria-hidden="true"></i> Email</label>
                            <input type="email" class="form-control" id="emailLogin" name="emailLoginMod" placeholder="Email">
                        </div>
                        <div class="form-group my-3">
                            <label for="senhaLogin"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Senha</label>
                            <input type="password" class="form-control" id="senhaLogin" name="senhaLoginMod"placeholder="Senha">
                        </div>

                        <div class="form-group text-center mb-2">
                            <button type="submit" class="btn btn-success " style="width:75px;">Entrar</button>
                            <?php echo $botaoSair?>

                        </div>
                        <input type="submit" style="visibility: hidden; width: 0px; height:0px; text-align:right; position:absolute;" id="hiddenSubmit">

                        <script>
                            function logOut(){
                                document.getElementById("emailLogin").value = '';
                                document.getElementById("senhaLogin").value = '';
                                document.getElementById("hiddenSubmit").click();
                            }   
                        </script>
                        <div class="form-group my-2">
                            <h5 class="text-center"> Status: <?php echo $_SESSION['statusLogado']?></h5>
                        </div>
                        
                       
                   </form>

                

                </div>

                <div class="modal-footer">

                    
                    <a href="signUp.php" class="btn btn-success" type="button" role="button">Cadastrar</a>

                    
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>

                </div>

            </div>
        </div>
    </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>

    <script>

        $(function () {

            $('[data-toggle="popover"]').popover()

        })

    </script>


  </body>
</html>