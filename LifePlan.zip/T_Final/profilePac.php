<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css" >

    <!-- Meu estilo CSS-->
    <link rel = "stylesheet" href="myStyle/css/myPersonalStyles.css">

    <!-- Font-awesome -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">

    <!-- Meu Javascript -->
    <script src="myJavascript/myInteractions.js"></script>
    
    <title>LifePlan</title>
  </head>
  <body>

  <!-- PHP -->
  <?php
        include 'myPhp/functions.php';
        session_start();

        if($_SESSION['statusLogado'] != "Paciente"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }

        $xmlFile = simplexml_load_file("./bancoDados/dadosLogin.xml") or die("Erro!");
            
        if($xmlFile == false){
            echo "Falha ao carregar o Xml: ";
            foreach(libxml_get_errors() as $error){
                echo "<br>" . $error->message;
            }
        }

        $administradores = $xmlFile->children()[0];
        $medicos = $xmlFile->children()[1];
        $laboratorios  =$xmlFile->children()[2];
        $pacientes = $xmlFile->children()[3];
        $emailSubTitle = '';
        $jaCadastrado = false;
        $senhaLogin = $emailLogin = "";

        if($_SERVER["REQUEST_METHOD"] == "POST"){

            $emailLogin = test_input($_POST["emailLoginMod"]);
            $senhaLogin = test_input($_POST["senhaLoginMod"]);

            if($senhaLogin == "" && $emailLogin == ""){
                foreach($pacientes->children() as $pac){ 
                    if($pac->email == $_SESSION['emailLogado'] ){
    
                        foreach($pacientes->children() as $pacCheck){
                            if($_POST['emailCadastroPac'] == $pacCheck->email && $_SESSION['emailLogado'] != $_POST['emailCadastroPac']){
                                $jaCadastrado = true;
                                break;
                            }
                        }
                        if(!$jaCadastrado){
                            $pac->nome = $_POST['nomeCadastroPac'];
                            $pac->cidade = $_POST['cidCadastroPac'];
                            $pac->estado = $_POST['estCadastroPac'];
                            $pac->cep = $_POST['cepCadastroPac'];
                            $pac->endereco = $_POST['endCadastroPac'];
                            $pac->telefone = $_POST['telCadastroPac'];
                            $pac->email = $_POST['emailCadastroPac'];
                            $pac->genero = $_POST['genCadastroPac'];
                            $pac->idade = $_POST['idadeCadastroPac'];
                            $pac->cpf = $_POST['cpfCadastroPac'];
                            $pac->senha = $_POST['senhaCadastroPac'];
                            $_SESSION['emailLogado'] = $_POST['emailCadastroPac'];
                            $xmlFile->saveXML("./bancoDados/dadosLogin.xml");
                        }else{
                            $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                        }
                        break;
    
                    }
                }

            }else{

                if($senhaLogin == "sairfurg00" && $emailLogin == "sairfurg00@furg.br"){
                   $senhaLogin = '';
                   $emailLogin = '';
                }
                $redirect = '';

                for($index = 0; $index <=3 ; $index++){
                    switch($index){
                        case 0: //adm
                            foreach($administradores->children() as $adm){ 
                                if($adm->email == $emailLogin && $adm->senha == $senhaLogin){
    
                                    $_SESSION['statusLogado'] = "Administrador";
                                    $_SESSION['profile'] = "profileAdm.php";
                                    $redirect ="
                                    <script> 
                                    window.location.href = './profileAdm.php';
                                    </script>";
                                    $index = 5; //quebra loop
                                    break;
                                }
                            }
                            break;
                        case 1: //med
                            foreach($medicos->children() as $med){ 
                                
                                if($med->email == $emailLogin && $med->senha == $senhaLogin){
    
                                    $_SESSION['statusLogado'] = "Médico";
                                    $_SESSION['profile'] = "profileMed.php";
                                    $index = 5; //quebra loop
                                    $redirect ="
                                    <script> 
                                    window.location.href = './profileMed.php';
                                    </script>";
                                    break;
                                }
                            }
                            break;
                        case 2: //lab
                            foreach($laboratorios->children() as $lab){ 
                                
                                if($lab->email == $emailLogin && $lab->senha == $senhaLogin){
    
                                    $_SESSION['statusLogado'] = "Laboratorio";
                                    $_SESSION['profile'] = "profileLab.php";
                                    $redirect ="
                                    <script> 
                                    window.location.href = './profileLab.php';
                                    </script>";
                                    $index = 5; //quebra loop
                                    break;
                                }
                            }
                            break;
                        case 3: //paciente
                            foreach($pacientes->children() as $pac){  
                                if($pac->email == $emailLogin && $pac->senha == $senhaLogin){
                                    $_SESSION['statusLogado'] = "Paciente";
                                    $_SESSION['profile'] = "profilePac.php";
                                    break;
                                }else{
                                    $_SESSION['statusLogado'] = "Visitante";
                                    $_SESSION['profile'] = "signUp.php";
                                    $redirect ="
                                    <script> 
                                    window.location.href = './signUp.php';
                                    </script>";
                                }
                            }
                    }
                }
                $_SESSION['emailLogado'] = $emailLogin;
                echo $redirect;
            }
        }
        
        foreach($pacientes->children() as $pac){ 
            if($pac->email == $_SESSION['emailLogado'] ){
                $nomePac = test_input($pac->nome);
                $cidadePac = test_input($pac->cidade);
                $estadoPac = test_input($pac->estado);
                $cepPac = test_input($pac->cep);
                $enderecoPac = test_input($pac->endereco);
                $telefonePac = test_input($pac->telefone);
                $emailPac = test_input($pac->email);
                $generoPac = test_input($pac->genero);
                $idadePac = test_input($pac->idade);
                $cpfPac = test_input($pac->cpf);
                $senhaPac = test_input($pac->senha);
                
                break;
            }
        }

        
        if($_SESSION['statusLogado'] != "Visitante"){
            $botaoSair = '<button type="button" id="botaoSair"class="btn btn-danger" style="width:75px;" onclick="logOut()">Sair</button>';
        }else{
            $botaoSair = "";
            $_SESSION['emailLogado'] = "";
        }

        if($_SESSION['statusLogado'] == "Administrador"){
            $_SESSION['profile'] = "profileAdm.php";
        }else if($_SESSION['statusLogado'] == "Médico"){
            $_SESSION['profile'] = "profileMed.php";
        }else if($_SESSION['statusLogado'] == "Laboratorio"){
            $_SESSION['profile'] = "profileLab.php";
        }else if($_SESSION['statusLogado'] == "Paciente"){
            $_SESSION['profile'] = "profilePac.php";
        }else{
            $_SESSION['profile'] = "signUp.php";
        }

        if($_SESSION['statusLogado'] != "Paciente"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }

    ?>


    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success" id="home">

        <div class="container">

            <a class="navbar-brand h1 mb-0" href="index.php"><i class="fa fa-heartbeat text-ligth" aria-hidden="true"></i> LifePlan</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSite">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="system.php">Sistema</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#faleConosco">Fale conosco</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="imp.php">Imprensa</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="navDrop" >
                            Social
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="https://www.facebook.com/">Facebook</a>
                            <a class="dropdown-item" href="https://www.instagram.com/">Instagram</a>
                            <a class="dropdown-item" href="https://twitter.com/">Twitter</a>
                        </div>
                    </li>
                   

                    <li class="nav-item mr-4">
                        <a type="button" class="nav-link" href="<?php echo $_SESSION['profile']?>"> Perfil <?php echo $_SESSION['statusLogado']?></a>
                    </li>
                </ul>

                <form class="form-inline">                    
                    <button type="button" class="btn btn-light" data-toggle="modal" data-target="#siteModal">Login</button>
                </form>

            </div>
        </div>
    </nav>

    <!-- Carousel -->
    <div id="carouselSite" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
            <li data-target="#carouselSite" data-slide-to="1"></li>
            <li data-target="#carouselSite" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/carousel_01.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_02.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_03.jpg" class="img-fluid d-block w
                -100">
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Posterior</span>
        </a>

    </div>

    

    
    <!-- Conteudo -->
    <div class="container">

        <div class="row">

            <div class="col-12 text-center mt-5" id="sistema">
                <h1 class="display-4"> <i class="fa fa-user-o text-success" aria-hidden="true"></i> Perfil <?php echo $_SESSION['statusLogado']?></h1>
                <p>Usuário: <?php echo $_SESSION['emailLogado']?></p>
            </div>

        </div>

        <div class="row">
            <div class="col-sm-6" style="text-align: justify;">
                <h3><i class="fa fa-pencil text-success" aria-hidden="true"></i> Histórico de Consultas e Exames</h3>
                <p>Como um paciente, você pode visualizar seu histórico de exames e consultas.</p>

                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="historicPac.php"> Histórico de Consultas</a>
                    <a class="list-group-item list-group-item-action" href="historicPac.php"> Histórico de Exames</a>
                
                </div>
            </div>

            <div class="col-sm-6">
                <h3><i class="fa fa-address-card-o text-success" aria-hidden="true"></i> Alterar Informações Pessoais</h3>
                 
                <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="nomeCadastroPac">Nome Completo:</label>
                                                <input type="text" class="form-control" 
                                                name="nomeCadastroPac"
                                                value="<?php echo $nomePac?>"
                                                id="nomeCadastroPac" placeholder="Digite aqui o nome completo..." required>

                                            </div>

                                        </div>
                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="endCadastroPac">Endereço</label>
                                                <input type="text" class="form-control" 
                                                name="endCadastroPac"
                                                value="<?php echo $enderecoPac?>"
                                                id="endCadastroPac" placeholder="Digite aqui o endereço..." required>

                                            </div>

                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-4">
                                                <label for="telCadastroPac">Telefone</label>
                                                <input type="text" id="telCadastroPac"
                                                name="telCadastroPac"
                                                value="<?php echo $telefonePac?>"
                                                class="form-control" placeholder="Digite o telefone aqui..."
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                                

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="cpfCadastroPac">CPF</label>
                                                <input type="text" id="cpfCadastroPac" class="form-control"
                                                name="cpfCadastroPac"
                                                value="<?php echo $cpfPac?>"
                                                placeholder="Digite o CPF aqui..."
                                                maxlength="11"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="11" required>

                                            </div>
                                            <div class="form-group col-sm-2">
                                                <label for="inputGenero">Genero</label>
                                                <select id="inputGenero" class="form-control"
                                                name="genCadastroPac"
                                                value="<?php echo $generoPac?>"
                                                required>
                                                    <option value ="">Escolha...</option>
                                                    <option value="M">Masculino</option>
                                                    <option value="F">Feminino</option>
                                                    <option value="O">Outros</option>
                                                    <option value="IDK">Não Identificar</option>
                                                </select>
                                                <small class="text-muted">*Selecione novamente</small>
                                            </div>
                                            <div class="form-group col-sm-2">
                                                <label for="inputIDade">Idade</label>
                                                <input type="text" id="inputIdade" placeholder="Idade" 
                                                name="idadeCadastroPac"
                                                value="<?php echo $idadePac?>"
                                                class="form-control"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                            </div>


                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6">

                                                <label for="cidCastroPac">Cidade</label>
                                                <input type="text" id="cidCadastroPac" class="form-control" 
                                                name="cidCadastroPac"
                                                value="<?php echo $cidadePac?>"
                                                placeholder="Digite aqui a cidade..." required>

                                            </div>

                                            <div class="form-group col-sm-4">

                                                <label for="estCadastroPac">Estado</label>
                                                <select id="estCadastroPac" class="form-control"
                                                name="estCadastroPac"
                                                value="<?php echo $estadoPac?>"
                                                required>
                                                    <option value ="">Escolha...</option>
                                                    <option value="AC">Acre</option>
                                                    <option value="AL">Alagoas</option>
                                                    <option value="AP">Amapá</option>
                                                    <option value="AM">Amazonas</option>
                                                    <option value="BA">Bahia</option>
                                                    <option value="CE">Ceará</option>
                                                    <option value="DF">Distrito Federal</option>
                                                    <option value="ES">Espírito Santo</option>
                                                    <option value="GO">Goiás</option>
                                                    <option value="MA">Maranhão</option>
                                                    <option value="MT">Mato Grosso</option>
                                                    <option value="MS">Mato Grosso do Sul</option>
                                                    <option value="MG">Minas Gerais</option>
                                                    <option value="PA">Pará</option>
                                                    <option value="PB">Paraíba</option>
                                                    <option value="PR">Paraná</option>
                                                    <option value="PE">Pernambuco</option>
                                                    <option value="PI">Piauí</option>
                                                    <option value="RJ">Rio de Janeiro</option>
                                                    <option value="RN">Rio Grande do Norte</option>
                                                    <option value="RS">Rio Grande do Sul</option>
                                                    <option value="RO">Rondônia</option>
                                                    <option value="RR">Roraima</option>
                                                    <option value="SC">Santa Catarina</option>
                                                    <option value="SP">São Paulo</option>
                                                    <option value="SE">Sergipe</option>
                                                    <option value="TO">Tocantins</option>
                                                </select>
                                                <small class="text-muted">*Selecione novamente</small>

                                            </div>

                                            <div class="form-group col-sm-2">

                                                <label for="cepCadastroPac">CEP</label>
                                                <input type="text" id="cepCadastroPac" 
                                                name="cepCadastroPac"
                                                value="<?php echo $cepPac?>"
                                                placeholder="Digite aqui..." class="form-control"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="8" required>

                                            </div>

                                        </div>

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">
                                                <label for="emailCadastroPac">Email</label>
                                                <input type="email" class="form-control" id="emailCadastroPac" 
                                                name="emailCadastroPac"
                                                aria-describedby="emailHelpPac" placeholder="Digite aqui o email..." required
                                                value= "<?php echo $emailPac?>">
                                                <?php echo $emailSubTitle?>
                                            </div>
                                            
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroPac">Senha</label>
                                                <input type="text" class="form-control" id="senhaCadastroPac"
                                                name="senhaCadastroPac" required placeholder="Digite a senha..."
                                                value= "<?php echo $senhaPac?>">
                                            </div>
                                            
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroConfirmPac" >Confirmar Senha</label>
                                                <input type="password" class="form-control"  required id="senhaCadastroConfirmPac" placeholder="Confirme a senha..." value= "<?php echo $senhaPac?>">

                                                <small id="senhaIncorretaPac" class="form-text text-muted"> 
                                                </small>

                                            </div>

                                        </div>
                                        
                                        <div class="form-row justify-content-center">
                                            <div class="form-group">
                                                <input type="hidden" name="tipoCadastro" value="Paciente"></input>

                                                <button type="submit" class="btn btn-success" 
                                                id="continueButtonPac"
                                                data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                                    Enviar
                                                </button>
                                            </div>
                                        </div>

                                        <script>
                                            document.getElementById("continueButtonPac").disabled=true;
                                            var senhaPac = document.getElementById("senhaCadastroPac");
                                            var senhaConfirmaPac = document.getElementById("senhaCadastroConfirmPac");

                                            checaSenha();

                                            function checaSenha(){
                                                if(senhaPac.value != senhaConfirmaPac.value){
                                                    document.getElementById("senhaIncorretaPac").innerHTML = "Senha Incorreta";
                                                    senhaConfirmaPac.setCustomValidity("Senha Incorreta!");
                                                    document.getElementById("continueButtonPac").disabled=true;
                                                } else{
                                                    senhaConfirmaPac.setCustomValidity("");
                                                    document.getElementById("senhaIncorretaPac").innerHTML = "";
                                                    document.getElementById("continueButtonPac").disabled=false;
                                                }
                                            }

                                            senhaPac.onchange = checaSenha;
                                            senhaConfirmaPac.onkeyup = checaSenha;
                                        </script>


                                    </form>


            </div>
        </div>
        

<!-- Footer -->
<div class="container">
        <div class="row mb-5">

            <div class="col-12 mb-3"><hr></div>

            <div class="col-sm-4" style="text-align: justify;">

                <h3>A LifePlan</h3>
                <p>Plano de saúde familiar e individual</p>
                <p>A LifePlan foi fundada em 2020 por 2 estudantes de engenharia da computação, Bryan Galani e Frederico Bender. A LifePlan visa proporcionar o plano de saúde ideal para voçe e sua familia, além de auxiliar o contato entre médico e paciente. Utilize nosso site para realizar consultas e exames. </p>

            </div>
            <div class="col-sm-4">
                <h3>Menu</h3>
                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="system.php">Sistema</a>

                    <a class="list-group-item list-group-item-action" href="plans.php">Planos</a>

                    <a class="list-group-item list-group-item-action" href="index.php#faleConosco">Fale Conosco</a>

                    <a class="list-group-item list-group-item-action" href="imp.php">Imprensa</a>
                </div>

            </div>
            <div class="col-sm-4">

                <h3>Social</h3>

                <div class="btn-group-vertical btn-block btn-group-lg" role="group">
                    <a class="btn btn-outline-success"  href="https://www.facebook.com/"><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>

                    <a class="btn btn-outline-success" href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a>

                    <a class="btn btn-outline-success" href="https://twitter.com/"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
                </div>


            </div>

            <div class="col-12 mt-5">

                <blockquote class="blockquote text-center">

                    <p class="mb-0">"Nada pior para a saúde que viver de aparências e fachadas. São pessoas com muito verniz e pouca raiz. Seu destino é a farmácia, o hospital, a dor."</p>
                    <footer class="blockquote-footer">Drauzio Varella <cite title="Source title">Médico, Cientista e Escritor</cite></footer>

                </blockquote>

            </div>

        </div>
    
    </div>
    

    <!-- Modal -->
    <div class="modal fade" id="siteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            

                <div class="modal-header">
                        <h4 class="modal-title w-100 text-center" >Login</h4>

                        <button type="button" class="close text-end" data-dismiss="modal" style="position: absolute; right: 15px;">
                            <span> &times; </span>
                        </button>    
                </div>

                <div class="modal-body">
                    
                   <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                        <div class="form-group mt-2">
                            <label for="emailLoginMod"><i class="fa fa-at" aria-hidden="true"></i> Email</label>
                            <input type="email" class="form-control" id="emailLoginMod" name="emailLoginMod" placeholder="Email">
                        </div>

                        <div class="form-group my-3">
                            <label for="senhaLoginMod"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Senha</label>
                            <input type="password" class="form-control" id="senhaLoginMod" name="senhaLoginMod" placeholder="Senha">
                        </div>

                        <div class="form-group text-center mb-2">
                            <button type="submit" class="btn btn-success" style="width:75px;" >Entrar</button>
                            <?php echo $botaoSair?>  
                        </div>

                        <input type="submit" style="visibility: hidden; width: 0px; height:0px; text-align:right; position:absolute;" id="hiddenSubmit">

                        <script>
                            function logOut(){
                                document.getElementById("emailLoginMod").value = 'sairfurg00@furg.br';
                                document.getElementById("senhaLoginMod").value = 'sairfurg00';
                                document.getElementById("hiddenSubmit").click();
                            }   
                        </script>

                        <div class="form-group my-2">
                            <h5 class="text-center"> Status: <?php echo $_SESSION['statusLogado']?></h5>
                        </div>

                   </form>

                </div>

                <div class="modal-footer">
                    <a href="signUp.php" class="btn btn-success" type="button" role="button">Cadastrar</a>

                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                </div>

            </div>
        </div>
    </div>


        


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>

    <script>

        $(function () {

            $('[data-toggle="popover"]').popover()

        })

    </script>

</body>



</html>