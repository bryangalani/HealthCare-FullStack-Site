<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css" >

    <!-- Meu estilo CSS-->
    <link rel = "stylesheet" href="myStyle/css/myPersonalStyles.css">

    <!-- Font-awesome -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">

    <!-- -->
    <script src="myJavascript/myInteractions.js"></script>

    <title>LifePlan</title>
</head>


<body>

    <!-- PHP -->
    <?php 
        include 'myPhp/functions.php';
        include 'myPhp/cadastroClass.php';

        session_start();
        //checa se o usuario que nao é adm tenta cadastrar
        if($_SESSION['statusLogado'] != "Administrador"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }

        //PDO - phpMyAdmin - SQL
        $server = "localhost:8889";
        $user = "bryan";
        $password = "admin";
        $db = "dados_lifeplan";

        try{
            //Criando conexão
            $db_connec = new PDO("mysql:host=$server", $user, $password);
            $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
            //Criando DB e Acessando
            $db_connec->exec("CREATE DATABASE IF NOT EXISTS $db");
            $db_connec =  new PDO("mysql:host=$server;dbname=$db", $user, $password);
            $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }catch(PDOException $e){
                echo "Erro: " . $e1->getMessage();
        }


        //puxar cadastros em classes para um vetor
        $vetorAdministradores = array();
        $vetorMedicos = array();
        $vetorLaboratorios = array();
        $vetorPacientes = array();
        
        $admprofileNumber = 0;
        $medprofileNumber = 0;
        $labprofileNumber = 0;
        $pacprofileNumber = 0;


        $vetorCardsAdm = array();
        $vetorCardsMed = array();
        $vetorCardsLab = array();
        $vetorCardsPac = array();


        $sqlGet_ = "SELECT * FROM administradores";
        $result_get = $db_connec->query($sqlGet_);

        $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $column){

            $emailAdm = test_input($column['email']);
            $senhaAdm = test_input($column['senha']);

            $admUnit = new Administrador($emailAdm, $senhaAdm);
            array_push($vetorAdministradores, $admUnit);
            
            $admButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardAdm'.$admprofileNumber.'" aria-expanded="false" value="Adm'.$admprofileNumber.'">
            Email: '.$emailAdm.'
            </button>' ;

            $admDataUnit = '
            <div class="collapse card btn-block" id="cardAdm'.$admprofileNumber.'">
            <ul class="list-group list-group-flush">
                    <li class="list-group-item">Email: '.$emailAdm.'</li>
                    <li class="list-group-item">Senha: '.$senhaAdm.'</li>
            </ul>
            <div class=" card-body">
            <form method="post" action:"">
                <input type="hidden" name="tipoDados" value="dadosAdministrador"></input>
                <input type="hidden" name="indiceDados" value="'.$admprofileNumber.'"></input>
                <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
            </form>
            </div>
            </div>';
            array_push($vetorCardsAdm, $admButtonUnit);
            array_push($vetorCardsAdm, $admDataUnit);
            $admprofileNumber += 1;
        }

            $sqlGet_ = "SELECT * FROM medicos";
            $result_get = $db_connec->query($sqlGet_);
            $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);

            foreach ($rows as $column){

                $nomeMed = test_input($column['nome']);
                $cidadeMed = test_input($column['cidade']);
                $estadoMed = test_input($column['estado']);
                $cepMed = test_input($column['cep']);
                $enderecoMed = test_input($column['endereco']);
                $telefoneMed = test_input($column['telefone']);
                $emailMed = test_input($column['email']);
                $especialidadeMed = test_input($column['especialidade']);
                $crmMed = test_input($column['crm']);
                $senhaMed = test_input($column['senha']);        

                $medicoUnit = new Medico($nomeMed, $cidadeMed, $estadoMed, $cepMed, $enderecoMed, $telefoneMed, $emailMed, $especialidadeMed, $crmMed, $senhaMed);
                array_push($vetorMedicos, $medicoUnit);

                $medButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardMed'.$medprofileNumber.'" aria-expanded="false">
                Email: '.$emailMed.'
                </button>' ;

                $medDataUnit =  '
                <div class="collapse card btn-block" id="cardMed'.$medprofileNumber.'">
                <ul class="list-group list-group-flush">
                        <li class="list-group-item">Nome: '.$nomeMed.'</li>
                        <li class="list-group-item">Cidade: '.$cidadeMed.'</li>
                        <li class="list-group-item">Estado: '.$estadoMed.'</li>
                        <li class="list-group-item">CEP: '.$cepMed.'</li>
                        <li class="list-group-item">Endereço: '.$enderecoMed.'</li>
                        <li class="list-group-item">Telefone: '.$telefoneMed.'</li>
                        <li class="list-group-item">Email: '.$emailMed.'</li>
                        <li class="list-group-item">Especialidade: '.$especialidadeMed.'</li>
                        <li class="list-group-item">CRM: '.$crmMed.'</li>
                        <li class="list-group-item">Senha: '.$senhaMed.'</li>
                </ul>
                <div class=" card-body">
                <form method="post" action:"">
                    <input type="hidden" name="tipoDados" value="dadosMedico"></input>
                    <input type="hidden" name="indiceDados" value="'.$medprofileNumber.'"></input>
                    <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
                </form>              
                </div>
                </div>';



                array_push($vetorCardsMed, $medButtonUnit);
                array_push($vetorCardsMed, $medDataUnit);
                $medprofileNumber += 1;
        }  

            $sqlGet_ = "SELECT * FROM laboratorios";
            $result_get = $db_connec->query($sqlGet_);
            $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);
        
            foreach ($rows as $column){
        
                $nomeLab = test_input($column['nome']);
                $cidadeLab = test_input($column['cidade']);
                $estadoLab = test_input($column['estado']);
                $cepLab = test_input($column['cep']);
                $enderecoLab = test_input($column['endereco']);
                $telefoneLab = test_input($column['telefone']);
                $emailLab = test_input($column['email']);
                $tipoExameLab = test_input($column['tipoExame']);
                $cnpjLab = test_input($column['cnpj']);
                $senhaLab = test_input($column['senha']);

                $laboratorioUnit = new Laboratorio($nomeLab, $cidadeLab, $estadoLab, $cepLab, $enderecoLab, $telefoneLab, $emailLab, $tipoExameLab, $cnpjLab, $senhaLab);
                array_push($vetorLaboratorios, $laboratorioUnit);



                $labButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardLab'.$labprofileNumber.'" aria-expanded="false">
                Email: '.$emailLab.'
                </button>' ;


                $labDataUnit = '
                <div class="collapse card btn-block" id="cardLab'.$labprofileNumber.'">
                <ul class="list-group list-group-flush">
                        <li class="list-group-item">Nome: '.$nomeLab.'</li>
                        <li class="list-group-item">Cidade: '.$cidadeLab.'</li>
                        <li class="list-group-item">Estado: '.$estadoLab.'</li>
                        <li class="list-group-item">CEP: '.$cepLab.'</li>
                        <li class="list-group-item">Endereço: '.$enderecoLab.'</li>
                        <li class="list-group-item">Telefone: '.$telefoneLab.'</li>
                        <li class="list-group-item">Email: '.$emailLab.'</li>
                        <li class="list-group-item">Exame(s): '.$tipoExameLab.'</li>
                        <li class="list-group-item">CNPJ: '.$cnpjLab.'</li>
                        <li class="list-group-item">Senha: '.$senhaLab.'</li>
                </ul>
                <div class=" card-body">
                <form method="post" action:"">
                    <input type="hidden" name="tipoDados" value="dadosLaboratorio"></input>
                    <input type="hidden" name="indiceDados" value="'.$labprofileNumber.'"></input>
                    <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
                </form>
                </div>
                </div>';


                array_push($vetorCardsLab, $labButtonUnit);
                array_push($vetorCardsLab, $labDataUnit);
                $labprofileNumber += 1;

        }
            $sqlGet_ = "SELECT * FROM pacientes";
            $result_get = $db_connec->query($sqlGet_);
        
            $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);
        
            foreach ($rows as $column){
        
                $nomePac = test_input($column['nome']);
                $cidadePac = test_input($column['cidade']);
                $estadoPac = test_input($column['estado']);
                $cepPac = test_input($column['cep']);
                $enderecoPac = test_input($column['endereco']);
                $telefonePac = test_input($column['telefone']);
                $emailPac = test_input($column['email']);
                $generoPac = test_input($column['genero']);
                $idadePac = test_input($column['idade']);
                $cpfPac = test_input($column['cpf']);
                $senhaPac = test_input($column['senha']);


                $pacienteUnit = new Paciente($nomePac, $cidadePac, $estadoPac, $cepPac, $enderecoPac, $telefonePac, $emailPac, $generoPac, $idadePac, $cpfPac ,$senhaPac);
                array_push($vetorPacientes, $pacienteUnit);


                $pacButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardPac'.$pacprofileNumber.'" aria-expanded="false">
                Email: '.$emailPac.'
                </button>' ;


                $pacDataUnit = '
                <div class="collapse card btn-block" id="cardPac'.$pacprofileNumber.'">
                <ul class="list-group list-group-flush">
                        <li class="list-group-item">Nome: '.$nomePac.'</li>
                        <li class="list-group-item">Cidade: '.$cidadePac.'</li>
                        <li class="list-group-item">Estado: '.$estadoPac.'</li>
                        <li class="list-group-item">CEP: '.$cepPac.'</li>
                        <li class="list-group-item">Endereço: '.$enderecoPac.'</li>
                        <li class="list-group-item">Telefone: '.$telefonePac.'</li>
                        <li class="list-group-item">Email: '.$emailPac.'</li>
                        <li class="list-group-item">Genero: '.$generoPac.'</li>
                        <li class="list-group-item">Idade: '.$idadePac.'</li>
                        <li class="list-group-item">CPF: '.$cpfPac.'</li>
                        <li class="list-group-item">Senha: '.$senhaPac.'</li>
                </ul>
                <div class=" card-body">
                <form method="post" action:"">
                    <input type="hidden" name="tipoDados" value="dadosPaciente"></input>
                    <input type="hidden" name="indiceDados" value="'.$pacprofileNumber.'"></input>
                    <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
                </form>
                </div>
                </div>';



                array_push($vetorCardsPac, $pacButtonUnit);
                array_push($vetorCardsPac, $pacDataUnit);
                $pacprofileNumber += 1;
        }

        $statusFormAdm = 'active';
        $statusFormMed = '';
        $statusFormLab = '';
        $statusFormPac = '';

        if($_POST['tipoDados'] == "dadosAdministrador"){

            $emailForm = $vetorAdministradores[$_POST['indiceDados']]->email;
            $sql_SetFormInfo = "SELECT COUNT(*) FROM administradores WHERE email = '$emailForm' ";
            if($result = $db_connec->query($sql_SetFormInfo)){
                if($result->fetchColumn() > 0){
                    $emailAdmCard = $vetorAdministradores[$_POST['indiceDados']]->email ;
                    $senhaAdmCard = $vetorAdministradores[$_POST['indiceDados']]->senha ;

                    $statusFormAdm = 'active';
                    $statusFormMed = '';
                    $statusFormLab = '';
                    $statusFormPac = '';
                }
            }

        }else if($_POST['tipoDados'] == "dadosMedico"){
            
            $emailForm = $vetorMedicos[$_POST['indiceDados']]->email;
            $sql_SetFormInfo = "SELECT COUNT(*) FROM medicos WHERE email = '$emailForm' ";

            if($result = $db_connec->query($sql_SetFormInfo)){
                if($result->fetchColumn() > 0){
                    $nomeMedCard = $vetorMedicos[$_POST['indiceDados']]->nome;
                    $cidadeMedCard = $vetorMedicos[$_POST['indiceDados']]->cidade;
                    $estadoMedCard = $vetorMedicos[$_POST['indiceDados']]->estado;
                    $cepMedCard = $vetorMedicos[$_POST['indiceDados']]->cep;
                    $enderecoMedCard = $vetorMedicos[$_POST['indiceDados']]->endereco;
                    $telefoneMedCard = $vetorMedicos[$_POST['indiceDados']]->telefone;
                    $emailMedCard = $vetorMedicos[$_POST['indiceDados']]->email;
                    $especialidadeMedCard = $vetorMedicos[$_POST['indiceDados']]->especialidade;
                    $crmMedCard = $vetorMedicos[$_POST['indiceDados']]->crm;
                    $senhaMedCard = $vetorMedicos[$_POST['indiceDados']]->senha;

                    $statusFormAdm = '';
                    $statusFormMed = 'active';
                    $statusFormLab = '';
                    $statusFormPac = '';
                }
            }
        }else if($_POST['tipoDados'] == "dadosLaboratorio"){
            $emailForm = $vetorLaboratorios[$_POST['indiceDados']]->email;
            $sql_SetFormInfo = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailForm' ";
            if($result = $db_connec->query($sql_SetFormInfo)){
                if($result->fetchColumn() > 0){

                    $nomeLabCard = $vetorLaboratorios[$_POST['indiceDados']]->nome;
                    $cidadeLabCard = $vetorLaboratorios[$_POST['indiceDados']]->cidade;
                    $estadoLabCard = $vetorLaboratorios[$_POST['indiceDados']]->estado;
                    $cepLabCard = $vetorLaboratorios[$_POST['indiceDados']]->cep;
                    $enderecoLabCard = $vetorLaboratorios[$_POST['indiceDados']]->endereco;
                    $telefoneLabCard = $vetorLaboratorios[$_POST['indiceDados']]->telefone;
                    $emailLabCard = $vetorLaboratorios[$_POST['indiceDados']]->email;
                    $tipoExameLabCard = $vetorLaboratorios[$_POST['indiceDados']]->tipoExame;
                    $cnpjLabCard = $vetorLaboratorios[$_POST['indiceDados']]->cnpj;
                    $senhaLabCard = $vetorLaboratorios[$_POST['indiceDados']]->senha;


                    $statusFormAdm = '';
                    $statusFormMed = '';
                    $statusFormLab = 'active';
                    $statusFormPac = '';
                }
            }

        }else if($_POST['tipoDados'] == "dadosPaciente"){

         
            $emailForm = $vetorPacientes[$_POST['indiceDados']]->email;
            $sql_SetFormInfo = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailForm' ";

            if($result = $db_connec->query($sql_SetFormInfo)){
                if($result->fetchColumn() > 0){
                    $nomePacCard = $vetorPacientes[$_POST['indiceDados']]->nome;
                    $cidadePacCard = $vetorPacientes[$_POST['indiceDados']]->cidade;
                    $estadoPacCard = $vetorPacientes[$_POST['indiceDados']]->estado;
                    $cepPacCard = $vetorPacientes[$_POST['indiceDados']]->cep;
                    $enderecoPacCard = $vetorPacientes[$_POST['indiceDados']]->endereco;
                    $telefonePacCard = $vetorPacientes[$_POST['indiceDados']]->telefone;
                    $emailPacCard = $vetorPacientes[$_POST['indiceDados']]->email;
                    $generoPacCard = $vetorPacientes[$_POST['indiceDados']]->genero;
                    $idadePacCard = $vetorPacientes[$_POST['indiceDados']]->idade;
                    $cpfPacCard = $vetorPacientes[$_POST['indiceDados']]->cpf;
                    $senhaPacCard = $vetorPacientes[$_POST['indiceDados']]->senha;

                    $statusFormAdm = '';
                    $statusFormMed = '';
                    $statusFormLab = '';
                    $statusFormPac = 'active';
                }
            }
        }
    
        //Atualizacao 
        if($_SERVER["REQUEST_METHOD"] == "POST"){

                $jaCadastrado = false;
                $statusSubCadastro ="";

                $emailLogin = $senhaLogin = "";

                $emailLogin = test_input($_POST['emailLoginMod']);
                $senhaLogin = test_input($_POST['senhaLoginMod']);
                $tipoCadastro = $_POST["tipoCadastro"];
                $jaCadastrado = false;
                $emailSubTitle = '';

                if($senhaLogin == "" && $emailLogin == ""){ //Atualizar os cadastros
                    if($tipoCadastro == ""){
                        $_SESSION['indiceDados'] =  $_POST['indiceDados'];
                    }

                    if($tipoCadastro == "Administrador"){

                        $emailSelected = $vetorAdministradores[$_SESSION['indiceDados']]->email;
                        $sqlFind_adm = "SELECT COUNT(*) FROM administradores WHERE email = '$emailSelected' ";
                        if($result = $db_connec->query($sqlFind_adm)){
                            if($result->fetchColumn() > 0){
                                //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                                $emailForm = $_POST['emailCadastroAdm'];
                                $sqlCheckEmail_adm = "SELECT COUNT(*) FROM administradores WHERE email = '$emailForm'";

                                if($result_temp = $db_connec->query($sqlCheckEmail_adm)){
                                    if($result_temp->fetchColumn() > 0 && $emailSelected != $_POST['emailCadastroAdm'] ) {
                                        $jaCadastrado = true;
                                        $statusSubCadastro = "Email não disponível";
                                    }
                                }
                                if(!$jaCadastrado){
                                    $sqlUpdate_adm = "UPDATE administradores SET email=?, senha=? WHERE email = '$emailSelected' ";
                                    $stmt = $db_connec->prepare($sqlUpdate_adm);
                                    $stmt->execute(
                                        array
                                        (
                                            $_POST['emailCadastroAdm'],
                                            $_POST['senhaCadastroAdm']
                                        )
                                    );
                                    $statusCadastro = "<b> Confirmado. </b>";

                                    $statusSubCadastro = "Administrador Alterado";
                                }else{
                                    $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                                }
                            }
                        }
                            
    
                    }else if($tipoCadastro == "Medico"){

                        $emailSelected_Med = $vetorMedicos[$_SESSION['indiceDados']]->email;
                        $sqlFind_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailSelected_Med' ";
                        if($result = $db_connec->query($sqlFind_med)){
                            if($result->fetchColumn() > 0){
                    
                                //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                                $emailForm = $_POST['emailCadastroMed'];
                                $sqlCheckEmail_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailForm'";
                    
                                if($result_temp = $db_connec->query($sqlCheckEmail_med)){
                                    if($result_temp->fetchColumn() > 0 && $emailSelected_Med != $_POST['emailCadastroMed'] ) {
                                        $jaCadastrado = true;
                                        $statusSubCadastro = "Email não disponível";
                                    }
                                }
                                if(!$jaCadastrado){
                    
                                    $resultC = $db_connec->query("SELECT * FROM medicos WHERE email = '$emailSelected_Med' ");
                                    $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                                    $crmTeste = $rows['crm'];
                    
                                    $sqlUpdate_med = "UPDATE medicos SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?,email=?, especialidade=?, crm=?, senha=? WHERE email = '$emailSelected_Med' ";
                    
                                    $crmMed_temp = $_POST['crmCadastroMed']; 
                                    $sqlCheck3 = "SELECT crm FROM medicos WHERE crm = '$crmMed_temp' ";
                                    $result3 = $db_connec->query($sqlCheck3);
                    
                                    if($result3->fetchColumn() > 0 && $crmTeste != $_POST['crmCadastroMed']){
                                        $statusCadastro = " <b> Negado. </b>";
                                        $statusSubCadastro = "CRM do Médico já cadastrado!";
                                    }else{
                                    $stmt = $db_connec->prepare($sqlUpdate_med);
                                    $stmt->execute(
                                        array
                                        (
                                            $_POST['nomeCadastroMed'],
                                            $_POST['cidCadastroMed'],
                                            $_POST['estCadastroMed'],
                                            $_POST['cepCadastroMed'],
                                            $_POST['endCadastroMed'],
                                            $_POST['telCadastroMed'],
                                            $_POST['emailCadastroMed'],
                                            $_POST['especCadastroMed'],
                                            $_POST['crmCadastroMed'],
                                            $_POST['senhaCadastroMed']
                                        )
                                    );
                                    $statusCadastro = "<b> Confirmado. </b>";
                                    $statusSubCadastro = "Médico Alterado";
                    
                                    }
                                }else{
                                    $statusCadastro = "<b> Negado. </b>";
                                    $statusSubCadastro = "Email indisponivel!";
                                    $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                                }
                            }
                        }
                    
                        }else if ($tipoCadastro == "Laboratorio"){
                            
                            
                            $emailSelected_Lab = $vetorLaboratorios[$_SESSION['indiceDados']]->email;
                            $sqlFind_lab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailSelected_Lab' ";
                            if($result = $db_connec->query($sqlFind_lab)){
                                if($result->fetchColumn() > 0){
                        
                                    //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                                    $emailForm = $_POST['emailCadastroLab'];
                                    $sqlCheckEmail_lab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailForm'";
                        
                                    if($result_temp = $db_connec->query($sqlCheckEmail_lab)){
                                        if($result_temp->fetchColumn() > 0 && $emailSelected_Lab != $_POST['emailCadastroLab'] ) {
                                            $jaCadastrado = true;
                                            $statusSubCadastro = "Email não disponível";
                                        }
                                    }
                                    if(!$jaCadastrado){
                        
                                        $resultC = $db_connec->query("SELECT * FROM laboratorios WHERE email = '$emailSelected_Lab' ");
                                        $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                                        $cnpjTeste = $rows['cnpj'];
                                        
                                        $sqlUpdate_lab = "UPDATE laboratorios SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?, email=?, tipoExame=?, cnpj=?, senha=? WHERE email = '$emailSelected_Lab' ";
                        
                                        $cnpjLab_temp = $_POST['cnpjCadastroLab']; 
                                        $sqlCheck3 = "SELECT cnpj FROM laboratorios WHERE cnpj = '$cnpjLab_temp' ";
                                        $result3 = $db_connec->query($sqlCheck3);
                        
                                        if($result3->fetchColumn() > 0 && $cnpjTeste != $_POST['cnpjCadastroLab']){
                                            $statusCadastro = " <b> Negado. </b>";
                                            $statusSubCadastro = "CNPJ do Laboartório já cadastrado!";
                                        }else{
                                        $stmt = $db_connec->prepare($sqlUpdate_lab);
                                        $stmt->execute(
                                            array
                                            (
                                                $_POST['nomeCadastroLab'],
                                                $_POST['cidCadastroLab'],
                                                $_POST['estCadastroLab'],
                                                $_POST['cepCadastroLab'],
                                                $_POST['endCadastroLab'],
                                                $_POST['telCadastroLab'],
                                                $_POST['emailCadastroLab'],
                                                $_POST['tipoExameCadastroLab'],
                                                $_POST['cnpjCadastroLab'],
                                                $_POST['senhaCadastroLab']
                                            )
                                        );
                        
                                        $statusCadastro = "<b> Confirmado. </b>";
                                        $statusSubCadastro = "Laboratorio Alterado";
                                        }
                                    }else{
                                        $statusCadastro = "<b> Negado. </b>";
                                        $statusSubCadastro = "Email indisponivel!";
                                        $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                                    }
                                }
                            }
                        }else if($tipoCadastro == "Paciente"){
                            
                            $emailSelected_Pac = $vetorPacientes[$_SESSION['indiceDados']]->email;
                            $sqlFind_pac = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailSelected_Pac' ";
                            if($result = $db_connec->query($sqlFind_pac))
                            {
                                if($result->fetchColumn() > 0){
                                //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                                $emailForm = $_POST['emailCadastroPac'];
                                $sqlCheckEmail_pac = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailForm'";

                                    if($result_temp = $db_connec->query($sqlCheckEmail_pac)){
                                        if($result_temp->fetchColumn() > 0 && $emailSelected_Pac != $_POST['emailCadastroPac'] ) {
                                            $jaCadastrado = true;
                                            $statusSubCadastro = "Email não disponível";
                                        }
                                    }
                                    if(!$jaCadastrado){

                                        $resultC = $db_connec->query("SELECT * FROM pacientes WHERE email = '$emailSelected_Pac' ");
                                        $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                                        $cpfTeste = $rows['cpf'];
                                        
                                        $sqlUpdate_pac = "UPDATE pacientes SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?, email=?, genero=?, idade=?, cpf=?, senha=? WHERE email = '$emailSelected_Pac' ";

                                        $cpfPac_temp = $_POST['cpfCadastroPac']; 
                                        $sqlCheck3 = "SELECT cpf FROM pacientes WHERE cpf = '$cpfPac_temp' ";
                                        $result3 = $db_connec->query($sqlCheck3);

                                        if($result3->fetchColumn() > 0 && $cpfTeste != $_POST['cpfCadastroPac']){
                                            $statusCadastro = " <b> Negado. </b>";
                                            $statusSubCadastro = "CPF do Paciente já cadastrado!";
                                        }else{
                                        $stmt = $db_connec->prepare($sqlUpdate_pac);
                                        $stmt->execute(
                                            array
                                            (
                                                $_POST['nomeCadastroPac'],
                                                $_POST['cidCadastroPac'],
                                                $_POST['estCadastroPac'],
                                                $_POST['cepCadastroPac'],
                                                $_POST['endCadastroPac'],
                                                $_POST['telCadastroPac'],
                                                $_POST['emailCadastroPac'],
                                                $_POST['genCadastroPac'],
                                                $_POST['idadeCadastroPac'],
                                                $_POST['cpfCadastroPac'],
                                                $_POST['senhaCadastroPac']
                                            )
                                        );

                                        $statusCadastro = "<b> Confirmado. </b>";
                                        $statusSubCadastro = "Alteração realizada!";

                                        }
                                    }else{
                                            $statusCadastro = "<b> Negado. </b>";
                                            $statusSubCadastro = "Email indisponivel!";
                                            $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                                    }
                                }        
                            }
                        }
                    
                }else{
                    if($senhaLogin == "sairfurg00" && $emailLogin == "sairfurg00@furg.br"){
                        $senhaLogin = '';
                        $emailLogin = '';
                    }

                    for($index = 0; $index <=3 ; $index++){
                        switch($index){
                            case 0: //adm
                                $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0){                
                                        $sqlCheck = "SELECT * FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                        $result = $db_connec->query($sqlCheck);


                                        $_SESSION['statusLogado'] = "Administrador";
                                        $_SESSION['profile'] = "profileAdm.php";
                                        $index = 5; //quebra loop
                                    break;
                                    }
                                }  
                                break;
                            case 1: //med
                                
                                $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0){                
                                        $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                        $result = $db_connec->query($sqlCheck);

                                        $_SESSION['statusLogado'] = "Médico";
                                        $_SESSION['profile'] = "profileMed.php";
                                        $index = 5; //quebra loop
                                    break;  
                                    }
                                }
                                
                                break;
                            case 2: //lab
                                
                                $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0){
            
                                        $sqlCheck = "SELECT * FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                        $result = $db_connec->query($sqlCheck);
                                        
                                        $_SESSION['statusLogado'] = "Laboratorio";
                                        $_SESSION['profile'] = "profileLab.php";
                                        $index = 5; //quebra loop
                                        break;
                                    }
                                }
                                
                                break;
                            case 3: //paciente
                                $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0)
                                    {
                                        $sqlCheck = "SELECT * FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
            
                                        $result = $db_connec->query($sqlCheck);

                                        $_SESSION['statusLogado'] = "Paciente";
                                        $_SESSION['profile'] = "profilePac.php";
                                        break;

                                    }else{
                                        $_SESSION['statusLogado'] = "Visitante";
                                        $_SESSION['profile'] = "signUp.php";
                                    }
                                }
                                
                        }
                    }
                    $_SESSION['emailLogado'] = $emailLogin;
                }
                
        }

        //Repete para conseguir atualizar, sem dar refresh na pag
        // Deste modo, assim que um usuario for atualizado no DB, sera atualizado na tela.

        //puxar cadastros em classes para um vetor
         $vetorAdministradores = array();
         $vetorMedicos = array();
         $vetorLaboratorios = array();
         $vetorPacientes = array();
         
         $admprofileNumber = 0;
         $medprofileNumber = 0;
         $labprofileNumber = 0;
         $pacprofileNumber = 0;
 
 
         $vetorCardsAdm = array();
         $vetorCardsMed = array();
         $vetorCardsLab = array();
         $vetorCardsPac = array();
 
 
         $sqlGet_ = "SELECT * FROM administradores";
         $result_get = $db_connec->query($sqlGet_);
 
         $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);
 
         foreach ($rows as $column){
 
             $emailAdm = test_input($column['email']);
             $senhaAdm = test_input($column['senha']);
 
             $admUnit = new Administrador($emailAdm, $senhaAdm);
             array_push($vetorAdministradores, $admUnit);
             
             $admButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardAdm'.$admprofileNumber.'" aria-expanded="false" value="Adm'.$admprofileNumber.'">
             Email: '.$emailAdm.'
             </button>' ;
 
             $admDataUnit = '
             <div class="collapse card btn-block" id="cardAdm'.$admprofileNumber.'">
             <ul class="list-group list-group-flush">
                     <li class="list-group-item">Email: '.$emailAdm.'</li>
                     <li class="list-group-item">Senha: '.$senhaAdm.'</li>
             </ul>
             <div class=" card-body">
             <form method="post" action:"">
                 <input type="hidden" name="tipoDados" value="dadosAdministrador"></input>
                 <input type="hidden" name="indiceDados" value="'.$admprofileNumber.'"></input>
                 <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
             </form>
             </div>
             </div>';
             array_push($vetorCardsAdm, $admButtonUnit);
             array_push($vetorCardsAdm, $admDataUnit);
             $admprofileNumber += 1;
         }
 
             $sqlGet_ = "SELECT * FROM medicos";
             $result_get = $db_connec->query($sqlGet_);
             $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);
 
             foreach ($rows as $column){
 
                 $nomeMed = test_input($column['nome']);
                 $cidadeMed = test_input($column['cidade']);
                 $estadoMed = test_input($column['estado']);
                 $cepMed = test_input($column['cep']);
                 $enderecoMed = test_input($column['endereco']);
                 $telefoneMed = test_input($column['telefone']);
                 $emailMed = test_input($column['email']);
                 $especialidadeMed = test_input($column['especialidade']);
                 $crmMed = test_input($column['crm']);
                 $senhaMed = test_input($column['senha']);        
 
                 $medicoUnit = new Medico($nomeMed, $cidadeMed, $estadoMed, $cepMed, $enderecoMed, $telefoneMed, $emailMed, $especialidadeMed, $crmMed, $senhaMed);
                 array_push($vetorMedicos, $medicoUnit);
 
                 $medButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardMed'.$medprofileNumber.'" aria-expanded="false">
                 Email: '.$emailMed.'
                 </button>' ;
 
                 $medDataUnit =  '
                 <div class="collapse card btn-block" id="cardMed'.$medprofileNumber.'">
                 <ul class="list-group list-group-flush">
                         <li class="list-group-item">Nome: '.$nomeMed.'</li>
                         <li class="list-group-item">Cidade: '.$cidadeMed.'</li>
                         <li class="list-group-item">Estado: '.$estadoMed.'</li>
                         <li class="list-group-item">CEP: '.$cepMed.'</li>
                         <li class="list-group-item">Endereço: '.$enderecoMed.'</li>
                         <li class="list-group-item">Telefone: '.$telefoneMed.'</li>
                         <li class="list-group-item">Email: '.$emailMed.'</li>
                         <li class="list-group-item">Especialidade: '.$especialidadeMed.'</li>
                         <li class="list-group-item">CRM: '.$crmMed.'</li>
                         <li class="list-group-item">Senha: '.$senhaMed.'</li>
                 </ul>
                 <div class=" card-body">
                 <form method="post" action:"">
                     <input type="hidden" name="tipoDados" value="dadosMedico"></input>
                     <input type="hidden" name="indiceDados" value="'.$medprofileNumber.'"></input>
                     <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
                 </form>              
                 </div>
                 </div>';
 
 
 
                 array_push($vetorCardsMed, $medButtonUnit);
                 array_push($vetorCardsMed, $medDataUnit);
                 $medprofileNumber += 1;
         }  
 
             $sqlGet_ = "SELECT * FROM laboratorios";
             $result_get = $db_connec->query($sqlGet_);
             $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);
         
             foreach ($rows as $column){
         
                 $nomeLab = test_input($column['nome']);
                 $cidadeLab = test_input($column['cidade']);
                 $estadoLab = test_input($column['estado']);
                 $cepLab = test_input($column['cep']);
                 $enderecoLab = test_input($column['endereco']);
                 $telefoneLab = test_input($column['telefone']);
                 $emailLab = test_input($column['email']);
                 $tipoExameLab = test_input($column['tipoExame']);
                 $cnpjLab = test_input($column['cnpj']);
                 $senhaLab = test_input($column['senha']);
 
                 $laboratorioUnit = new Laboratorio($nomeLab, $cidadeLab, $estadoLab, $cepLab, $enderecoLab, $telefoneLab, $emailLab, $tipoExameLab, $cnpjLab, $senhaLab);
                 array_push($vetorLaboratorios, $laboratorioUnit);
 
 
 
                 $labButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardLab'.$labprofileNumber.'" aria-expanded="false">
                 Email: '.$emailLab.'
                 </button>' ;
 
 
                 $labDataUnit = '
                 <div class="collapse card btn-block" id="cardLab'.$labprofileNumber.'">
                 <ul class="list-group list-group-flush">
                         <li class="list-group-item">Nome: '.$nomeLab.'</li>
                         <li class="list-group-item">Cidade: '.$cidadeLab.'</li>
                         <li class="list-group-item">Estado: '.$estadoLab.'</li>
                         <li class="list-group-item">CEP: '.$cepLab.'</li>
                         <li class="list-group-item">Endereço: '.$enderecoLab.'</li>
                         <li class="list-group-item">Telefone: '.$telefoneLab.'</li>
                         <li class="list-group-item">Email: '.$emailLab.'</li>
                         <li class="list-group-item">Exame(s): '.$tipoExameLab.'</li>
                         <li class="list-group-item">CNPJ: '.$cnpjLab.'</li>
                         <li class="list-group-item">Senha: '.$senhaLab.'</li>
                 </ul>
                 <div class=" card-body">
                 <form method="post" action:"">
                     <input type="hidden" name="tipoDados" value="dadosLaboratorio"></input>
                     <input type="hidden" name="indiceDados" value="'.$labprofileNumber.'"></input>
                     <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
                 </form>
                 </div>
                 </div>';
 
 
                 array_push($vetorCardsLab, $labButtonUnit);
                 array_push($vetorCardsLab, $labDataUnit);
                 $labprofileNumber += 1;
 
         }
             $sqlGet_ = "SELECT * FROM pacientes";
             $result_get = $db_connec->query($sqlGet_);
         
             $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);
         
             foreach ($rows as $column){
         
                 $nomePac = test_input($column['nome']);
                 $cidadePac = test_input($column['cidade']);
                 $estadoPac = test_input($column['estado']);
                 $cepPac = test_input($column['cep']);
                 $enderecoPac = test_input($column['endereco']);
                 $telefonePac = test_input($column['telefone']);
                 $emailPac = test_input($column['email']);
                 $generoPac = test_input($column['genero']);
                 $idadePac = test_input($column['idade']);
                 $cpfPac = test_input($column['cpf']);
                 $senhaPac = test_input($column['senha']);
 
 
                 $pacienteUnit = new Paciente($nomePac, $cidadePac, $estadoPac, $cepPac, $enderecoPac, $telefonePac, $emailPac, $generoPac, $idadePac, $cpfPac ,$senhaPac);
                 array_push($vetorPacientes, $pacienteUnit);
 
 
                 $pacButtonUnit = '<button class="btn btn-block btn-outline-success mt-2" type="button" data-toggle="collapse" data-target="#cardPac'.$pacprofileNumber.'" aria-expanded="false">
                 Email: '.$emailPac.'
                 </button>' ;
 
 
                 $pacDataUnit = '
                 <div class="collapse card btn-block" id="cardPac'.$pacprofileNumber.'">
                 <ul class="list-group list-group-flush">
                         <li class="list-group-item">Nome: '.$nomePac.'</li>
                         <li class="list-group-item">Cidade: '.$cidadePac.'</li>
                         <li class="list-group-item">Estado: '.$estadoPac.'</li>
                         <li class="list-group-item">CEP: '.$cepPac.'</li>
                         <li class="list-group-item">Endereço: '.$enderecoPac.'</li>
                         <li class="list-group-item">Telefone: '.$telefonePac.'</li>
                         <li class="list-group-item">Email: '.$emailPac.'</li>
                         <li class="list-group-item">Genero: '.$generoPac.'</li>
                         <li class="list-group-item">Idade: '.$idadePac.'</li>
                         <li class="list-group-item">CPF: '.$cpfPac.'</li>
                         <li class="list-group-item">Senha: '.$senhaPac.'</li>
                 </ul>
                 <div class=" card-body">
                 <form method="post" action:"">
                     <input type="hidden" name="tipoDados" value="dadosPaciente"></input>
                     <input type="hidden" name="indiceDados" value="'.$pacprofileNumber.'"></input>
                     <input type="submit" class="card-link btn btn-success" value ="Alterar Cadastro"></input>
                 </form>
                 </div>
                 </div>';
 
 
 
                 array_push($vetorCardsPac, $pacButtonUnit);
                 array_push($vetorCardsPac, $pacDataUnit);
                 $pacprofileNumber += 1;
         }
 
         $statusFormAdm = 'active';
         $statusFormMed = '';
         $statusFormLab = '';
         $statusFormPac = '';
 
         if($_POST['tipoDados'] == "dadosAdministrador"){
 
             $emailForm = $vetorAdministradores[$_POST['indiceDados']]->email;
             $sql_SetFormInfo = "SELECT COUNT(*) FROM administradores WHERE email = '$emailForm' ";
             if($result = $db_connec->query($sql_SetFormInfo)){
                 if($result->fetchColumn() > 0){
                     $emailAdmCard = $vetorAdministradores[$_POST['indiceDados']]->email ;
                     $senhaAdmCard = $vetorAdministradores[$_POST['indiceDados']]->senha ;
 
                     $statusFormAdm = 'active';
                     $statusFormMed = '';
                     $statusFormLab = '';
                     $statusFormPac = '';
                 }
             }
 
         }else if($_POST['tipoDados'] == "dadosMedico"){
             
             $emailForm = $vetorMedicos[$_POST['indiceDados']]->email;
             $sql_SetFormInfo = "SELECT COUNT(*) FROM medicos WHERE email = '$emailForm' ";
 
             if($result = $db_connec->query($sql_SetFormInfo)){
                 if($result->fetchColumn() > 0){
                     $nomeMedCard = $vetorMedicos[$_POST['indiceDados']]->nome;
                     $cidadeMedCard = $vetorMedicos[$_POST['indiceDados']]->cidade;
                     $estadoMedCard = $vetorMedicos[$_POST['indiceDados']]->estado;
                     $cepMedCard = $vetorMedicos[$_POST['indiceDados']]->cep;
                     $enderecoMedCard = $vetorMedicos[$_POST['indiceDados']]->endereco;
                     $telefoneMedCard = $vetorMedicos[$_POST['indiceDados']]->telefone;
                     $emailMedCard = $vetorMedicos[$_POST['indiceDados']]->email;
                     $especialidadeMedCard = $vetorMedicos[$_POST['indiceDados']]->especialidade;
                     $crmMedCard = $vetorMedicos[$_POST['indiceDados']]->crm;
                     $senhaMedCard = $vetorMedicos[$_POST['indiceDados']]->senha;
 
                     $statusFormAdm = '';
                     $statusFormMed = 'active';
                     $statusFormLab = '';
                     $statusFormPac = '';
                 }
             }
         }else if($_POST['tipoDados'] == "dadosLaboratorio"){
             $emailForm = $vetorLaboratorios[$_POST['indiceDados']]->email;
             $sql_SetFormInfo = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailForm' ";
             if($result = $db_connec->query($sql_SetFormInfo)){
                 if($result->fetchColumn() > 0){
 
                     $nomeLabCard = $vetorLaboratorios[$_POST['indiceDados']]->nome;
                     $cidadeLabCard = $vetorLaboratorios[$_POST['indiceDados']]->cidade;
                     $estadoLabCard = $vetorLaboratorios[$_POST['indiceDados']]->estado;
                     $cepLabCard = $vetorLaboratorios[$_POST['indiceDados']]->cep;
                     $enderecoLabCard = $vetorLaboratorios[$_POST['indiceDados']]->endereco;
                     $telefoneLabCard = $vetorLaboratorios[$_POST['indiceDados']]->telefone;
                     $emailLabCard = $vetorLaboratorios[$_POST['indiceDados']]->email;
                     $tipoExameLabCard = $vetorLaboratorios[$_POST['indiceDados']]->tipoExame;
                     $cnpjLabCard = $vetorLaboratorios[$_POST['indiceDados']]->cnpj;
                     $senhaLabCard = $vetorLaboratorios[$_POST['indiceDados']]->senha;
 
 
                     $statusFormAdm = '';
                     $statusFormMed = '';
                     $statusFormLab = 'active';
                     $statusFormPac = '';
                 }
             }
 
         }else if($_POST['tipoDados'] == "dadosPaciente"){
 
          
             $emailForm = $vetorPacientes[$_POST['indiceDados']]->email;
             $sql_SetFormInfo = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailForm' ";
 
             if($result = $db_connec->query($sql_SetFormInfo)){
                 if($result->fetchColumn() > 0){
                     $nomePacCard = $vetorPacientes[$_POST['indiceDados']]->nome;
                     $cidadePacCard = $vetorPacientes[$_POST['indiceDados']]->cidade;
                     $estadoPacCard = $vetorPacientes[$_POST['indiceDados']]->estado;
                     $cepPacCard = $vetorPacientes[$_POST['indiceDados']]->cep;
                     $enderecoPacCard = $vetorPacientes[$_POST['indiceDados']]->endereco;
                     $telefonePacCard = $vetorPacientes[$_POST['indiceDados']]->telefone;
                     $emailPacCard = $vetorPacientes[$_POST['indiceDados']]->email;
                     $generoPacCard = $vetorPacientes[$_POST['indiceDados']]->genero;
                     $idadePacCard = $vetorPacientes[$_POST['indiceDados']]->idade;
                     $cpfPacCard = $vetorPacientes[$_POST['indiceDados']]->cpf;
                     $senhaPacCard = $vetorPacientes[$_POST['indiceDados']]->senha;
 
                     $statusFormAdm = '';
                     $statusFormMed = '';
                     $statusFormLab = '';
                     $statusFormPac = 'active';
                 }
             }
         }

        
        //Fechamento
        if($_SESSION['statusLogado'] != "Visitante"){
            $botaoSair = '<button type="button" id="botaoSair"class="btn btn-danger" style="width:75px;" onclick="logOut()">Sair</button>';
        }else{
            $botaoSair = "";
            $_SESSION['emailLogado'] = "";
        }

        if($_SESSION['statusLogado'] == "Administrador"){
            $_SESSION['profile'] = "profileAdm.php";
        }else if($_SESSION['statusLogado'] == "Médico"){
            $_SESSION['profile'] = "profileMed.php";
        }else if($_SESSION['statusLogado'] == "Laboratorio"){
            $_SESSION['profile'] = "profileLab.php";
        }else if($_SESSION['statusLogado'] == "Paciente"){
            $_SESSION['profile'] = "profilePac.php";
        }else{
            $_SESSION['profile'] = "signUp.php";
        }

        if($_SESSION['statusLogado'] != "Administrador"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }
    ?>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success" id="home">

        <div class="container">

            <a class="navbar-brand h1 mb-0" href="index.php"><i class="fa fa-heartbeat text-ligth" aria-hidden="true"></i> LifePlan</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSite">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="system.php">Sistema</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#faleConosco">Fale conosco</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="imp.php">Imprensa</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="navDrop" >
                            Social
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="https://www.facebook.com/">Facebook</a>
                            <a class="dropdown-item" href="https://www.instagram.com/">Instagram</a>
                            <a class="dropdown-item" href="https://twitter.com/">Twitter</a>
                        </div>
                    </li>
                   

                    <li class="nav-item mr-4">
                        <a type="button" class="nav-link" href="<?php echo $_SESSION['profile']?>"> Perfil <?php echo $_SESSION['statusLogado']?></a>
                    </li>
                </ul>

                <form class="form-inline">                    
                    <button type="button" class="btn btn-light" data-toggle="modal" data-target="#siteModal">Login</button>
                </form>

            </div>
        </div>
    </nav>

    <!-- Carousel -->
    <div id="carouselSite" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
            <li data-target="#carouselSite" data-slide-to="1"></li>
            <li data-target="#carouselSite" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/carousel_01.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_02.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_03.jpg" class="img-fluid d-block w
                -100">
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Posterior</span>
        </a>

    </div>


    <!-- Conteudo -->
    <div class="container">
            <div class="row">
                <div class="col-12 text-center">

                    <h1 class="display-4"><i class="fa fa-address-card-o text-success" aria-hidden="true"></i> Alterar Cadastros </h1>
                    <p> <?php echo $statusCadastro . $statusSubCadastro ?>  </p>
                    <hr>

                </div>

            </div>

        <!-- ScrollSpy -->
        <div class="row mb-2">

            <div class="col-md-6 mb-3">
                <nav class="navbar navbar-light bg-light justify-content-center mb-3">
                    <ul class="nav nav-pills justify-content-center" id="pills-nav" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link <?php echo $statusFormAdm?>" id="nav-pills-00" data-toggle="pill" href="#nav-item-00">Administrador</a>
                        </li>

                            <li class="nav-item">
                                <a class="nav-link <?php echo $statusFormMed?>" id="nav-pills-01" data-toggle="pill" href="#nav-item-01">Médico</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link <?php echo $statusFormLab?>" id="nav-pills-02" data-toggle="pill" href="#nav-item-02">Laboratório</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $statusFormPac?>" id="nav-pills-03" data-toggle="pill" href="#nav-item-03">Paciente</a>
                            </li>

                    </ul>
                </nav>
    
                <div class="tab-content" id="nav-pills-content">

                    <div class="tab-pane fade show <?php echo $statusFormAdm?>" id="nav-item-00" role="tabpanel">

                        <div class="row justify-content-center mb-5">

                            <div class="col-sm-12">

                                <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                    <div class="form-row">

                                        <div class="form-group col-md-12">
                                            <label for="emailCadastroAdm">Email</label>
                                            <input type="email" class="form-control" id="emailCadastroAdm"
                                            name="emailCadastroAdm" aria-describedby="emailHelpAdm" placeholder="Digite aqui o email..."
                                            value="<?php echo $emailAdmCard?>" required>
                                            <?php echo $emailSubTitle?>
                                            
                                        </div>
                                        
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-md-6 text-left">
                                            <label for="senhaCadastroAdm">Senha</label>
                                            <input type="text" class="form-control" id="senhaCadastroAdm" 
                                            name="senhaCadastroAdm"
                                            placeholder="Digite a senha..."
                                            value="<?php echo $senhaAdmCard?>"
                                            required>
                                        </div>
                                        
                                        <div class="form-group col-md-6 text-left">
                                            <label for="senhaCadastroConfirmAdm" >Confirmar Senha</label>
                                            <input type="password" class="form-control"  id="senhaCadastroConfirmAdm" placeholder="Confirme a senha..."
                                            value="<?php echo $senhaAdmCard?>" required>

                                            <small id="senhaIncorretaAdm" class="form-text text-muted"> 
                                            </small>
                                        </div>
                                    </div>

                                    <div class="form-row justify-content-center">
                                        <div class="form-group">

                                            <input type="hidden" name="tipoCadastro" value="Administrador"></input>

                                            <input type="submit" class="btn btn-success" 
                                            id="continueButtonAdm"
                                            data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise"
                                            value="Enviar"></input>

                                        </div>
                                    </div>

                                    <script>

                                        document.getElementById("continueButtonAdm").disabled =true;
                                        
                                        var senhaAdm = document.getElementById("senhaCadastroAdm");
                                        var senhaConfirmaAdm = document.getElementById("senhaCadastroConfirmAdm");

                                        checaSenha();

                                        function checaSenha(){
                                            if(senhaAdm.value != senhaConfirmaAdm.value){
                                                document.getElementById("senhaIncorretaAdm").innerHTML = "Senha Incorreta";
                                                senhaConfirmaAdm.setCustomValidity("Senha Incorreta!");
                                                document.getElementById("continueButtonAdm").disabled=true;
                                            }else{
                                                senhaConfirmaAdm.setCustomValidity("");
                                                document.getElementById("senhaIncorretaAdm").innerHTML = "";
                                                document.getElementById("continueButtonAdm").disabled =false;
                                            }
                                        }

                                        senhaAdm.onchange = checaSenha;
                                        senhaConfirmaAdm.onkeyup = checaSenha;
                                    </script>

                                </form>


                            </div>

                        </div>

                    </div>

                    <div class="tab-pane fade show <?php echo $statusFormMed?>" id="nav-item-01" role="tabpanel">

                        <div class="row justify-content-center mb-5">

                            <div class="col-sm-12">

                                <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                    <div class="form-row">

                                        <div class="form-group col-sm-12">

                                            <label for="nomeCadastroMed">Nome Completo:</label>
                                            <input type="text" class="form-control" id="nomeCadastroMed" 
                                            name="nomeCadastroMed"
                                            placeholder="Digite aqui o nome completo..."
                                            value="<?php echo $nomeMedCard?>"
                                            required>

                                        </div>

                                    </div>
                                    <div class="form-row">

                                        <div class="form-group col-sm-12">

                                            <label for="endCadMed">Endereço</label>
                                            <input type="text" class="form-control" id="endCadMed" 
                                            name="endCadastroMed"
                                            placeholder="Digite aqui o endereço..."
                                            value="<?php echo $enderecoMedCard?>"
                                            required>

                                        </div>

                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-4">
                                            <label for="inputTelefone">Telefone</label>
                                            <input type="text" id="inputTelefone" class="form-control" 
                                            name="telCadastroMed"
                                            placeholder="Digite o telefone aqui..." 
                                            value="<?php echo $telefoneMedCard?>"required >

                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="inputCRM">CRM</label>
                                            <input type="text" id="inputCRM" class="form-control" 
                                            name="crmCadastroMed"
                                            placeholder="Digite o CRM aqui..."
                                            maxlength="7"
                                            value="<?php echo $crmMedCard?>"
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>

                                        </div>
                                        <div class="form-group col-sm-4">
                                        <label for="especialidadeMedico">Especialidade</label>
                                        <select required class="form-control" id="especialidadeMedico" 
                                        name ="especCadastroMed"
                                        value="<?php echo $especialidadeMedCard?>"
                                        name="especialidadeMedico">
                                            <option >Selecione...</option>
                                            <option>ACUPUNTURA</option>
                                            <option >ADMINISTRAÇÃO EM SAÚDE</option>
                                            <option >ADMINISTRAÇÃO HOSPITALAR</option>
                                            <option >ALERGIA E IMUNOLOGIA</option>
                                            <option >ALERGIA E IMUNOPATOLOGIA</option>
                                            <option >ANATOMIA PATOLÓGICA</option>
                                            <option >ANESTESIOLOGIA</option>
                                            <option >ANGIOLOGIA</option>
                                            <option >ANGIOLOGIA E CIRURGIA VASCULAR</option>
                                            <option >BRONCOESOFAGOLOGIA</option>
                                            <option >CANCEROLOGIA</option>
                                            <option >CANCEROLOGIA/CANCEROLOGIA CIRÚRGICA</option>
                                            <option >CANCEROLOGIA/CANCEROLOGIA PEDIÁTRICA</option>
                                            <option >CARDIOLOGIA</option>
                                            <option >CIRURGIA CARDIOVASCULAR</option>
                                            <option >CIRURGIA DA MÃO</option>
                                            <option >CIRURGIA DE CABEÇA E PESCOÇO</option>
                                            <option >CIRURGIA DIGESTIVA</option>
                                            <option >CIRURGIA DO APARELHO DIGESTIVO</option>
                                            <option >CIRURGIA DO TRAUMA</option>
                                            <option >CIRURGIA GASTROENTEROLÓGICA</option>
                                            <option >CIRURGIA GERAL</option>
                                            <option >CIRURGIA ONCOLÓGICA</option>
                                            <option >CIRURGIA PEDIÁTRICA</option>
                                            <option >CIRURGIA PLÁSTICA</option>
                                            <option >CIRURGIA TORÁCICA</option>
                                            <option >CIRURGIA TORÁXICA</option>
                                            <option >CIRURGIA VASCULAR</option>
                                            <option >CIRURGIA VASCULAR PERIFÉRICA</option>
                                            <option >CITOPATOLOGIA</option>
                                            <option >CLÍNICA MÉDICA</option>
                                            <option >COLOPROCTOLOGIA</option>
                                            <option >DENSITOMETRIA ÓSSEA</option>
                                            <option >DERMATOLOGIA</option>
                                            <option >DIAGNÓSTICO POR IMAGEM</option>
                                            <option >DOENÇAS INFECCIOSAS E PARASITÁRIAS</option>
                                            <option >ELETROENCEFALOGRAFIA</option>
                                            <option >ENDOCRINOLOGIA</option>
                                            <option >ENDOCRINOLOGIA E METABOLOGIA</option>
                                            <option >ENDOSCOPIA</option>
                                            <option >ENDOSCOPIA DIGESTIVA</option>
                                            <option >ENDOSCOPIA PERORAL</option>
                                            <option >ENDOSCOPIA PERORAL VIAS AÉREAS</option>
                                            <option >FISIATRIA</option>
                                            <option >FONIATRIA</option>
                                            <option >GASTROENTEROLOGIA</option>
                                            <option >GENÉTICA CLÍNICA</option>
                                            <option >GENÉTICA LABORATORIAL</option>
                                            <option >GENÉTICA MÉDICA</option>
                                            <option >GERIATRIA</option>
                                            <option >GERIATRIA E GERONTOLOGIA</option>
                                            <option >GINECOLOGIA</option>
                                            <option >GINECOLOGIA E OBSTETRÍCIA</option>
                                            <option >HANSENOLOGIA</option>
                                            <option >HEMATOLOGIA</option>
                                            <option >HEMATOLOGIA E HEMOTERAPIA</option>
                                            <option >HEMOTERAPIA</option>
                                            <option >HEPATOLOGIA</option>
                                            <option >HOMEOPATIA</option>
                                            <option >IMUNOLOGIA CLÍNICA</option>
                                            <option >INFECTOLOGIA</option>
                                            <option >INFORMÁTICA MÉDICA</option>
                                            <option >MASTOLOGIA</option>
                                            <option >MEDICINA DE EMERGÊNCIA</option>
                                            <option >MEDICINA DE FAMÍLIA E COMUNIDADE</option>
                                            <option >MEDICINA DE TRÁFEGO</option>
                                            <option >MEDICINA DO ADOLESCENTE</option>
                                            <option >MEDICINA DO ESPORTE</option>
                                            <option >MEDICINA DO TRABALHO</option>
                                            <option >MEDICINA ESPORTIVA</option>
                                            <option >MEDICINA FÍSICA E REABILITAÇÃO</option>
                                            <option >MEDICINA GERAL COMUNITÁRIA</option>
                                            <option >MEDICINA INTENSIVA</option>
                                            <option >MEDICINA INTERNA OU CLÍNICA MÉDICA</option>
                                            <option >MEDICINA LEGAL</option>
                                            <option >MEDICINA LEGAL E PERÍCIA MÉDICA</option>
                                            <option >MEDICINA NUCLEAR</option>
                                            <option >MEDICINA PREVENTIVA E SOCIAL</option>
                                            <option >MEDICINA SANITÁRIA</option>
                                            <option >NEFROLOGIA</option>
                                            <option >NEUROCIRURGIA</option>
                                            <option >NEUROFISIOLOGIA CLÍNICA</option>
                                            <option >NEUROLOGIA</option>
                                            <option >NEUROLOGIA PEDIÁTRICA</option>
                                            <option >NEUROPEDIATRIA</option>
                                            <option >NUTRIÇÃO PARENTERAL E ENTERAL</option>
                                            <option >NUTROLOGIA</option>
                                            <option >OBSTETRÍCIA</option>
                                            <option >OFTALMOLOGIA</option>
                                            <option >ONCOLOGIA</option>
                                            <option >ONCOLOGIA CLÍNICA</option>
                                            <option >ORTOPEDIA E TRAUMATOLOGIA</option>
                                            <option >OTORRINOLARINGOLOGIA</option>
                                            <option >PATOLOGIA</option>
                                            <option >PATOLOGIA CLÍNICA</option>
                                            <option >PATOLOGIA CLÍNICA/MEDICINA LABORATORIAL</option>
                                            <option >PEDIATRIA</option>
                                            <option >PNEUMOLOGIA</option>
                                            <option >PNEUMOLOGIA E TISIOLOGIA</option>
                                            <option >PROCTOLOGIA</option>
                                            <option >PSIQUIATRIA</option>
                                            <option >PSIQUIATRIA INFANTIL</option>
                                            <option >RADIODIAGNÓSTICO</option>
                                            <option >RADIOLOGIA</option>
                                            <option >RADIOLOGIA E DIAGNÓSTICO POR IMAGEM</option>
                                            <option >RADIOTERAPIA</option>
                                            <option >REUMATOLOGIA</option>
                                            <option >SEXOLOGIA</option>
                                            <option >TERAPIA INTENSIVA</option>
                                            <option >TERAPIA INTENSIVA PEDIÁTRICA</option>
                                            <option >TISIOLOGIA</option>
                                            <option >TOCO-GINECOLOGIA</option>
                                            <option >ULTRASSONOGRAFIA</option>
                                            <option >ULTRASSONOGRAFIA EM GINECOLOGIA E OBSTETRÍCIA</option>
                                            <option >ULTRASSONOGRAFIA GERAL</option>
                                            <option>UROLOGIA</option>
                                            <option>OUTRAS</option>
                                        </select>
                                        </div>


                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-6">

                                            <label for="inputCidMed">Cidade</label>
                                            <input type="text" id="inputCidMed" class="form-control" 
                                            name="cidCadastroMed"
                                            value="<?php echo $cidadeMedCard?>"
                                            placeholder="Digite aqui a cidade..." required>

                                        </div>

                                        <div class="form-group col-sm-4">

                                            <label for="estCadastroMed">Estado</label>
                                            <select id="estCadastroMed" 
                                            name="estCadastroMed"
                                            value="<?php echo $estadoMedCard?>"
                                            class="form-control" required>
                                                <option value ="">Escolha...</option>
                                                <option value="AC">Acre</option>
                                                <option value="AL">Alagoas</option>
                                                <option value="AP">Amapá</option>
                                                <option value="AM">Amazonas</option>
                                                <option value="BA">Bahia</option>
                                                <option value="CE">Ceará</option>
                                                <option value="DF">Distrito Federal</option>
                                                <option value="ES">Espírito Santo</option>
                                                <option value="GO">Goiás</option>
                                                <option value="MA">Maranhão</option>
                                                <option value="MT">Mato Grosso</option>
                                                <option value="MS">Mato Grosso do Sul</option>
                                                <option value="MG">Minas Gerais</option>
                                                <option value="PA">Pará</option>
                                                <option value="PB">Paraíba</option>
                                                <option value="PR">Paraná</option>
                                                <option value="PE">Pernambuco</option>
                                                <option value="PI">Piauí</option>
                                                <option value="RJ">Rio de Janeiro</option>
                                                <option value="RN">Rio Grande do Norte</option>
                                                <option value="RS">Rio Grande do Sul</option>
                                                <option value="RO">Rondônia</option>
                                                <option value="RR">Roraima</option>
                                                <option value="SC">Santa Catarina</option>
                                                <option value="SP">São Paulo</option>
                                                <option value="SE">Sergipe</option>
                                                <option value="TO">Tocantins</option>
                                            </select>

                                        </div>

                                        <div class="form-group col-sm-2">

                                            <label for="cepCadastroMed">CEP</label>
                                            <input type="text" id="cepCadastroMed" 
                                            name="cepCadastroMed"
                                            value="<?php echo $cepMedCard?>"
                                            placeholder="Digite aqui..." class="form-control"
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                            maxlength="8"
                                            required>

                                        </div>

                                    </div>

                                    <div class="form-row">

                                        <div class="form-group col-sm-12">
                                            <label for="emailCadastroMed">Email</label>
                                            <input type="email" class="form-control" id="emailCadastroMed" 
                                            name="emailCadastroMed"
                                            aria-describedby="emailHelpMed" placeholder="Digite aqui o email..."
                                            value="<?php echo $emailMedCard?>"
                                            required>
                                            <?php echo $emailSubTitle?>

                                            
                                        </div>
                                        
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-6 text-left">
                                            <label for="senhaCadastroMed">Senha</label>
                                            <input type="password" class="form-control" id="senhaCadastroMed"
                                            name="senhaCadastroMed"
                                            placeholder="Digite a senha..." 
                                            value="<?php echo $senhaMedCard?>" required>
                                        </div>
                                        
                                        <div class="form-group col-sm-6 text-left">
                                            <label for="senhaCadastroConfirmMed" >Confirmar Senha</label>
                                            <input type="password" class="form-control"  id="senhaCadastroConfirmMed" placeholder="Confirme a senha..." value="<?php echo $senhaMedCard?>" required>

                                            <small id="senhaIncorretaMed" class="form-text text-muted"> 
                                            </small>

                                        </div>

                                    </div>

                                    <div class="form-row justify-content-center">
                                        <div class="form-group">

                                        <input type="hidden" name="tipoCadastro" value="Medico"></input>

                                        <input type="submit" class="btn btn-success" id="continueButtonMed" data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                    </input>
                                        </div>
                                    </div>

                                    <script>
                                        document.getElementById("continueButtonMed").disabled=true;
                                        var senhaMed = document.getElementById("senhaCadastroMed");
                                        var senhaConfirmaMed = document.getElementById("senhaCadastroConfirmMed");

                                        checaSenha();


                                        function checaSenha(){
                                            if(senhaMed.value != senhaConfirmaMed.value){
                                                document.getElementById("senhaIncorretaMed").innerHTML = "Senha Incorreta";
                                                senhaConfirmaMed.setCustomValidity("Senha Incorreta!");
                                                document.getElementById("continueButtonMed").disabled=true;
                                            } else{
                                                senhaConfirmaMed.setCustomValidity("");
                                                document.getElementById("senhaIncorretaMed").innerHTML = "";
                                                document.getElementById("continueButtonMed").disabled=false;
                                            }
                                        }

                                        senhaMed.onchange = checaSenha;
                                        senhaConfirmaMed.onkeyup = checaSenha;
                                    </script>

                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade show <?php echo $statusFormLab?>" id="nav-item-02" role="tabpanel">

                        <div class="row justify-content-center mb-5">

                            <div class="col-sm-12">

                                <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                    <div class="form-row">

                                        <div class="form-group col-sm-12">

                                            <label for="nomeCadastroLab">Nome Completo:</label>
                                            <input type="text" class="form-control"
                                            name="nomeCadastroLab"
                                            value="<?php echo $nomeLabCard?>"
                                            id="nomeCadastroLab" placeholder="Digite aqui o nome completo..." required>

                                        </div>

                                    </div>
                                    <div class="form-row">

                                        <div class="form-group col-sm-12">

                                            <label for="endCadastroLab">Endereço</label>
                                            <input type="text" class="form-control"
                                            name="endCadastroLab"
                                            value="<?php echo $enderecoLabCard?>"
                                            id="endCadastroLab" placeholder="Digite aqui o endereço..." required>

                                        </div>

                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-4">
                                            <label for="telCadastroLab">Telefone</label>
                                            <input type="text" id="telCadastroLab" class="form-control" 
                                            name="telCadastroLab"
                                            value="<?php echo $telefoneLabCard?>"
                                            placeholder="Digite o telefone aqui..." required>

                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="cnpjCadastroLab">CNPJ</label>
                                            <input type="text" id="cnpjCadastroLab" class="form-control" 
                                            name="cnpjCadastroLab"
                                            placeholder="Digite o CNPJ aqui..."
                                            maxlength="14"
                                            value="<?php echo $cnpjLabCard?>"
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>

                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="inputExame">Tipo de Exame</label>
                                            <input type="text" id="inputExame"
                                            name="tipoExameCadastroLab"
                                            value="<?php echo $tipoExameLabCard?>"
                                            placeholder="Digite o tipo de exame aqui..." class="form-control" required>
                                        </div>


                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-6">

                                            <label for="inputCidLab">Cidade</label>
                                            <input type="text" id="inputCidLab" class="form-control" 
                                            name="cidCadastroLab"
                                            value="<?php echo $cidadeLabCard?>"
                                            placeholder="Digite aqui a cidade..." required>

                                        </div>

                                        <div class="form-group col-sm-4">

                                            <label for="cidCadastroLab">Estado</label>
                                            <select id="cidCadastroLab" class="form-control"
                                            value="<?php echo $estadoLabCard?>"
                                            name="estCadastroLab" required>
                                                <option value="">Escolha...</option>
                                                <option value="AC">Acre</option>
                                                <option value="AL">Alagoas</option>
                                                <option value="AP">Amapá</option>
                                                <option value="AM">Amazonas</option>
                                                <option value="BA">Bahia</option>
                                                <option value="CE">Ceará</option>
                                                <option value="DF">Distrito Federal</option>
                                                <option value="ES">Espírito Santo</option>
                                                <option value="GO">Goiás</option>
                                                <option value="MA">Maranhão</option>
                                                <option value="MT">Mato Grosso</option>
                                                <option value="MS">Mato Grosso do Sul</option>
                                                <option value="MG">Minas Gerais</option>
                                                <option value="PA">Pará</option>
                                                <option value="PB">Paraíba</option>
                                                <option value="PR">Paraná</option>
                                                <option value="PE">Pernambuco</option>
                                                <option value="PI">Piauí</option>
                                                <option value="RJ">Rio de Janeiro</option>
                                                <option value="RN">Rio Grande do Norte</option>
                                                <option value="RS">Rio Grande do Sul</option>
                                                <option value="RO">Rondônia</option>
                                                <option value="RR">Roraima</option>
                                                <option value="SC">Santa Catarina</option>
                                                <option value="SP">São Paulo</option>
                                                <option value="SE">Sergipe</option>
                                                <option value="TO">Tocantins</option>
                                            </select>

                                        </div>

                                        <div class="form-group col-sm-2">

                                            <label for="cepCadastroLab">CEP</label>
                                            <input type="text" id="cepCadastroLab" 
                                            name="cepCadastroLab"
                                            placeholder="Digite aqui..." class="form-control"
                                            value="<?php echo $cepLabCard?>"
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                            maxlength="8" required>

                                        </div>

                                    </div>

                                    <div class="form-row">

                                        <div class="form-group col-sm-12">
                                            <label for="emailCadastroLab">Email</label>
                                            <input type="email" class="form-control" id="emailCadastroLab" 
                                            name="emailCadastroLab"
                                            aria-describedby="emailHelpLab" placeholder="Digite aqui o email..." required
                                            value="<?php echo $emailLabCard?>">
                                            <?php echo $emailSubTitle?>

                                           
                                        </div>
                                        
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-6 text-left">
                                            <label for="senhaCadastroLab">Senha</label>
                                            <input type="password" class="form-control" id="senhaCadastroLab"
                                            name="senhaCadastroLab"
                                            placeholder="Digite a senha..." 
                                            value="<?php echo $senhaLabCard?>"
                                             required>
                                        </div>
                                        
                                        <div class="form-group col-sm-6 text-left">
                                            <label for="senhaCadastroConfirmLab" >Confirmar Senha</label>
                                            <input type="password" class="form-control"  id="senhaCadastroConfirmLab" placeholder="Confirme a senha..." value="<?php echo $senhaLabCard?>" required>

                                            <small id="senhaIncorretaLab" class="form-text text-muted"> 
                                            </small>

                                        </div>

                                    </div>

                                    <div class="form-row justify-content-center">
                                        <div class="form-group">
                                            <input type="hidden" name="tipoCadastro" value="Laboratorio"></input>

                                            <button type="submit" class="btn btn-success" 
                                            id="continueButtonLab"
                                            data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                                Enviar
                                            </button>
                                        </div>
                                    </div>

                                    <script>
                                        document.getElementById("continueButtonLab").disabled=true;
                                        var senhaLab = document.getElementById("senhaCadastroLab");
                                        var senhaConfirmaLab = document.getElementById("senhaCadastroConfirmLab");

                                        checaSenha();

                                        function checaSenha(){
                                            if(senhaLab.value != senhaConfirmaLab.value){
                                                document.getElementById("senhaIncorretaLab").innerHTML = "Senha Incorreta";
                                                senhaConfirmaLab.setCustomValidity("Senha Incorreta!");
                                                document.getElementById("continueButtonLab").disabled=true;
                                            } else{
                                                senhaConfirmaLab.setCustomValidity("");
                                                document.getElementById("senhaIncorretaLab").innerHTML = "";
                                                document.getElementById("continueButtonLab").disabled=false;
                                            }
                                        }

                                        senhaLab.onchange = checaSenha;
                                        senhaConfirmaLab.onkeyup = checaSenha;
                                    </script>


                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade show <?php echo $statusFormPac?>" id="nav-item-03" role="tabpanel">
                        <div class="row justify-content-center mb-5">

                            <div class="col-sm-12">

                                <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                    <div class="form-row">

                                        <div class="form-group col-sm-12">

                                            <label for="nomeCadastroPac">Nome Completo:</label>
                                            <input type="text" class="form-control" 
                                            name="nomeCadastroPac"
                                            value="<?php echo $nomePacCard?>"
                                            id="nomeCadastroPac" placeholder="Digite aqui o nome completo..." required>

                                        </div>

                                    </div>
                                    <div class="form-row">

                                        <div class="form-group col-sm-12">

                                            <label for="endCadastroPac">Endereço</label>
                                            <input type="text" class="form-control" 
                                            name="endCadastroPac"
                                            value="<?php echo $enderecoPacCard?>"
                                            id="endCadastroPac" placeholder="Digite aqui o endereço..." required>

                                        </div>

                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-4">
                                            <label for="telCadastroPac">Telefone</label>
                                            <input type="text" id="telCadastroPac"
                                            name="telCadastroPac"
                                            value="<?php echo $telefonePacCard?>"
                                            class="form-control" placeholder="Digite o telefone aqui..."
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                            

                                        </div>
                                        <div class="form-group col-sm-4">
                                            <label for="cpfCadastroPac">CPF</label>
                                            <input type="text" id="cpfCadastroPac" class="form-control"
                                            name="cpfCadastroPac"
                                            value="<?php echo $cpfPacCard?>"
                                            placeholder="Digite o CPF aqui..."
                                            maxlength="11"
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                            maxlength="11" required>

                                        </div>
                                        <div class="form-group col-sm-2">
                                            <label for="inputGenero">Genero</label>
                                            <select id="inputGenero" class="form-control"
                                            name="genCadastroPac" value="<?php echo $generoPacCard?>" required>
                                                <option value ="">Escolha...</option>
                                                <option value="M">Masculino</option>
                                                <option value="F">Feminino</option>
                                                <option value="O">Outros</option>
                                                <option value="IDK">Não Identificar</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-sm-2">
                                            <label for="inputIDade">Idade</label>
                                            <input type="text" id="inputIdade" placeholder="Idade" 
                                            name="idadeCadastroPac"
                                            value="<?php echo $idadePacCard?>"
                                            class="form-control"
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                        </div>


                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-6">

                                            <label for="cidCastroPac">Cidade</label>
                                            <input type="text" id="cidCadastroPac" class="form-control" 
                                            name="cidCadastroPac"
                                            value="<?php echo $cidadePacCard?>"
                                            placeholder="Digite aqui a cidade..." required>

                                        </div>

                                        <div class="form-group col-sm-4">

                                            <label for="estCadastroPac">Estado</label>
                                            <select id="estCadastroPac" class="form-control"
                                            value="<?php echo $estadoPacCard?>"
                                            name="estCadastroPac" required>
                                                <option value ="">Escolha...</option>
                                                <option value="AC">Acre</option>
                                                <option value="AL">Alagoas</option>
                                                <option value="AP">Amapá</option>
                                                <option value="AM">Amazonas</option>
                                                <option value="BA">Bahia</option>
                                                <option value="CE">Ceará</option>
                                                <option value="DF">Distrito Federal</option>
                                                <option value="ES">Espírito Santo</option>
                                                <option value="GO">Goiás</option>
                                                <option value="MA">Maranhão</option>
                                                <option value="MT">Mato Grosso</option>
                                                <option value="MS">Mato Grosso do Sul</option>
                                                <option value="MG">Minas Gerais</option>
                                                <option value="PA">Pará</option>
                                                <option value="PB">Paraíba</option>
                                                <option value="PR">Paraná</option>
                                                <option value="PE">Pernambuco</option>
                                                <option value="PI">Piauí</option>
                                                <option value="RJ">Rio de Janeiro</option>
                                                <option value="RN">Rio Grande do Norte</option>
                                                <option value="RS">Rio Grande do Sul</option>
                                                <option value="RO">Rondônia</option>
                                                <option value="RR">Roraima</option>
                                                <option value="SC">Santa Catarina</option>
                                                <option value="SP">São Paulo</option>
                                                <option value="SE">Sergipe</option>
                                                <option value="TO">Tocantins</option>
                                            </select>

                                        </div>

                                        <div class="form-group col-sm-2">

                                            <label for="cepCadastroPac">CEP</label>
                                            <input type="text" id="cepCadastroPac" 
                                            name="cepCadastroPac"
                                            placeholder="Digite aqui..." 
                                            value="<?php echo $cepPacCard?>"
                                            class="form-control"
                                            onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                            maxlength="8" required>

                                        </div>

                                    </div>

                                    <div class="form-row">

                                        <div class="form-group col-sm-12">
                                            <label for="emailCadastroPac">Email</label>
                                            <input type="email" class="form-control" id="emailCadastroPac" 
                                            name="emailCadastroPac"
                                            aria-describedby="emailHelpPac" placeholder="Digite aqui o email..." required
                                            value="<?php echo $emailPacCard?>" >
                                            <?php echo $emailSubTitle?>

                                        </div>
                                        
                                    </div>

                                    <div class="form-row">
                                        <div class="form-group col-sm-6 text-left">
                                            <label for="senhaCadastroPac">Senha</label>
                                            <input type="password" class="form-control" id="senhaCadastroPac"
                                            name="senhaCadastroPac" required placeholder="Digite a senha..."
                                            value="<?php echo $senhaPacCard?>">
                                        </div>
                                        
                                        <div class="form-group col-sm-6 text-left">
                                            <label for="senhaCadastroConfirmPac" >Confirmar Senha</label>
                                            <input type="password" class="form-control"  required id="senhaCadastroConfirmPac" placeholder="Confirme a senha..." value="<?php echo $senhaPacCard?>">

                                            <small id="senhaIncorretaPac" class="form-text text-muted"> 
                                            </small>

                                        </div>

                                    </div>
                                    
                                    <div class="form-row justify-content-center">
                                        <div class="form-group">
                                            <input type="hidden" name="tipoCadastro" value="Paciente"></input>

                                            <button type="submit" class="btn btn-success" 
                                            id="continueButtonPac"
                                            data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                                Enviar
                                            </button>
                                        </div>
                                    </div>

                                    <script>
                                        document.getElementById("continueButtonPac").disabled=true;
                                        var senhaPac = document.getElementById("senhaCadastroPac");
                                        var senhaConfirmaPac = document.getElementById("senhaCadastroConfirmPac");

                                        checaSenha();

                                        function checaSenha(){
                                            if(senhaPac.value != senhaConfirmaPac.value){
                                                document.getElementById("senhaIncorretaPac").innerHTML = "Senha Incorreta";
                                                senhaConfirmaPac.setCustomValidity("Senha Incorreta!");
                                                document.getElementById("continueButtonPac").disabled=true;
                                            } else{
                                                senhaConfirmaPac.setCustomValidity("");
                                                document.getElementById("senhaIncorretaPac").innerHTML = "";
                                                document.getElementById("continueButtonPac").disabled=false;
                                            }
                                        }

                                        senhaPac.onchange = checaSenha;
                                        senhaConfirmaPac.onkeyup = checaSenha;
                                    </script>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-6 mb-3 ">

                <nav id="navbarVertical" class="navbar navbar-light bg-light justify-content-center mb-3">
                    <ul class="nav nav-pills justify-content-center">
                        <li class="nav-item">
                            <a class="nav-link" href="#item1">Administradores</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#item2">Médicos</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#item3">Laboratórios</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#item4">Pacientes</a>
                        </li>

                    </ul>
                </nav>
            
                <div data-spy="scroll" data-target="#navbarVertical" data-offset="0" class="myscrollspySite justify-content-center text-center" style="height: 570px;">
                    
                    <h4 id="item1">Administradores</h4>
                    <hr>

                    <p>


                    <?php 
                        foreach($vetorCardsAdm as $chave=>$valor){
                            echo '<div class="row mt-1 mx-2 justify-content-center">';
                            echo "{$valor}";
                            echo '</div>';
                        }
                    ?>

                    </p>

                    <h4 id="item2">Médicos</h4>
                    <hr>
                    <p>
                        
                    <?php 
                        foreach($vetorCardsMed as $chave=>$valor){
                            echo '<div class="row mt-1 mx-2 justify-content-center">';
                            echo "{$valor}";
                            echo '</div>';
                        }
                    ?>
                    
                    </p>



                    <h4 id="item3">Laboratórios</h4>
                    <hr>
                    <p>

                    <?php 
                        foreach($vetorCardsLab as $chave=>$valor){
                            echo '<div class="row mt-1 mx-2 justify-content-center">';
                            echo "{$valor}";
                            echo '</div>';
                        }
                    ?>

                    </p>



                    <h4 id="item4">Pacientes</h4>
                    <hr>
                    <p>
                        
                    <?php 
                        foreach($vetorCardsPac as $chave=>$valor){
                            echo '<div class="row mt-1 mx-2 ">';
                            echo "{$valor}";
                            echo '</div>';
                        }
                    ?>

                    </p>


                </div>

            </div>

        </div>

    </div>

 
<!-- Footer -->
<div class="container">
        <div class="row mb-5">

            <div class="col-12 mb-3"><hr></div>

            <div class="col-sm-4" style="text-align: justify;">

                <h3>A LifePlan</h3>
                <p>Plano de saúde familiar e individual</p>
                <p>A LifePlan foi fundada em 2020 por 2 estudantes de engenharia da computação, Bryan Galani e Frederico Bender. A LifePlan visa proporcionar o plano de saúde ideal para voçe e sua familia, além de auxiliar o contato entre médico e paciente. Utilize nosso site para realizar consultas e exames. </p>

            </div>
            <div class="col-sm-4">
                <h3>Menu</h3>
                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="system.php">Sistema</a>

                    <a class="list-group-item list-group-item-action" href="plans.php">Planos</a>

                    <a class="list-group-item list-group-item-action" href="index.php#faleConosco">Fale Conosco</a>

                    <a class="list-group-item list-group-item-action" href="imp.php">Imprensa</a>
                </div>

            </div>
            <div class="col-sm-4">

                <h3>Social</h3>

                <div class="btn-group-vertical btn-block btn-group-lg" role="group">
                    <a class="btn btn-outline-success"  href="https://www.facebook.com/"><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>

                    <a class="btn btn-outline-success" href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a>

                    <a class="btn btn-outline-success" href="https://twitter.com/"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
                </div>


            </div>

            <div class="col-12 mt-5">

                <blockquote class="blockquote text-center">

                    <p class="mb-0">"Nada pior para a saúde que viver de aparências e fachadas. São pessoas com muito verniz e pouca raiz. Seu destino é a farmácia, o hospital, a dor."</p>
                    <footer class="blockquote-footer">Drauzio Varella <cite title="Source title">Médico, Cientista e Escritor</cite></footer>

                </blockquote>

            </div>

        </div>
    
    </div>

     <!-- Modal -->
    <div class="modal fade" id="siteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            

                <div class="modal-header">
                        <h4 class="modal-title w-100 text-center" >Login</h4>

                        <button type="button" class="close text-end" data-dismiss="modal" style="position: absolute; right: 15px;">
                            <span> &times; </span>
                        </button>    
                </div>

                <div class="modal-body">
                    
                   <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">
                        <div class="form-group mt-2">
                            <label for="emailLogin"><i class="fa fa-at" aria-hidden="true"></i> Email</label>
                            <input type="email" class="form-control" id="emailLogin" name="emailLoginMod" placeholder="Email">
                        </div>
                        <div class="form-group my-3">
                            <label for="senhaLogin"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Senha</label>
                            <input type="password" class="form-control" id="senhaLogin" name="senhaLoginMod"placeholder="Senha">
                        </div>

                        <div class="form-group text-center mb-2">
                            <button type="submit" class="btn btn-success " style="width:75px;">Entrar</button>
                            <?php echo $botaoSair?>  
                        </div>

                        <input type="submit" style="visibility: hidden; width: 0px; height:0px; text-align:right; position:absolute;" id="hiddenSubmit">

                        <script>
                            function logOut(){
                                document.getElementById("emailLogin").value = 'sairfurg00@furg.br';
                                document.getElementById("senhaLogin").value = 'sairfurg00';
                                document.getElementById("hiddenSubmit").click();
                            }   
                        </script>
                        <div class="form-group my-2">
                            <h5 class="text-center"> Status: <?php echo $_SESSION['statusLogado']?></h5>
                        </div>
                   </form>

                </div>

                <div class="modal-footer">
                    <a href="signUp.php" class="btn btn-success" type="button" role="button">Cadastrar</a>

                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                </div>

            </div>
        </div>
    </div>

    
    <!-- Optional JavaScript for bootstrap -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
        
    <script>0
        $(function () {
            $('[data-toggle="popover"]').popover()
        })
    </script>


</body>



</html>