function salvarPreCadastro(){
    var emailCadastro = $("input[name=emailCad]").val();
    $.post("signUpData",{emailCad: emailCadastro}, function(data){alert(data);
    
    
    })
    return false;
}

function redirectSignUp(){
    window.location.href = "./signUpData.php";
}
