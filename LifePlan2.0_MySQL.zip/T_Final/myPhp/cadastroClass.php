<?php

class Administrador{

    public $email, $senha;

    function __construct( $email,  $senha)
    {
       
        $this->email = $email; 
        $this->senha = $senha;
    }

    function __destruct()
    {
      //  echo "<br> Objeto destruido!";
    }

}

class Medico{

    public $nome, $cidade, $estado, $cep, $endereco, $telefone, $email, $especialidade, $crm, $senha;

    function __construct($nome, $cidade, $estado, $cep, $endereco, $telefone, $email, $especialidade, $crm, $senha)
    {
        $this->nome = $nome;
        $this->cidade = $cidade;
        $this->estado = $estado;
        $this->cep = $cep;
        $this->endereco = $endereco;
        $this->telefone = $telefone;
        $this->email = $email; 
        $this->especialidade = $especialidade;
        $this->crm = $crm;
        $this->senha = $senha;
    }

    function __destruct()
    {
       // echo "<br> Objeto destruido!";
    }

}

class Laboratorio{

    public $nome, $cidade, $estado, $cep, $endereco, $telefone, $email, $tipoExame, $cnpj, $senha;

    function __construct($nome, $cidade, $estado, $cep, $endereco, $telefone, $email, $tipoExame, $cnpj, $senha)
    {
        $this->nome = $nome;
        $this->cidade = $cidade;
        $this->estado = $estado;
        $this->cep = $cep;
        $this->endereco = $endereco;
        $this->telefone = $telefone;
        $this->email = $email; 
        $this->tipoExame = $tipoExame;
        $this->cnpj = $cnpj;
        $this->senha = $senha;
    }

    function __destruct()
    {
        //echo "<br> Objeto destruido!";
    }

}

class Paciente{

    public $nome, $cidade, $estado, $cep, $endereco, $telefone, $email, $genero, $idade, $cpf, $senha;

    function __construct($nome, $cidade, $estado, $cep, $endereco, $telefone, $email, $genero, $idade, $cpf, $senha)
    {
        $this->nome = $nome;
        $this->cidade = $cidade;
        $this->estado = $estado;
        $this->cep = $cep;
        $this->endereco = $endereco;
        $this->telefone = $telefone;
        $this->email = $email; 
        $this->genero = $genero;
        $this->idade = $idade;
        $this->cpf = $cpf;
        $this->senha = $senha;
    }

    function __destruct()
    {
        //echo "<br> Objeto destruido!";
    }



}

?>