<?php


function test_input($data){ //prepara o input no formato correto
    $data = trim($data); //remove espaços, tabs, etc..
    $data = stripslashes($data); //remove barra invertidaws
    $data = htmlspecialchars($data); //converte char especial em HTML codes
    return $data;
}


function save_preCadastro($email, $senha, $senhaConfirmada){
    $myFile = fopen("./bancoDados/preLogin.txt","w+") or die ("Falha na Criação");
    
    fwrite($myFile, "$email,$senha,$senhaConfirmada");

    fclose($myFile); 
}

?>