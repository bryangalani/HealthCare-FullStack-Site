<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css" >

    <!-- Meu estilo CSS-->
    <link rel = "stylesheet" href="myStyle/css/myPersonalStyles.css">

    <!-- Font-awesome -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">

    <!-- -->
    <script src="myJavascript/myInteractions.js"></script>

    <title>LifePlan</title>
</head>

<body>

    <!--Php-->
    <?php
        include 'myPhp/functions.php';
        session_start();

        if($_SERVER["REQUEST_METHOD"] == "POST"){

            //PDO - phpMyAdmin - SQL
            $server = "localhost:8889";
            $user = "bryan";
            $password = "admin";
            $db = "dados_lifeplan";

            try{
                //Criando conexão
                $db_connec = new PDO("mysql:host=$server", $user, $password);
                $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
                //Criando DB e Acessando
                $db_connec->exec("CREATE DATABASE IF NOT EXISTS $db");
                $db_connec =  new PDO("mysql:host=$server;dbname=$db", $user, $password);
                $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch(PDOException $e){
                    echo "Erro: " . $e1->getMessage();
            }


            $senhaLogin = $emailLogin = "";

            $emailLogin = test_input($_POST["emailLoginMod"]);
            $senhaLogin = test_input($_POST["senhaLoginMod"]);
            
            for($index = 0; $index <=3 ; $index++){
                switch($index){
                    case 0: //adm
                        $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                        if($result = $db_connec->query($sqlCheck)){
                            if($result->fetchColumn() > 0){                
                                $sqlCheck = "SELECT * FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                                $result = $db_connec->query($sqlCheck);


                                $_SESSION['statusLogado'] = "Administrador";
                                $_SESSION['profile'] = "profileAdm.php";
                                $index = 5; //quebra loop
                            break;
                            }
                        }  
                        break;
                    case 1: //med
                        
                        $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                        if($result = $db_connec->query($sqlCheck)){
                            if($result->fetchColumn() > 0){                
                                $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                                $result = $db_connec->query($sqlCheck);

                                $_SESSION['statusLogado'] = "Médico";
                                $_SESSION['profile'] = "profileMed.php";
                                $index = 5; //quebra loop
                            break;  
                            }
                        }
                        
                        break;
                    case 2: //lab
                        
                        $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                        if($result = $db_connec->query($sqlCheck)){
                            if($result->fetchColumn() > 0){
    
                                $sqlCheck = "SELECT * FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                                $result = $db_connec->query($sqlCheck);
                                
                                $_SESSION['statusLogado'] = "Laboratorio";
                                $_SESSION['profile'] = "profileLab.php";
                                $index = 5; //quebra loop
                                break;
                            }
                        }
                        
                        break;
                    case 3: //paciente
                        $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                        if($result = $db_connec->query($sqlCheck)){
                            if($result->fetchColumn() > 0)
                            {
                                $sqlCheck = "SELECT * FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                                $result = $db_connec->query($sqlCheck);

                                $_SESSION['statusLogado'] = "Paciente";
                                $_SESSION['profile'] = "profilePac.php";
                                break;

                            }else{
                                $_SESSION['statusLogado'] = "Visitante";
                                $_SESSION['profile'] = "signUp.php";
                            }
                        }
                        
                }
            }
            $_SESSION['emailLogado'] = $emailLogin;
        }

        if($_SESSION['statusLogado'] != "Visitante"){
            $botaoSair = '<button type="button" id="botaoSair"class="btn btn-danger" style="width:75px;" onclick="logOut()">Sair</button>';
        }else{
            $botaoSair = "";
            $_SESSION['emailLogado'] = "";
        }

        if($_SESSION['statusLogado'] == "Administrador"){
            $_SESSION['profile'] = "profileAdm.php";
        }else if($_SESSION['statusLogado'] == "Médico"){
            $_SESSION['profile'] = "profileMed.php";
        }else if($_SESSION['statusLogado'] == "Laboratorio"){
            $_SESSION['profile'] = "profileLab.php";
        }else if($_SESSION['statusLogado'] == "Paciente"){
            $_SESSION['profile'] = "profilePac.php";
        }else{
            $_SESSION['profile'] = "signUp.php";
        }

    ?>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success" id="home">

        <div class="container">

            <a class="navbar-brand h1 mb-0" href="index.php"><i class="fa fa-heartbeat text-ligth" aria-hidden="true"></i> LifePlan</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSite">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="system.php">Sistema</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#faleConosco">Fale conosco</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="imp.php">Imprensa</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="navDrop" >
                            Social
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="https://www.facebook.com/">Facebook</a>
                            <a class="dropdown-item" href="https://www.instagram.com/">Instagram</a>
                            <a class="dropdown-item" href="https://twitter.com/">Twitter</a>
                        </div>
                    </li>
                   

                    <li class="nav-item mr-4">
                        <a type="button" class="nav-link" href="<?php echo $_SESSION['profile']?>"> Perfil <?php echo $_SESSION['statusLogado']?></a>
                    </li>
                </ul>

                <form class="form-inline">                    
                    <button type="button" class="btn btn-light" data-toggle="modal" data-target="#siteModal">Login</button>
                </form>

            </div>
        </div>
    </nav>

    <!-- Carousel -->
    <div id="carouselSite" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
            <li data-target="#carouselSite" data-slide-to="1"></li>
            <li data-target="#carouselSite" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/carousel_01.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_02.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_03.jpg" class="img-fluid d-block w
                -100">
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Posterior</span>
        </a>

    </div>



    <!-- Conteudo -->
    <div class="container">

        <div class="row">

            <div class="col-12 text-center mt-5" id="sistema">
                <h1 class="display-4">Planos LifePlan</h1>
                <p>Plano de saúde familiar e individual.</p>
        </div>

         <!-- ScrollSpy -->
        <div class="row mb-5">

            <div class="col-sm-6 col-md-4 mb-3">

                <nav id="navbarVertical" class="navbar navbar-light  bg-light">
                    <nav class="nav nav-pills flex-column ">
                        
                        <a class="nav-link" href="#item1">Plano Econômico</a>
                        
                        <nav class="nav nav-pills flex-column">

                            <a class="nav-link ml-3" href="#item1-1">Individual</a>
                            
                            <a class="nav-link ml-3" href="#item1-2">Familiar</a>

                        </nav>

                        <a class="nav-link mt-2" href="#item2">Plano Medium</a>

                        <a class="nav-link mt-2" href="#item3">Plano Premium</a>

                    </nav>

                </nav>

            </div>

        <div class="col-sm-6 col-md-8 ">

            <div data-spy="scroll" data-target="#navbarVertical" data-offset="0" class="myscrollspySite">
                
                <h4 id="item1">Plano Econômico</h4>
                <p>O plano econômico foi feito para você que quer pagar menos e alcançar mais. Nosso plano econômico pode ser feito individualmente ou para toda familia. Este plano cobre 50% de suas dispesas médicas em consultórios e laboratórios afiliados, ou seja, você pagará metade do preço em suas consultas e exames por um preço bem acessivel. </p>

                <h5 id="item1-1">Individual</h5>
                <p>O plano indivual pode ser realizado e cancelado a qualquer momento, porém o plano só libera o desconto de 50% após 25 dias de afiliação, evitando o mal uso de nossos beneficios. Assim que o plano for cancelado, o usuario ainda pode utiliza-lo por 20 dias!</p>

                <h5 id="item1-2">Familiar</h5>
                <p>O plano familiar assim como o individual pode ser realizado e cancelado a qualquer momento, porém o plano só libera o desconto de 50% após 25 dias de afiliação, evitando o mal uso de nossos beneficios. Assim que o plano for cancelado, sua familia ainda pode utiliza-lo por 20 dias! Os preços variam de acordo com o número de integrantes da familia, favor consultar preço em nosso departamento.</p>

                <h4 id="item2">Plano Medium</h4>
                <p>O plano medium cobre 75% de suas dispesas médicas em consultórios e laboratórios afiliados, ou seja, você pagará menos da metade do preço em suas consultas e exames por um preço justo. Além de concorrer todos mês por um plano premium sem acréscimo do preço! </p>

                <h4 id="item3">Plano Premium</h4>
                <p>O plano premium cobre 100% de suas dispesas médicas em consultórios e laboratórios afiliados, ou seja, você não pagará nada em suas consultas e exames. Além disso, você concorre a descontos especiais em lojas parceiras, desde medicamentos medicinais, tratamentos homeopaticos, fisioterapia, massagem relaxante, entre outros. Este plano entrega o melhor custo beneficio para você e sua familia.</p>

            </div>

        </div>
        </div>


        <div class="row">
            <div class="col-md-6">
                <figure class="figure">
                    <img src="images/plans_01.jpg" class="figure-img img-fluid rounded" alt="...">
                </figure>
            </div>

            <div class="col-md-6">
                <figure class="figure">
                    <img src="images/plans_02.jpg" class="figure-img img-fluid rounded" alt="...">
                </figure>
            </div>
        </div>

        

        <div class="row">
            <div class="col-md-6">
                <figure class="figure">
                    <img src="images/plans_03.jpg" class="figure-img img-fluid rounded" alt="...">
                </figure>
            </div>

            <div class="col-md-6">
                <figure class="figure">
                    <img src="images/plans_04.jpg" class="figure-img img-fluid rounded" alt="...">
                </figure>
            </div>
        </div>

    </div>






<!-- Footer -->
<div class="container">
        <div class="row mb-5">

            <div class="col-12 mb-3"><hr></div>

            <div class="col-sm-4" style="text-align: justify;">

                <h3>A LifePlan</h3>
                <p>Plano de saúde familiar e individual</p>
                <p>A LifePlan foi fundada em 2020 por 2 estudantes de engenharia da computação, Bryan Galani e Frederico Bender. A LifePlan visa proporcionar o plano de saúde ideal para voçe e sua familia, além de auxiliar o contato entre médico e paciente. Utilize nosso site para realizar consultas e exames. </p>

            </div>
            <div class="col-sm-4">
                <h3>Menu</h3>
                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="system.php">Sistema</a>

                    <a class="list-group-item list-group-item-action" href="plans.php">Planos</a>

                    <a class="list-group-item list-group-item-action" href="index.php#faleConosco">Fale Conosco</a>

                    <a class="list-group-item list-group-item-action" href="imp.php">Imprensa</a>
                </div>

            </div>
            <div class="col-sm-4">

                <h3>Social</h3>

                <div class="btn-group-vertical btn-block btn-group-lg" role="group">
                    <a class="btn btn-outline-success"  href="https://www.facebook.com/"><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>

                    <a class="btn btn-outline-success" href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a>

                    <a class="btn btn-outline-success" href="https://twitter.com/"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
                </div>


            </div>

            <div class="col-12 mt-5">

                <blockquote class="blockquote text-center">

                    <p class="mb-0">"Nada pior para a saúde que viver de aparências e fachadas. São pessoas com muito verniz e pouca raiz. Seu destino é a farmácia, o hospital, a dor."</p>
                    <footer class="blockquote-footer">Drauzio Varella <cite title="Source title">Médico, Cientista e Escritor</cite></footer>

                </blockquote>

            </div>

        </div>
    
    </div>


     <!-- Modal -->
    <div class="modal fade" id="siteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            

                <div class="modal-header">
                        <h4 class="modal-title w-100 text-center" >Login</h4>

                        <button type="button" class="close text-end" data-dismiss="modal" style="position: absolute; right: 15px;">
                            <span> &times; </span>
                        </button>    
                </div>

                <div class="modal-body">
                    
                   <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">
                        <div class="form-group mt-2">
                            <label for="emailLogin"><i class="fa fa-at" aria-hidden="true"></i> Email</label>
                            <input type="email" class="form-control" id="emailLogin" name="emailLoginMod" placeholder="Email">
                        </div>
                        <div class="form-group my-3">
                            <label for="senhaLogin"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Senha</label>
                            <input type="password" class="form-control" id="senhaLogin" name="senhaLoginMod"placeholder="Senha">
                        </div>

                        <div class="form-group text-center mb-2">
                            <button type="submit" class="btn btn-success " style="width:75px;">Entrar</button>
                            <?php echo $botaoSair?>  
                        </div>

                        <input type="submit" style="visibility: hidden; width: 0px; height:0px; text-align:right; position:absolute;" id="hiddenSubmit">

                        <script>
                            function logOut(){
                                document.getElementById("emailLogin").value = 'sairfurg00@furg.br';
                                document.getElementById("senhaLogin").value = 'sairfurg00';
                                document.getElementById("hiddenSubmit").click();
                            }   
                        </script>
                        <div class="form-group my-2">
                            <h5 class="text-center"> Status: <?php echo $_SESSION['statusLogado']?></h5>
                        </div>
                   </form>

                </div>

                <div class="modal-footer">
                    <a href="signUp.php" class="btn btn-success" type="button" role="button">Cadastrar</a>

                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                </div>

            </div>
        </div>
    </div>

    
    <!-- Optional JavaScript for bootstrap -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
        
    <script>0
        $(function () {
            $('[data-toggle="popover"]').popover()
        })
    </script>


</body>



</html>