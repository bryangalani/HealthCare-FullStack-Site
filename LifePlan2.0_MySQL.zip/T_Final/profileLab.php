<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css" >

    <!-- Meu estilo CSS-->
    <link rel = "stylesheet" href="myStyle/css/myPersonalStyles.css">

    <!-- Font-awesome -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">

    <!-- Meu Javascript -->
    <script src="myJavascript/myInteractions.js"></script>
    
    <title>LifePlan</title>
  </head>
  <body>

      <!-- PHP -->
      <?php
        include 'myPhp/functions.php';
        session_start();

        if($_SESSION['statusLogado'] != "Laboratorio"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }


          //PDO - phpMyAdmin - SQL
          $server = "localhost:8889";
          $user = "bryan";
          $password = "admin";
          $db = "dados_lifeplan";
  
          try{
              //Criando conexão
              $db_connec = new PDO("mysql:host=$server", $user, $password);
              $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      
              //Criando DB e Acessando
              $db_connec->exec("CREATE DATABASE IF NOT EXISTS $db");
              $db_connec =  new PDO("mysql:host=$server;dbname=$db", $user, $password);
              $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          }catch(PDOException $e){
                  echo "Erro: " . $e1->getMessage();
          }

        $jaCadastrado = false;
        $emailSubTitle = '';
        $senhaLogin = $emailLogin = "";


        if($_SERVER["REQUEST_METHOD"] == "POST"){

            $statusCadastro = "";
            $statusSubCadastro = "";

            $emailLogin = test_input($_POST["emailLoginMod"]);
            $senhaLogin = test_input($_POST["senhaLoginMod"]);

            if($senhaLogin == "" && $emailLogin == ""){


                $emailLab_tempLogado = $_SESSION['emailLogado'];
                $sqlFind_lab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLab_tempLogado' ";
                if($result = $db_connec->query($sqlFind_lab)){
                    if($result->fetchColumn() > 0){
            
                        //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                        $emailForm = $_POST['emailCadastroLab'];
                        $sqlCheckEmail_lab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailForm'";
            
                        if($result_temp = $db_connec->query($sqlCheckEmail_lab)){
                            if($result_temp->fetchColumn() > 0 && $_SESSION['emailLogado'] != $_POST['emailCadastroLab'] ) {
                                $jaCadastrado = true;
                            }
                        }
                        if(!$jaCadastrado){

                            $resultC = $db_connec->query("SELECT * FROM laboratorios WHERE email = '$emailLab_tempLogado' ");
                            $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                            $cnpjTeste = $rows['cnpj'];
                            
                            $sqlUpdate_lab = "UPDATE laboratorios SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?, email=?, tipoExame=?, cnpj=?, senha=? WHERE email = '$emailLab_tempLogado' ";
            
                            $cnpjLab_temp = $_POST['cnpjCadastroLab']; 
                            $sqlCheck3 = "SELECT cnpj FROM laboratorios WHERE cnpj = '$cnpjLab_temp' ";
                            $result3 = $db_connec->query($sqlCheck3);
            
                            if($result3->fetchColumn() > 0 && $cnpjTeste != $_POST['cnpjCadastroLab']){
                                $statusCadastro = " <b> Negado. </b>";
                                $statusSubCadastro = "CNPJ do Laboartório <b> " . $emailLab .  " </b> já cadastrado!";
                            }else{
                            $stmt = $db_connec->prepare($sqlUpdate_lab);
                            $stmt->execute(
                                array
                                (
                                    $_POST['nomeCadastroLab'],
                                    $_POST['cidCadastroLab'],
                                    $_POST['estCadastroLab'],
                                    $_POST['cepCadastroLab'],
                                    $_POST['endCadastroLab'],
                                    $_POST['telCadastroLab'],
                                    $_POST['emailCadastroLab'],
                                    $_POST['tipoExameCadastroLab'],
                                    $_POST['cnpjCadastroLab'],
                                    $_POST['senhaCadastroLab']
                                )
                            );
            
                            $_SESSION['emailLogado'] = $_POST['emailCadastroLab'];   
            
                            $statusCadastro = "<b> Confirmado. </b>";
                            $statusSubCadastro = "Alteração realizada!";
            
                            }
                        }else{
                            $statusCadastro = "<b> Negado. </b>";
                            $statusSubCadastro = "Email indisponivel!";
                            $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                        }
                    }
                }



            }else{

                if($senhaLogin == "sairfurg00" && $emailLogin == "sairfurg00@furg.br"){
                   $senhaLogin = '';
                   $emailLogin = '';
                }
                $redirect = '';
                for($index = 0; $index <=3 ; $index++){
                    switch($index){
                        case 0: //adm
                            $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0){                
                                    $redirect ="
                                    <script> 
                                    window.location.href = './profileAdm.php';
                                    </script>";
    
                                    $_SESSION['statusLogado'] = "Administrador";
                                    $_SESSION['profile'] = "profileAdm.php";
                                    $index = 5; //quebra loop
                                break;
                                }
                            }  
                            break;
                        case 1: //med
                            
                            $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0){                
                                    $_SESSION['statusLogado'] = "Médico";
                                    $_SESSION['profile'] = "profileMed.php";
                                    
                                    $redirect ="
                                     <script> 
                                     window.location.href = './profileMed.php';
                                     </script>";
                                    $index = 5; //quebra loop
                                break;  
                                }
                            }
                            
                            break;
                        case 2: //lab
                            
                            $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0){
                                    
                                    $_SESSION['statusLogado'] = "Laboratorio";
                                    $_SESSION['profile'] = "profileLab.php";


                                    $index = 5; //quebra loop
                                    break;
                                }
                            }
                            
                            break;
                        case 3: //paciente
                            $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0)
                                {
    
                                    $_SESSION['statusLogado'] = "Paciente";
                                    $_SESSION['profile'] = "profilePac.php";
                                    $redirect ="
                                     <script> 
                                     window.location.href = './profilePac.php';
                                     </script>";
                                    break;
    
                                }else{
                                    $_SESSION['statusLogado'] = "Visitante";
                                    $_SESSION['profile'] = "signUp.php";
                                    $redirect ="
                                     <script> 
                                     window.location.href = './signUp.php';
                                     </script>";
                                }
                            }
                            
                    }
                }
                $_SESSION['emailLogado'] = $emailLogin;
                echo $redirect;
            }
        }
        
        //Mostrar dados atuais na tela
        $emailSessao =  $_SESSION['emailLogado'];
        $sqlGetInfo_labAtual = "SELECT * FROM laboratorios WHERE email = '$emailSessao' ";

        $labLogado = $db_connec->query($sqlGetInfo_labAtual);

        $labLogadoInfo = $labLogado->fetch(PDO::FETCH_ASSOC);

        $nomeLab = test_input($labLogadoInfo['nome']);
        $cidadeLab = test_input($labLogadoInfo['cidade']);
        $estadoLab = test_input($labLogadoInfo['estado']);
        $cepLab = test_input($labLogadoInfo['cep']);
        $enderecoLab = test_input($labLogadoInfo['endereco']);
        $telefoneLab = test_input($labLogadoInfo['telefone']);
        $emailLab = test_input($labLogadoInfo['email']);
        $tipoExameLab = test_input($labLogadoInfo['tipoExame']);
        $cnpjLab = test_input($labLogadoInfo['cnpj']);
        $senhaLab = test_input($labLogadoInfo['senha']);

        if($_SESSION['statusLogado'] != "Visitante"){
            $botaoSair = '<button type="button" id="botaoSair"class="btn btn-danger" style="width:75px;" onclick="logOut()">Sair</button>';
        }else{
            $botaoSair = "";
            $_SESSION['emailLogado'] = "";
        }

        if($_SESSION['statusLogado'] == "Administrador"){
            $_SESSION['profile'] = "profileAdm.php";
        }else if($_SESSION['statusLogado'] == "Médico"){
            $_SESSION['profile'] = "profileMed.php";
        }else if($_SESSION['statusLogado'] == "Laboratorio"){
            $_SESSION['profile'] = "profileLab.php";
        }else if($_SESSION['statusLogado'] == "Paciente"){
            $_SESSION['profile'] = "profilePac.php";
        }else{
            $_SESSION['profile'] = "signUp.php";
        }
    
        if($_SESSION['statusLogado'] != "Laboratorio"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }
    ?>


    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success" id="home">

        <div class="container">

            <a class="navbar-brand h1 mb-0" href="index.php"><i class="fa fa-heartbeat text-ligth" aria-hidden="true"></i> LifePlan</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSite">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="system.php">Sistema</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#faleConosco">Fale conosco</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="imp.php">Imprensa</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="navDrop" >
                            Social
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="https://www.facebook.com/">Facebook</a>
                            <a class="dropdown-item" href="https://www.instagram.com/">Instagram</a>
                            <a class="dropdown-item" href="https://twitter.com/">Twitter</a>
                        </div>
                    </li>
                   

                    <li class="nav-item mr-4">
                        <a type="button" class="nav-link" href="<?php echo $_SESSION['profile']?>"> Perfil <?php echo $_SESSION['statusLogado']?></a>
                    </li>
                </ul>

                <form class="form-inline">                    
                    <button type="button" class="btn btn-light" data-toggle="modal" data-target="#siteModal">Login</button>
                </form>

            </div>
        </div>
    </nav>

    <!-- Carousel -->
    <div id="carouselSite" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
            <li data-target="#carouselSite" data-slide-to="1"></li>
            <li data-target="#carouselSite" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/carousel_01.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_02.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_03.jpg" class="img-fluid d-block w
                -100">
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Posterior</span>
        </a>

    </div>



    
    <!-- Conteudo -->
    <div class="container">

        <div class="row">

            <div class="col-12 text-center mt-5" id="sistema">
                <h1 class="display-4"><i class="fa fa-hospital-o text-success" aria-hidden="true"></i> Perfil <?php echo $_SESSION['statusLogado']?></h1>
                <p>Usuário: <?php echo $_SESSION['emailLogado'] . "<br>" . $statusCadastro . $statusSubCadastro?></p>
            </div>

        </div>

        <div class="row">
            <div class="col-sm-6" style="text-align: justify;">
                <h3><i class="fa fa-pencil text-success" aria-hidden="true"></i> Cadastro e Histórico de Exames</h3>
                <p>Como um laboratório, você pode cadastrar exames e inspecionar o histórico de exames realizados.</p>

                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="signUpExam.php"> Cadastro</a>
                    <a class="list-group-item list-group-item-action" href="signUpExam.php"> Histórico de Exames</a>
                
                </div>
            </div>

            <div class="col-sm-6">
                <h3><i class="fa fa-address-card-o text-success" aria-hidden="true"></i> Alterar Informações Pessoais</h3>
                 
                <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="nomeCadastroLab">Nome Completo:</label>
                                                <input type="text" class="form-control"
                                                name="nomeCadastroLab"
                                                id="nomeCadastroLab" placeholder="Digite aqui o nome completo..." value="<?php echo $nomeLab?>" required>

                                            </div>

                                        </div>
                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="endCadastroLab">Endereço</label>
                                                <input type="text" class="form-control"
                                                name="endCadastroLab"
                                                id="endCadastroLab" placeholder="Digite aqui o endereço..." value="<?php echo $enderecoLab?>" required>

                                            </div>

                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-4">
                                                <label for="telCadastroLab">Telefone</label>
                                                <input type="text" id="telCadastroLab" class="form-control" 
                                                name="telCadastroLab"
                                                placeholder="Digite o telefone aqui..." value="<?php echo $telefoneLab?>" required>

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="cnpjCadastroLab">CNPJ</label>
                                                <input type="text" id="cnpjCadastroLab" class="form-control" 
                                                name="cnpjCadastroLab"
                                                placeholder="Digite o CNPJ aqui..."
                                                maxlength="14"
                                                value="<?php echo $cnpjLab?>"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="inputExame">Tipo de Exame</label>
                                                <input type="text" id="inputExame"
                                                name="tipoExameCadastroLab"
                                                value="<?php echo $tipoExameLab?>"
                                                placeholder="Digite o tipo de exame aqui..." class="form-control" required>
                                            </div>


                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6">

                                                <label for="inputCidLab">Cidade</label>
                                                <input type="text" id="inputCidLab" class="form-control" 
                                                name="cidCadastroLab"
                                                value="<?php echo $cidadeLab?>"
                                                placeholder="Digite aqui a cidade..." required>

                                            </div>

                                            <div class="form-group col-sm-4">

                                                <label for="cidCadastroLab">Estado</label>
                                                <select id="cidCadastroLab" class="form-control"
                                                name="estCadastroLab" 
                                                value="<?php echo $estadoLab?>" required>
                                                    <option value="">Escolha...</option>
                                                    <option value="AC">Acre</option>
                                                    <option value="AL">Alagoas</option>
                                                    <option value="AP">Amapá</option>
                                                    <option value="AM">Amazonas</option>
                                                    <option value="BA">Bahia</option>
                                                    <option value="CE">Ceará</option>
                                                    <option value="DF">Distrito Federal</option>
                                                    <option value="ES">Espírito Santo</option>
                                                    <option value="GO">Goiás</option>
                                                    <option value="MA">Maranhão</option>
                                                    <option value="MT">Mato Grosso</option>
                                                    <option value="MS">Mato Grosso do Sul</option>
                                                    <option value="MG">Minas Gerais</option>
                                                    <option value="PA">Pará</option>
                                                    <option value="PB">Paraíba</option>
                                                    <option value="PR">Paraná</option>
                                                    <option value="PE">Pernambuco</option>
                                                    <option value="PI">Piauí</option>
                                                    <option value="RJ">Rio de Janeiro</option>
                                                    <option value="RN">Rio Grande do Norte</option>
                                                    <option value="RS">Rio Grande do Sul</option>
                                                    <option value="RO">Rondônia</option>
                                                    <option value="RR">Roraima</option>
                                                    <option value="SC">Santa Catarina</option>
                                                    <option value="SP">São Paulo</option>
                                                    <option value="SE">Sergipe</option>
                                                    <option value="TO">Tocantins</option>
                                                </select>
                                                <small class="text-muted">*Selecione novamente</small>

                                            </div>

                                            <div class="form-group col-sm-2">

                                                <label for="cepCadastroLab">CEP</label>
                                                <input type="text" id="cepCadastroLab" 
                                                name="cepCadastroLab"
                                                placeholder="Digite..."
                                                value="<?php echo $cepLab?>"
                                                class="form-control"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="8" required>

                                            </div>

                                        </div>

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">
                                                <label for="emailCadastroLab">Email</label>
                                                <input type="email" class="form-control" id="emailCadastroLab" 
                                                name="emailCadastroLab"
                                                aria-describedby="emailHelpLab" placeholder="Digite aqui o email..." required
                                                value= "<?php echo $emailLab?>">
                                                <?php echo $emailSubTitle?>
                                            </div>
                                            
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroLab">Senha</label>
                                                <input type="text" class="form-control" id="senhaCadastroLab"
                                                name="senhaCadastroLab"
                                                placeholder="Digite a senha..." 
                                                value= "<?php echo $senhaLab ?>" required>
                                            </div>
                                            
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroConfirmLab" >Confirmar Senha</label>
                                                <input type="password" class="form-control"  id="senhaCadastroConfirmLab" placeholder="Confirme a senha..." value= "<?php echo $senhaLab?>" required>

                                                <small id="senhaIncorretaLab" class="form-text text-muted"> 
                                                </small>

                                            </div>

                                        </div>

                                        <div class="form-row justify-content-center">
                                            <div class="form-group">
                                                <input type="hidden" name="tipoCadastro" value="Laboratorio"></input>

                                                <button type="submit" class="btn btn-success" 
                                                id="continueButtonLab"
                                                data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                                    Enviar
                                                </button>
                                            </div>
                                        </div>

                                        <script>
                                            document.getElementById("continueButtonLab").disabled=true;
                                            var senhaLab = document.getElementById("senhaCadastroLab");
                                            var senhaConfirmaLab = document.getElementById("senhaCadastroConfirmLab");

                                            checaSenha();

                                            function checaSenha(){
                                                if(senhaLab.value != senhaConfirmaLab.value){
                                                    document.getElementById("senhaIncorretaLab").innerHTML = "Senha Incorreta";
                                                    senhaConfirmaLab.setCustomValidity("Senha Incorreta!");
                                                    document.getElementById("continueButtonLab").disabled=true;
                                                } else{
                                                    senhaConfirmaLab.setCustomValidity("");
                                                    document.getElementById("senhaIncorretaLab").innerHTML = "";
                                                    document.getElementById("continueButtonLab").disabled=false;
                                                }
                                            }

                                            senhaLab.onchange = checaSenha;
                                            senhaConfirmaLab.onkeyup = checaSenha;
                                        </script>


                                    </form>


            </div>
        </div>
        
<!-- Footer -->
<div class="container">
        <div class="row mb-5">

            <div class="col-12 mb-3"><hr></div>

            <div class="col-sm-4" style="text-align: justify;">

                <h3>A LifePlan</h3>
                <p>Plano de saúde familiar e individual</p>
                <p>A LifePlan foi fundada em 2020 por 2 estudantes de engenharia da computação, Bryan Galani e Frederico Bender. A LifePlan visa proporcionar o plano de saúde ideal para voçe e sua familia, além de auxiliar o contato entre médico e paciente. Utilize nosso site para realizar consultas e exames. </p>

            </div>
            <div class="col-sm-4">
                <h3>Menu</h3>
                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="system.php">Sistema</a>

                    <a class="list-group-item list-group-item-action" href="plans.php">Planos</a>

                    <a class="list-group-item list-group-item-action" href="index.php#faleConosco">Fale Conosco</a>

                    <a class="list-group-item list-group-item-action" href="imp.php">Imprensa</a>
                </div>

            </div>
            <div class="col-sm-4">

                <h3>Social</h3>

                <div class="btn-group-vertical btn-block btn-group-lg" role="group">
                    <a class="btn btn-outline-success"  href="https://www.facebook.com/"><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>

                    <a class="btn btn-outline-success" href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a>

                    <a class="btn btn-outline-success" href="https://twitter.com/"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
                </div>


            </div>

            <div class="col-12 mt-5">

                <blockquote class="blockquote text-center">

                    <p class="mb-0">"Nada pior para a saúde que viver de aparências e fachadas. São pessoas com muito verniz e pouca raiz. Seu destino é a farmácia, o hospital, a dor."</p>
                    <footer class="blockquote-footer">Drauzio Varella <cite title="Source title">Médico, Cientista e Escritor</cite></footer>

                </blockquote>

            </div>

        </div>
    
    </div>
    

    <!-- Modal -->
    <div class="modal fade" id="siteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            

                <div class="modal-header">
                        <h4 class="modal-title w-100 text-center" >Login</h4>

                        <button type="button" class="close text-end" data-dismiss="modal" style="position: absolute; right: 15px;">
                            <span> &times; </span>
                        </button>    
                </div>

                <div class="modal-body">
                    
                   <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">
                        <div class="form-group mt-2">
                            <label for="emailLogin"><i class="fa fa-at" aria-hidden="true"></i> Email</label>
                            <input type="email" class="form-control" id="emailLogin" name="emailLoginMod" placeholder="Email">
                        </div>
                        <div class="form-group my-3">
                            <label for="senhaLogin"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Senha</label>
                            <input type="password" class="form-control" id="senhaLogin" name="senhaLoginMod"placeholder="Senha">
                        </div>

                        <div class="form-group text-center mb-2">
                            <button type="submit" class="btn btn-success " style="width:75px;">Entrar</button>
                            <?php echo $botaoSair?>  
                        </div>

                        <input type="submit" style="visibility: hidden; width: 0px; height:0px; text-align:right; position:absolute;" id="hiddenSubmit">

                        <script>
                            function logOut(){
                                document.getElementById("emailLogin").value = 'sairfurg00@furg.br';
                                document.getElementById("senhaLogin").value = 'sairfurg00';
                                document.getElementById("hiddenSubmit").click();
                            }   
                        </script>
                        <div class="form-group my-2">
                            <h5 class="text-center"> Status: <?php echo $_SESSION['statusLogado']?></h5>
                        </div>
                   </form>

                </div>

                <div class="modal-footer">
                    <a href="signUp.php" class="btn btn-success" type="button" role="button">Cadastrar</a>

                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                </div>

            </div>
        </div>
    </div>

        


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>

    <script>

        $(function () {

            $('[data-toggle="popover"]').popover()

        })

    </script>

</body>



</html>