<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css" >

    <!-- Meu estilo CSS-->
    <link rel = "stylesheet" href="myStyle/css/myPersonalStyles.css">

    <!-- Font-awesome -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">

    <!-- Meu Javascript -->
    <script src="myJavascript/myInteractions.js"></script>
    
    <title>LifePlan</title>
  </head>
  <body>

     <!-- PHP -->
     <?php
        include 'myPhp/functions.php';
        session_start();

        if($_SESSION['statusLogado'] != "Médico"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }

          //PDO - phpMyAdmin - SQL
          $server = "localhost:8889";
          $user = "bryan";
          $password = "admin";
          $db = "dados_lifeplan";
  
          try{
              //Criando conexão
              $db_connec = new PDO("mysql:host=$server", $user, $password);
              $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      
              //Criando DB e Acessando
              $db_connec->exec("CREATE DATABASE IF NOT EXISTS $db");
              $db_connec =  new PDO("mysql:host=$server;dbname=$db", $user, $password);
              $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          }catch(PDOException $e){
                  echo "Erro: " . $e1->getMessage();
          }
  

        $jaCadastrado = false;
        $emailSubTitle = '';
        $senhaLogin = $emailLogin = "";

        if($_SERVER["REQUEST_METHOD"] == "POST"){

            $statusCadastro = "";
            $statusSubCadastro = "";

            $emailLogin = test_input($_POST["emailLoginMod"]);
            $senhaLogin = test_input($_POST["senhaLoginMod"]);

            if($senhaLogin == "" && $emailLogin == ""){

                $emailMed_tempLogado = $_SESSION['emailLogado'];
                $sqlFind_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailMed_tempLogado' ";
                if($result = $db_connec->query($sqlFind_med)){
                    if($result->fetchColumn() > 0){

                        //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                        $emailForm = $_POST['emailCadastroMed'];
                        $sqlCheckEmail_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailForm'";

                        if($result_temp = $db_connec->query($sqlCheckEmail_med)){
                            if($result_temp->fetchColumn() > 0 && $_SESSION['emailLogado'] != $_POST['emailCadastroMed'] ) {
                                $jaCadastrado = true;
                            }
                        }
                        if(!$jaCadastrado){

                            $resultC = $db_connec->query("SELECT * FROM medicos WHERE email = '$emailMed_tempLogado' ");
                            $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                            $crmTeste = $rows['crm'];

                            $sqlUpdate_med = "UPDATE medicos SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?,email=?, especialidade=?, crm=?, senha=? WHERE email = '$emailMed_tempLogado' ";

                            $crmMed_temp = $_POST['crmCadastroMed']; 
                            $sqlCheck3 = "SELECT crm FROM medicos WHERE crm = '$crmMed_temp' ";
                            $result3 = $db_connec->query($sqlCheck3);

                            if($result3->fetchColumn() > 0 && $crmTeste != $_POST['crmCadastroMed']){
                                $statusCadastro = " <b> Negado. </b>";
                                $statusSubCadastro = "CRM do Médico <b> " . $emailMed .  " </b> já cadastrado!";
                            }else{
                            $stmt = $db_connec->prepare($sqlUpdate_med);
                            $stmt->execute(
                                array
                                (
                                    $_POST['nomeCadastroMed'],
                                    $_POST['cidCadastroMed'],
                                    $_POST['estCadastroMed'],
                                    $_POST['cepCadastroMed'],
                                    $_POST['endCadastroMed'],
                                    $_POST['telCadastroMed'],
                                    $_POST['emailCadastroMed'],
                                    $_POST['especCadastroMed'],
                                    $_POST['crmCadastroMed'],
                                    $_POST['senhaCadastroMed']
                                )
                            );

                            $_SESSION['emailLogado'] = $_POST['emailCadastroMed'];   

                            $statusCadastro = "<b> Confirmado. </b>";
                            $statusSubCadastro = "Alteração realizada!";

                            }
                        }else{
                            $statusCadastro = "<b> Negado. </b>";
                            $statusSubCadastro = "Email indisponivel!";
                            $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                        }
                    }
                }
            }else{ //modal

                if($senhaLogin == "sairfurg00" && $emailLogin == "sairfurg00@furg.br"){
                   $senhaLogin = '';
                   $emailLogin = '';
                }
                $redirect = '';

               for($index = 0; $index <=3 ; $index++){
                    switch($index){
                        case 0: //adm
                            $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0){                
                                    $redirect ="
                                    <script> 
                                    window.location.href = './profileAdm.php';
                                    </script>";
    
                                    $_SESSION['statusLogado'] = "Administrador";
                                    $_SESSION['profile'] = "profileAdm.php";
                                    $index = 5; //quebra loop
                                break;
                                }
                            }  
                            break;
                        case 1: //med
                            
                            $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0){                
                                    $_SESSION['statusLogado'] = "Médico";
                                    $_SESSION['profile'] = "profileMed.php";

                                    $index = 5; //quebra loop
                                break;  
                                }
                            }
                            
                            break;
                        case 2: //lab
                            
                            $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0){
                                    
                                    $_SESSION['statusLogado'] = "Laboratorio";
                                    $_SESSION['profile'] = "profileLab.php";
                                    
                                    $redirect ="
                                     <script> 
                                     window.location.href = './profileLab.php';
                                     </script>";

                                    $index = 5; //quebra loop
                                    break;
                                }
                            }
                            
                            break;
                        case 3: //paciente
                            $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
    
                            if($result = $db_connec->query($sqlCheck)){
                                if($result->fetchColumn() > 0)
                                {
    
                                    $_SESSION['statusLogado'] = "Paciente";
                                    $_SESSION['profile'] = "profilePac.php";
                                    $redirect ="
                                     <script> 
                                     window.location.href = './profilePac.php';
                                     </script>";
                                    break;
    
                                }else{
                                    $_SESSION['statusLogado'] = "Visitante";
                                    $_SESSION['profile'] = "signUp.php";
                                    $redirect ="
                                     <script> 
                                     window.location.href = './signUp.php';
                                     </script>";
                                }
                            }
                            
                    }
                }
                $_SESSION['emailLogado'] = $emailLogin;
                echo $redirect;
            }
        }

        //Mostrar dados atuais na tela
        $emailSessao =  $_SESSION['emailLogado'];
        $sqlGetInfo_medAtual = "SELECT * FROM medicos WHERE email = '$emailSessao' ";

        $medLogado = $db_connec->query($sqlGetInfo_medAtual);

        $medLogadoInfo = $medLogado->fetch(PDO::FETCH_ASSOC);

        $nomeMed = test_input($medLogadoInfo['nome']);
        $cidadeMed = test_input($medLogadoInfo['cidade']);
        $estadoMed = test_input($medLogadoInfo['estado']);
        $cepMed = test_input($medLogadoInfo['cep']);
        $enderecoMed = test_input($medLogadoInfo['endereco']);
        $telefoneMed = test_input($medLogadoInfo['telefone']);
        $emailMed = test_input($medLogadoInfo['email']);
        $especialidadeMed = test_input($medLogadoInfo['especialidade']);
        $crmMed = test_input($medLogadoInfo['crm']);
        $senhaMed = test_input($medLogadoInfo['senha']);       

        if($_SESSION['statusLogado'] != "Visitante"){
            $botaoSair = '<button type="button" id="botaoSair"class="btn btn-danger" style="width:75px;" onclick="logOut()">Sair</button>';
        }else{
            $botaoSair = "";
            $_SESSION['emailLogado'] = "";
        }

        if($_SESSION['statusLogado'] == "Administrador"){
            $_SESSION['profile'] = "profileAdm.php";
        }else if($_SESSION['statusLogado'] == "Médico"){
            $_SESSION['profile'] = "profileMed.php";
        }else if($_SESSION['statusLogado'] == "Laboratorio"){
            $_SESSION['profile'] = "profileLab.php";
        }else if($_SESSION['statusLogado'] == "Paciente"){
            $_SESSION['profile'] = "profilePac.php";
        }else{
            $_SESSION['profile'] = "signUp.php";
        }
        if($_SESSION['statusLogado'] != "Médico"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }
    ?>


    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success" id="home">

        <div class="container">

            <a class="navbar-brand h1 mb-0" href="index.php"><i class="fa fa-heartbeat text-ligth" aria-hidden="true"></i> LifePlan</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSite">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="system.php">Sistema</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#faleConosco">Fale conosco</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="imp.php">Imprensa</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="navDrop" >
                            Social
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="https://www.facebook.com/">Facebook</a>
                            <a class="dropdown-item" href="https://www.instagram.com/">Instagram</a>
                            <a class="dropdown-item" href="https://twitter.com/">Twitter</a>
                        </div>
                    </li>
                   

                    <li class="nav-item mr-4">
                        <a type="button" class="nav-link" href="<?php echo $_SESSION['profile']?>"> Perfil <?php echo $_SESSION['statusLogado']?></a>
                    </li>
                </ul>

                <form class="form-inline">                    
                    <button type="button" class="btn btn-light" data-toggle="modal" data-target="#siteModal">Login</button>
                </form>

            </div>
        </div>
    </nav>
    <!-- Carousel -->
    <div id="carouselSite" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
            <li data-target="#carouselSite" data-slide-to="1"></li>
            <li data-target="#carouselSite" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/carousel_01.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_02.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_03.jpg" class="img-fluid d-block w
                -100">
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Posterior</span>
        </a>

    </div>

 

    
    <!-- Conteudo -->
    <div class="container">

        <div class="row">

            <div class="col-12 text-center mt-3" id="sistema">
                <h1 class="display-4"><i class="fa fa-user-md text-success" aria-hidden="true"></i> Perfil <?php echo $_SESSION['statusLogado']?></h1>
                <p>Usuário: <?php echo $_SESSION['emailLogado'] . "<br>" . $statusCadastro . " " . $statusSubCadastro?></p>
            </div>

        </div>

        <div class="row">
            <div class="col-sm-6" style="text-align: justify;">
                <h3><i class="fa fa-pencil text-success" aria-hidden="true"></i> Cadastro e Histórico de Consultas</h3>
                <p>Como um médico, você pode cadastrar consultas e inspecionar o histórico  de suas consultas.</p>

                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="signUpConsult.php"> Cadastro de Consultas</a>
                    <a class="list-group-item list-group-item-action" href="signUpConsult.php"> Histórico de Consultas</a>
                
                </div>
            </div>

            <div class="col-sm-6">
                <h3><i class="fa fa-address-card-o text-success" aria-hidden="true"></i> Alterar Informações Pessoais</h3>
                 
                <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="nomeCadastroMed">Nome Completo:</label>
                                                <input type="text" class="form-control" id="nomeCadastroMed" 
                                                name="nomeCadastroMed"
                                                placeholder="Digite aqui o nome completo..." value="<?php echo $nomeMed?>"
                                                required>

                                            </div>

                                        </div>
                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="endCadMed">Endereço</label>
                                                <input type="text" class="form-control" id="endCadMed" 
                                                name="endCadastroMed"
                                                placeholder="Digite aqui o endereço..." value="<?php echo $enderecoMed?>"
                                                required>

                                            </div>

                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-4">
                                                <label for="inputTelefone">Telefone</label>
                                                <input type="text" id="inputTelefone" class="form-control" 
                                                name="telCadastroMed"
                                                placeholder="Digite o telefone aqui..." 
                                                value="<?php echo $telefoneMed?>"
                                                required >

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="inputCRM">CRM</label>
                                                <input type="text" id="inputCRM" class="form-control" 
                                                name="crmCadastroMed"
                                                placeholder="Digite o CRM aqui..."
                                                maxlength="7"
                                                value="<?php echo $crmMed?>"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>

                                            </div>
                                            <div class="form-group col-sm-4">
                                            <label for="especialidadeMedico">Especialidade</label>
                                            <select required class="form-control" id="especialidadeMedico" 
                                            name ="especCadastroMed"
                                            value="<?php echo $especialidadeMed?>" required>
                                                <option >Selecione...</option>
                                                <option>ACUPUNTURA</option>
                                                <option >ADMINISTRAÇÃO EM SAÚDE</option>
                                                <option >ADMINISTRAÇÃO HOSPITALAR</option>
                                                <option >ALERGIA E IMUNOLOGIA</option>
                                                <option >ALERGIA E IMUNOPATOLOGIA</option>
                                                <option >ANATOMIA PATOLÓGICA</option>
                                                <option >ANESTESIOLOGIA</option>
                                                <option >ANGIOLOGIA</option>
                                                <option >ANGIOLOGIA E CIRURGIA VASCULAR</option>
                                                <option >BRONCOESOFAGOLOGIA</option>
                                                <option >CANCEROLOGIA</option>
                                                <option >CANCEROLOGIA/CANCEROLOGIA CIRÚRGICA</option>
                                                <option >CANCEROLOGIA/CANCEROLOGIA PEDIÁTRICA</option>
                                                <option >CARDIOLOGIA</option>
                                                <option >CIRURGIA CARDIOVASCULAR</option>
                                                <option >CIRURGIA DA MÃO</option>
                                                <option >CIRURGIA DE CABEÇA E PESCOÇO</option>
                                                <option >CIRURGIA DIGESTIVA</option>
                                                <option >CIRURGIA DO APARELHO DIGESTIVO</option>
                                                <option >CIRURGIA DO TRAUMA</option>
                                                <option >CIRURGIA GASTROENTEROLÓGICA</option>
                                                <option >CIRURGIA GERAL</option>
                                                <option >CIRURGIA ONCOLÓGICA</option>
                                                <option >CIRURGIA PEDIÁTRICA</option>
                                                <option >CIRURGIA PLÁSTICA</option>
                                                <option >CIRURGIA TORÁCICA</option>
                                                <option >CIRURGIA TORÁXICA</option>
                                                <option >CIRURGIA VASCULAR</option>
                                                <option >CIRURGIA VASCULAR PERIFÉRICA</option>
                                                <option >CITOPATOLOGIA</option>
                                                <option >CLÍNICA MÉDICA</option>
                                                <option >COLOPROCTOLOGIA</option>
                                                <option >DENSITOMETRIA ÓSSEA</option>
                                                <option >DERMATOLOGIA</option>
                                                <option >DIAGNÓSTICO POR IMAGEM</option>
                                                <option >DOENÇAS INFECCIOSAS E PARASITÁRIAS</option>
                                                <option >ELETROENCEFALOGRAFIA</option>
                                                <option >ENDOCRINOLOGIA</option>
                                                <option >ENDOCRINOLOGIA E METABOLOGIA</option>
                                                <option >ENDOSCOPIA</option>
                                                <option >ENDOSCOPIA DIGESTIVA</option>
                                                <option >ENDOSCOPIA PERORAL</option>
                                                <option >ENDOSCOPIA PERORAL VIAS AÉREAS</option>
                                                <option >FISIATRIA</option>
                                                <option >FONIATRIA</option>
                                                <option >GASTROENTEROLOGIA</option>
                                                <option >GENÉTICA CLÍNICA</option>
                                                <option >GENÉTICA LABORATORIAL</option>
                                                <option >GENÉTICA MÉDICA</option>
                                                <option >GERIATRIA</option>
                                                <option >GERIATRIA E GERONTOLOGIA</option>
                                                <option >GINECOLOGIA</option>
                                                <option >GINECOLOGIA E OBSTETRÍCIA</option>
                                                <option >HANSENOLOGIA</option>
                                                <option >HEMATOLOGIA</option>
                                                <option >HEMATOLOGIA E HEMOTERAPIA</option>
                                                <option >HEMOTERAPIA</option>
                                                <option >HEPATOLOGIA</option>
                                                <option >HOMEOPATIA</option>
                                                <option >IMUNOLOGIA CLÍNICA</option>
                                                <option >INFECTOLOGIA</option>
                                                <option >INFORMÁTICA MÉDICA</option>
                                                <option >MASTOLOGIA</option>
                                                <option >MEDICINA DE EMERGÊNCIA</option>
                                                <option >MEDICINA DE FAMÍLIA E COMUNIDADE</option>
                                                <option >MEDICINA DE TRÁFEGO</option>
                                                <option >MEDICINA DO ADOLESCENTE</option>
                                                <option >MEDICINA DO ESPORTE</option>
                                                <option >MEDICINA DO TRABALHO</option>
                                                <option >MEDICINA ESPORTIVA</option>
                                                <option >MEDICINA FÍSICA E REABILITAÇÃO</option>
                                                <option >MEDICINA GERAL COMUNITÁRIA</option>
                                                <option >MEDICINA INTENSIVA</option>
                                                <option >MEDICINA INTERNA OU CLÍNICA MÉDICA</option>
                                                <option >MEDICINA LEGAL</option>
                                                <option >MEDICINA LEGAL E PERÍCIA MÉDICA</option>
                                                <option >MEDICINA NUCLEAR</option>
                                                <option >MEDICINA PREVENTIVA E SOCIAL</option>
                                                <option >MEDICINA SANITÁRIA</option>
                                                <option >NEFROLOGIA</option>
                                                <option >NEUROCIRURGIA</option>
                                                <option >NEUROFISIOLOGIA CLÍNICA</option>
                                                <option >NEUROLOGIA</option>
                                                <option >NEUROLOGIA PEDIÁTRICA</option>
                                                <option >NEUROPEDIATRIA</option>
                                                <option >NUTRIÇÃO PARENTERAL E ENTERAL</option>
                                                <option >NUTROLOGIA</option>
                                                <option >OBSTETRÍCIA</option>
                                                <option >OFTALMOLOGIA</option>
                                                <option >ONCOLOGIA</option>
                                                <option >ONCOLOGIA CLÍNICA</option>
                                                <option >ORTOPEDIA E TRAUMATOLOGIA</option>
                                                <option >OTORRINOLARINGOLOGIA</option>
                                                <option >PATOLOGIA</option>
                                                <option >PATOLOGIA CLÍNICA</option>
                                                <option >PATOLOGIA CLÍNICA/MEDICINA LABORATORIAL</option>
                                                <option >PEDIATRIA</option>
                                                <option >PNEUMOLOGIA</option>
                                                <option >PNEUMOLOGIA E TISIOLOGIA</option>
                                                <option >PROCTOLOGIA</option>
                                                <option >PSIQUIATRIA</option>
                                                <option >PSIQUIATRIA INFANTIL</option>
                                                <option >RADIODIAGNÓSTICO</option>
                                                <option >RADIOLOGIA</option>
                                                <option >RADIOLOGIA E DIAGNÓSTICO POR IMAGEM</option>
                                                <option >RADIOTERAPIA</option>
                                                <option >REUMATOLOGIA</option>
                                                <option >SEXOLOGIA</option>
                                                <option >TERAPIA INTENSIVA</option>
                                                <option >TERAPIA INTENSIVA PEDIÁTRICA</option>
                                                <option >TISIOLOGIA</option>
                                                <option >TOCO-GINECOLOGIA</option>
                                                <option >ULTRASSONOGRAFIA</option>
                                                <option >ULTRASSONOGRAFIA EM GINECOLOGIA E OBSTETRÍCIA</option>
                                                <option >ULTRASSONOGRAFIA GERAL</option>
                                                <option>UROLOGIA</option>
                                                <option>OUTRAS</option>
                                            </select>
                                            <small class="text-muted">*Selecione novamente</small>

                                            </div>


                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6">

                                                <label for="inputCidMed">Cidade</label>
                                                <input type="text" id="inputCidMed" class="form-control" 
                                                name="cidCadastroMed"
                                                placeholder="Digite aqui a cidade..." 
                                                value="<?php echo $cidadeMed?>" required>

                                            </div>

                                            <div class="form-group col-sm-4">

                                                <label for="estCadastroMed">Estado</label>
                                                <select id="estCadastroMed" 
                                                name="estCadastroMed"
                                                value="<?php echo $estadoMed?>"
                                                class="form-control" required>
                                                    <option value ="">Escolha...</option>
                                                    <option value="AC">Acre</option>
                                                    <option value="AL">Alagoas</option>
                                                    <option value="AP">Amapá</option>
                                                    <option value="AM">Amazonas</option>
                                                    <option value="BA">Bahia</option>
                                                    <option value="CE">Ceará</option>
                                                    <option value="DF">Distrito Federal</option>
                                                    <option value="ES">Espírito Santo</option>
                                                    <option value="GO">Goiás</option>
                                                    <option value="MA">Maranhão</option>
                                                    <option value="MT">Mato Grosso</option>
                                                    <option value="MS">Mato Grosso do Sul</option>
                                                    <option value="MG">Minas Gerais</option>
                                                    <option value="PA">Pará</option>
                                                    <option value="PB">Paraíba</option>
                                                    <option value="PR">Paraná</option>
                                                    <option value="PE">Pernambuco</option>
                                                    <option value="PI">Piauí</option>
                                                    <option value="RJ">Rio de Janeiro</option>
                                                    <option value="RN">Rio Grande do Norte</option>
                                                    <option value="RS">Rio Grande do Sul</option>
                                                    <option value="RO">Rondônia</option>
                                                    <option value="RR">Roraima</option>
                                                    <option value="SC">Santa Catarina</option>
                                                    <option value="SP">São Paulo</option>
                                                    <option value="SE">Sergipe</option>
                                                    <option value="TO">Tocantins</option>
                                                </select>
                                                <small class="text-muted">*Selecione novamente</small>

                                            </div>

                                            <div class="form-group col-sm-2">

                                                <label for="cepCadastroMed">CEP</label>
                                                <input type="text" id="cepCadastroMed" 
                                                name="cepCadastroMed"
                                                placeholder="Digite..." class="form-control"
                                                value="<?php echo $cepMed?>"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="8"
                                                required>

                                            </div>

                                        </div>

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">
                                                <label for="emailCadastroMed">Email</label>
                                                <input type="email" class="form-control" id="emailCadastroMed" 
                                                name="emailCadastroMed"
                                                aria-describedby="emailHelpMed" placeholder="Digite aqui o email..."
                                                value= "<?php echo $emailMed?>"
                                                required>
                                                <?php echo $emailSubTitle?>
                                            </div>
                                            
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroMed">Senha</label>
                                                <input type="text" class="form-control" id="senhaCadastroMed"
                                                name="senhaCadastroMed"
                                                placeholder="Digite a senha..." 
                                                value= "<?php echo $senhaMed?>" required>
                                            </div>
                                            
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroConfirmMed" >Confirmar Senha</label>
                                                <input type="password" class="form-control"  id="senhaCadastroConfirmMed" placeholder="Confirme a senha..." value= "<?php echo $senhaMed?>" required>

                                                <small id="senhaIncorretaMed" class="form-text text-muted"> 
                                                </small>

                                            </div>

                                        </div>

                                        <div class="form-row justify-content-center">
                                            <div class="form-group">

                                            <input type="hidden" name="tipoCadastro" value="Medico"></input>

                                            <input type="submit" class="btn btn-success" id="continueButtonMed" data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie para atualizar seus dados!">
                                        </input>
                                            </div>
                                        </div>

                                        <script>
                                            document.getElementById("continueButtonMed").disabled=true;
                                            var senhaMed = document.getElementById("senhaCadastroMed");
                                            var senhaConfirmaMed = document.getElementById("senhaCadastroConfirmMed");

                                            checaSenha();


                                            function checaSenha(){
                                                if(senhaMed.value != senhaConfirmaMed.value){
                                                    document.getElementById("senhaIncorretaMed").innerHTML = "Senha Incorreta";
                                                    senhaConfirmaMed.setCustomValidity("Senha Incorreta!");
                                                    document.getElementById("continueButtonMed").disabled=true;
                                                } else{
                                                    senhaConfirmaMed.setCustomValidity("");
                                                    document.getElementById("senhaIncorretaMed").innerHTML = "";
                                                    document.getElementById("continueButtonMed").disabled=false;
                                                }
                                            }

                                            senhaMed.onchange = checaSenha;
                                            senhaConfirmaMed.onkeyup = checaSenha;
                                        </script>

                                    </form>


            </div>
        </div>
        
        
<!-- Footer -->
<div class="container">
        <div class="row mb-5">

            <div class="col-12 mb-3"><hr></div>

            <div class="col-sm-4" style="text-align: justify;">

                <h3>A LifePlan</h3>
                <p>Plano de saúde familiar e individual</p>
                <p>A LifePlan foi fundada em 2020 por 2 estudantes de engenharia da computação, Bryan Galani e Frederico Bender. A LifePlan visa proporcionar o plano de saúde ideal para voçe e sua familia, além de auxiliar o contato entre médico e paciente. Utilize nosso site para realizar consultas e exames. </p>

            </div>
            <div class="col-sm-4">
                <h3>Menu</h3>
                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="system.php">Sistema</a>

                    <a class="list-group-item list-group-item-action" href="plans.php">Planos</a>

                    <a class="list-group-item list-group-item-action" href="index.php#faleConosco">Fale Conosco</a>

                    <a class="list-group-item list-group-item-action" href="imp.php">Imprensa</a>
                </div>

            </div>
            <div class="col-sm-4">

                <h3>Social</h3>

                <div class="btn-group-vertical btn-block btn-group-lg" role="group">
                    <a class="btn btn-outline-success"  href="https://www.facebook.com/"><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>

                    <a class="btn btn-outline-success" href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a>

                    <a class="btn btn-outline-success" href="https://twitter.com/"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
                </div>


            </div>

            <div class="col-12 mt-5">

                <blockquote class="blockquote text-center">

                    <p class="mb-0">"Nada pior para a saúde que viver de aparências e fachadas. São pessoas com muito verniz e pouca raiz. Seu destino é a farmácia, o hospital, a dor."</p>
                    <footer class="blockquote-footer">Drauzio Varella <cite title="Source title">Médico, Cientista e Escritor</cite></footer>

                </blockquote>

            </div>

        </div>
    
    </div>
    

     <!-- Modal -->
     <div class="modal fade" id="siteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            

                <div class="modal-header">
                        <h4 class="modal-title w-100 text-center" >Login</h4>

                        <button type="button" class="close text-end" data-dismiss="modal" style="position: absolute; right: 15px;">
                            <span> &times; </span>
                        </button>    
                </div>

                <div class="modal-body">
                    
                   <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">
                        <div class="form-group mt-2">
                            <label for="emailLogin"><i class="fa fa-at" aria-hidden="true"></i> Email</label>
                            <input type="email" class="form-control" id="emailLogin" name="emailLoginMod" placeholder="Email">
                        </div>
                        <div class="form-group my-3">
                            <label for="senhaLogin"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Senha</label>
                            <input type="password" class="form-control" id="senhaLogin" name="senhaLoginMod"placeholder="Senha">
                        </div>

                        <div class="form-group text-center mb-2">
                            <button type="submit" class="btn btn-success " style="width:75px;">Entrar</button>
                            <?php echo $botaoSair?>  
                        </div>

                        <input type="submit" style="visibility: hidden; width: 0px; height:0px; text-align:right; position:absolute;" id="hiddenSubmit">

                        <script>
                            function logOut(){
                                document.getElementById("emailLogin").value = 'sairfurg00@furg.br';
                                document.getElementById("senhaLogin").value = 'sairfurg00';
                                document.getElementById("hiddenSubmit").click();
                            }   
                        </script>
                        <div class="form-group my-2">
                            <h5 class="text-center"> Status: <?php echo $_SESSION['statusLogado']?></h5>
                        </div>
                   </form>

                </div>

                <div class="modal-footer">
                    <a href="signUp.php" class="btn btn-success" type="button" role="button">Cadastrar</a>

                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                </div>

            </div>
        </div>
    </div>
        


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>

    <script>

        $(function () {

            $('[data-toggle="popover"]').popover()

        })

    </script>

</body>



</html>