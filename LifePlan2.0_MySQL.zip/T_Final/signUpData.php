<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0,shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="node_modules/bootstrap/compiler/bootstrap.css" >

    <!-- Meu estilo CSS-->
    <link rel = "stylesheet" href="myStyle/css/myPersonalStyles.css">

    <!-- Font-awesome -->
    <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.css">

    <!-- -->
    <script src="myJavascript/myInteractions.js"></script>

    <title>LifePlan</title>
</head>


<body>

    <!-- PHP -->
    <?php 
        include 'myPhp/functions.php';
        session_start();

        //checa se o usuario que nao é adm tenta cadastrar
        if($_SESSION['statusLogado'] != "Administrador"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }
    
        if($_SERVER["REQUEST_METHOD"] == "POST"){
            
            //PDO - phpMyAdmin - SQL
            $server = "localhost:8889";
            $user = "bryan";
            $password = "admin";
            $db = "dados_lifeplan";

            try{
                //Criando conexão
                $db_connec = new PDO("mysql:host=$server", $user, $password);
                $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
                //Criando DB e Acessando
                $db_connec->exec("CREATE DATABASE IF NOT EXISTS $db");
                $db_connec =  new PDO("mysql:host=$server;dbname=$db", $user, $password);
                $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch(PDOException $e){
                    echo "Erro: " . $e1->getMessage();
            }

                $tipoCadastro = $_POST["tipoCadastro"];
                
                $jaCadastrado = false;
                $statusCadastro = "";
                $statusSubCadastro ="";


                if($tipoCadastro == "" && $_POST['emailPreCadastro'] == ""){
                    $emailLogin = $senhaLogin = "";

                    $emailLogin = test_input($_POST['emailLoginMod']);
                    $senhaLogin = test_input($_POST['senhaLoginMod']);

                    if($senhaLogin == "sairfurg00" && $emailLogin == "sairfurg00@furg.br"){
                        $senhaLogin = '';
                        $emailLogin = '';
                     }
    
                     for($index = 0; $index <=3 ; $index++){
                        switch($index){
                            case 0: //adm
                                $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0){                
                                        $sqlCheck = "SELECT * FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                        $result = $db_connec->query($sqlCheck);


                                        $_SESSION['statusLogado'] = "Administrador";
                                        $_SESSION['profile'] = "profileAdm.php";
                                        $index = 5; //quebra loop
                                    break;
                                    }
                                }  
                                break;
                            case 1: //med
                                
                                $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0){                
                                        $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                        $result = $db_connec->query($sqlCheck);

                                        $_SESSION['statusLogado'] = "Médico";
                                        $_SESSION['profile'] = "profileMed.php";
                                        $index = 5; //quebra loop
                                    break;  
                                    }
                                }
                                
                                break;
                            case 2: //lab
                                
                                $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0){

                                        $sqlCheck = "SELECT * FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                        $result = $db_connec->query($sqlCheck);
                                        
                                        $_SESSION['statusLogado'] = "Laboratorio";
                                        $_SESSION['profile'] = "profileLab.php";
                                        $index = 5; //quebra loop
                                        break;
                                    }
                                }
                                
                                break;
                            case 3: //paciente
                                $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                if($result = $db_connec->query($sqlCheck)){
                                    if($result->fetchColumn() > 0)
                                    {
                                        $sqlCheck = "SELECT * FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                                        $result = $db_connec->query($sqlCheck);

                                        $_SESSION['statusLogado'] = "Paciente";
                                        $_SESSION['profile'] = "profilePac.php";
                                        break;

                                    }else{
                                        $_SESSION['statusLogado'] = "Visitante";
                                        $_SESSION['profile'] = "signUp.php";
                                    }
                                }
                        }
                    }
                    $_SESSION['emailLogado'] = $emailLogin;
                }else if($tipoCadastro == "Administrador"){
                    $emailAdm = $_POST["emailCadastroAdm"];
                    $senhaAdm = $_POST["senhaCadastroAdm"];

                    $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailAdm'";
                    
                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                
                            $sqlCheck = "SELECT * FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";
                
                            $result = $db_connec->query($sqlCheck);
                            
                            $jaCadastrado = true;
                            $statusCadastro = "Negado";
                            $statusSubCadastro = "Administrador <b> " . $emailAdm .  " </b> já cadastrado!";
                        }
                
                        if(!$jaCadastrado){
                            $sqlSign_adm = "
                            INSERT INTO administradores (email, senha) VALUE
                            (:emailAdm,:senhaAdm)
                            ";
                
                            $statement = $db_connec->prepare($sqlSign_adm);
                            $statement->execute(
                                array(
                                'emailAdm' => $emailAdm,
                                'senhaAdm' => $senhaAdm
                                )
                            );
                
                            $jaCadastrado = true;
                            $statusCadastro = "Realizado!";
                            $statusSubCadastro = "Administrador <b> " . $emailAdm .  " </b> adicionado!";
                        }
                
                    }

                }else if($tipoCadastro == "Medico"){
                    $nomeMed = $_POST["nomeCadastroMed"];
                    $cidadeMed = $_POST["cidCadastroMed"];
                    $estadoMed = $_POST["estCadastroMed"];
                    $cepMed = $_POST["cepCadastroMed"];
                    $enderecoMed = $_POST["endCadastroMed"];
                    $telefoneMed= $_POST["telCadastroMed"];
                    $emailMed = $_POST["emailCadastroMed"];
                    $especialidadeMed = $_POST["especCadastroMed"];
                    $crmMed = $_POST["crmCadastroMed"];
                    $senhaMed = $_POST["senhaCadastroMed"];


                    $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailMed'";

                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                
                            $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailMed'";
                
                            $result = $db_connec->query($sqlCheck);
                            
                            $jaCadastrado = true;
                            $statusCadastro = "Negado";
                            $statusSubCadastro = "Médico <b> " . $emailMed .  " </b> já cadastrado!";
                        }
                        if(!$jaCadastrado){
                            $sqlSign_med = "
                            INSERT INTO medicos (nome, cidade, estado, cep, endereco, telefone, email, especialidade, crm, senha) VALUES
                            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                            ";
                
                            $sqlCheck = "SELECT crm FROM medicos WHERE crm = '$crmMed'";
                            $result = $db_connec->query($sqlCheck);
                            if($result->fetchColumn() > 0){
                                $jaCadastrado = true;
                                $statusCadastro = "Negado";
                                $statusSubCadastro = "CRM do Médico <b> " . $emailMed .  " </b> já cadastrado!";
                            }else{
                                $statement = $db_connec->prepare($sqlSign_med);
                                $statement->execute(
                                    array
                                    (
                                        $nomeMed,
                                        $cidadeMed,
                                        $estadoMed, 
                                        $cepMed,
                                        $enderecoMed,
                                        $telefoneMed,
                                        $emailMed, 
                                        $especialidadeMed,
                                        $crmMed, 
                                        $senhaMed
                                    )
                                );
                    
                                $jaCadastrado = true;
                                $statusCadastro = "Realizado!";
                                $statusSubCadastro = "Médico <b> " . $emailMed .  " </b> adicionado!";
                            }
                        }
                    }
                }else if($tipoCadastro == "Laboratorio"){
                    $nomeLab = $_POST["nomeCadastroLab"];
                    $cidadeLab = $_POST["cidCadastroLab"];
                    $estadoLab = $_POST["estCadastroLab"];
                    $cepLab = $_POST["cepCadastroLab"];
                    $enderecoLab = $_POST["endCadastroLab"];
                    $telefoneLab= $_POST["telCadastroLab"];
                    $emailLab = $_POST["emailCadastroLab"];
                    $tipoExameLab = $_POST["tipoCadastroLab"];
                    $cnpjLab = $_POST["cnpjCadastroLab"];
                    $senhaLab = $_POST["senhaCadastroLab"];


                    $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLab'";

                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                            $sqlCheck = "SELECT * FROM laboratorios WHERE email = '$emailLab'";
                            $result = $db_connec->query($sqlCheck);

                            $jaCadastrado = true;
                            $statusCadastro = "Negado";
                            $statusSubCadastro = "Laboratório <b> " . $emailLab .  " </b> já cadastrado!";

                        }

                        if(!$jaCadastrado){
                            $sqlSign_lab = "
                            INSERT INTO laboratorios (nome, cidade, estado, cep, endereco, telefone, email, tipoExame, cnpj, senha) VALUES
                            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                            ";

                            //check CNPJ
                            $sqlCheck = "SELECT cnpj FROM laboratorios WHERE cnpj = '$cnpjLab'";
                            $result = $db_connec->query($sqlCheck);
                            if($result->fetchColumn() > 0){
                                $jaCadastrado = true;
                                $statusCadastro = "Negado";
                                $statusSubCadastro = "CNPJ do Laboratório <b> " . $emailLab .  " </b> já cadastrado!";
                            }else{
                                $statement = $db_connec->prepare($sqlSign_lab);
                                $statement->execute(
                                    array
                                    (
                                        $nomeLab,
                                        $cidadeLab,
                                        $estadoLab,
                                        $cepLab,
                                        $enderecoLab,
                                        $telefoneLab,
                                        $emailLab,
                                        $tipoExameLab,
                                        $cnpjLab,
                                        $senhaLab
                                    )
                                );
                                $jaCadastrado = true;
                                $statusCadastro = "Realizado!";
                                $statusSubCadastro = "Laboratório <b> " . $emailLab .  " </b> adicionado!";
                            }
                        }
                    }
                }else if($tipoCadastro == "Paciente"){
                    $nomePac = $_POST["nomeCadastroPac"];
                    $cidadePac = $_POST["cidCadastroPac"];
                    $estadoPac = $_POST["estCadastroPac"];
                    $cepPac = $_POST["cepCadastroPac"];
                    $enderecoPac = $_POST["endCadastroPac"];
                    $telefonePac= $_POST["telCadastroPac"];
                    $emailPac = $_POST["emailCadastroPac"];
                    $generoPac = $_POST["genCadastroPac"];
                    $idadePac = $_POST["idadeCadastroPac"];
                    $cpfPac = $_POST["cpfCadastroPac"];
                    $senhaPac = $_POST["senhaCadastroPac"];


                    $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailPac' ";

                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                            $jaCadastrado = true;
                            $statusCadastro = "Negado";
                            $statusSubCadastro = "Paciente <b> " . $emailPac .  " </b> já cadastrado!";
                        }
                        if(!$jaCadastrado){
                
                            $sqlSign_pac = "
                            INSERT INTO pacientes (nome, cidade, estado, cep, endereco, telefone, email, genero, idade, cpf, senha) VALUE
                            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                            ";
                
                            $sqlCheck = "SELECT cpf FROM pacientes WHERE cpf = '$cpfPac' ";
                            $result = $db_connec->query($sqlCheck);
                            if($result->fetchColumn() > 0){
                                $jaCadastrado = true;
                                $statusCadastro = "Negado";
                                $statusSubCadastro = "CPF do Paciente <b> " . $emailPac .  " </b> já cadastrado!";
                            }else{
                                $statement = $db_connec->prepare($sqlSign_pac);
                                $statement->execute(
                                    array
                                    (
                                        $nomePac,
                                        $cidadePac,
                                        $estadoPac,
                                        $cepPac,
                                        $enderecoPac,
                                        $telefonePac,
                                        $emailPac,
                                        $generoPac,
                                        $idadePac,
                                        $cpfPac,
                                        $senhaPac
                                    )
                                );
                
                                $jaCadastrado = true;
                                $statusCadastro = "Realizado!";
                                $statusSubCadastro = "Paciente <b> " . $emailPac .  " </b> adicionado!";
                            }
                        }
                    }
                }
        }

        
        if($_SESSION['statusLogado'] != "Visitante"){
            $botaoSair = '<button type="button" id="botaoSair"class="btn btn-danger" style="width:75px;" onclick="logOut()">Sair</button>';
        }else{
            $botaoSair = "";
            $_SESSION['emailLogado'] = "";
        }

        if($_SESSION['statusLogado'] == "Administrador"){
            $_SESSION['profile'] = "profileAdm.php";
        }else if($_SESSION['statusLogado'] == "Médico"){
            $_SESSION['profile'] = "profileMed.php";
        }else if($_SESSION['statusLogado'] == "Laboratorio"){
            $_SESSION['profile'] = "profileLab.php";
        }else if($_SESSION['statusLogado'] == "Paciente"){
            $_SESSION['profile'] = "profilePac.php";
        }else{
            $_SESSION['profile'] = "signUp.php";
        }

        if($_SESSION['statusLogado'] != "Administrador"){
            echo "
            <script> 
            window.location.href = './signUp.php';
            </script>";
        }
    ?>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success" id="home">

        <div class="container">

            <a class="navbar-brand h1 mb-0" href="index.php"><i class="fa fa-heartbeat text-ligth" aria-hidden="true"></i> LifePlan</a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSite">
                <span class="navbar-toggler-icon"></span>
            </button>
    
            <div class="collapse navbar-collapse" id="navbarSite">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="system.php">Sistema</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="plans.php">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php#faleConosco">Fale conosco</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="imp.php">Imprensa</a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" data-toggle="dropdown" id="navDrop" >
                            Social
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="https://www.facebook.com/">Facebook</a>
                            <a class="dropdown-item" href="https://www.instagram.com/">Instagram</a>
                            <a class="dropdown-item" href="https://twitter.com/">Twitter</a>
                        </div>
                    </li>
                   

                    <li class="nav-item mr-4">
                        <a type="button" class="nav-link" href="<?php echo $_SESSION['profile']?>"> Perfil <?php echo $_SESSION['statusLogado']?></a>
                    </li>
                </ul>

                <form class="form-inline">                    
                    <button type="button" class="btn btn-light" data-toggle="modal" data-target="#siteModal">Login</button>
                </form>

            </div>
        </div>
    </nav>

    <!-- Carousel -->
    <div id="carouselSite" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#carouselSite" data-slide-to="0" class="active"></li>
            <li data-target="#carouselSite" data-slide-to="1"></li>
            <li data-target="#carouselSite" data-slide-to="2"></li>
        </ol>


        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/carousel_01.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_02.jpg" class="img-fluid d-block w-100">
            </div>

            <div class="carousel-item">
                <img src="images/carousel_03.jpg" class="img-fluid d-block w
                -100">
            </div>
        </div>

        <a class="carousel-control-prev" href="#carouselSite" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Anterior</span>
        </a>

        <a class="carousel-control-next" href="#carouselSite" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Posterior</span>
        </a>

    </div>


    <!-- Conteudo -->
    <div class="container">
            <div class="row">
                <div class="col-12 text-center">

                    <h1 class="display-4"><i class="fa fa-address-card-o text-success" aria-hidden="true"></i> Cadastro <?php echo $statusCadastro?></h1>
                    <p> <?php echo $statusSubCadastro?>  </p>
                    <hr>

                </div>
            </div>

            <div class="row">

                <div class="col-12">
                    <ul class="nav nav-pills justify-content-center mb-3" id="pills-nav" role="tablist">

                    <li class="nav-item">
                        <a class="nav-link active" id="nav-pills-00" data-toggle="pill" href="#nav-item-00">Administrador</a>
                    </li>

                        <li class="nav-item">
                            <a class="nav-link" id="nav-pills-01" data-toggle="pill" href="#nav-item-01">Médico</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" id="nav-pills-02" data-toggle="pill" href="#nav-item-02">Laboratório</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="nav-pills-03" data-toggle="pill" href="#nav-item-03">Paciente</a>
                        </li>

                    </ul>

                    <div class="tab-content" id="nav-pills-content">

                        <div class="tab-pane fade show active" id="nav-item-00" role="tabpanel">

                            <div class="row justify-content-center mb-5">

                                <div class="col-sm-12 col-md-10 col-lg-8">

                                    <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">
                                                <label for="emailCadastroAdm">Email</label>
                                                <input type="email" class="form-control" id="emailCadastroAdm"
                                                name="emailCadastroAdm" aria-describedby="emailHelpAdm" placeholder="Digite aqui o email..." value= "<?php echo $_POST["emailPreCadastro"]?>" required>
                                                
                                            </div>
                                            
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroAdm">Senha</label>
                                                <input type="password" class="form-control" id="senhaCadastroAdm" 
                                                name="senhaCadastroAdm"
                                                placeholder="Digite a senha..."
                                                value= "<?php echo $_POST["senhaPreCadastro"]?>" required>
                                            </div>
                                            
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroConfirmAdm" >Confirmar Senha</label>
                                                <input type="password" class="form-control"  id="senhaCadastroConfirmAdm" placeholder="Confirme a senha..." value= "<?php echo $_POST["senhaPreCadastroConfirmada"]?>" required>
                    
                                                <small id="senhaIncorretaAdm" class="form-text text-muted"> 
                                                </small>
                                            </div>
                                        </div>

                                        <div class="form-row justify-content-center">
                                            <div class="form-group">

                                                <input type="hidden" name="tipoCadastro" value="Administrador"></input>

                                                <input type="submit" class="btn btn-success" 
                                                id="continueButtonAdm"
                                                data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise"
                                                value="Enviar"></input>

                                            </div>
                                        </div>

                                        <script>

                                            document.getElementById("continueButtonAdm").disabled =true;
                                            
                                            var senhaAdm = document.getElementById("senhaCadastroAdm");
                                            var senhaConfirmaAdm = document.getElementById("senhaCadastroConfirmAdm");

                                            checaSenha();
                
                                            function checaSenha(){
                                                if(senhaAdm.value != senhaConfirmaAdm.value){
                                                    document.getElementById("senhaIncorretaAdm").innerHTML = "Senha Incorreta";
                                                    senhaConfirmaAdm.setCustomValidity("Senha Incorreta!");
                                                    document.getElementById("continueButtonAdm").disabled=true;
                                                }else{
                                                    senhaConfirmaAdm.setCustomValidity("");
                                                    document.getElementById("senhaIncorretaAdm").innerHTML = "";
                                                    document.getElementById("continueButtonAdm").disabled =false;
                                                }
                                            }
                
                                            senhaAdm.onchange = checaSenha;
                                            senhaConfirmaAdm.onkeyup = checaSenha;
                                        </script>

                                    </form>


                                </div>

                            </div>

                        </div>

                        <div class="tab-pane fade show" id="nav-item-01" role="tabpanel">

                            <div class="row justify-content-center mb-5">

                                <div class="col-sm-12 col-md-10 col-lg-8">

                                    <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="nomeCadastroMed">Nome Completo:</label>
                                                <input type="text" class="form-control" id="nomeCadastroMed" 
                                                name="nomeCadastroMed"
                                                placeholder="Digite aqui o nome completo..."
                                                required>

                                            </div>

                                        </div>
                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="endCadMed">Endereço</label>
                                                <input type="text" class="form-control" id="endCadMed" 
                                                name="endCadastroMed"
                                                placeholder="Digite aqui o endereço..."
                                                required>

                                            </div>

                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-4">
                                                <label for="inputTelefone">Telefone</label>
                                                <input type="text" id="inputTelefone" class="form-control" 
                                                name="telCadastroMed"
                                                placeholder="Digite o telefone aqui..." required >

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="inputCRM">CRM</label>
                                                <input type="text" id="inputCRM" class="form-control" 
                                                name="crmCadastroMed"
                                                placeholder="Digite o CRM aqui..."
                                                maxlength="7"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>

                                            </div>
                                            <div class="form-group col-sm-4">
                                            <label for="especialidadeMedico">Especialidade</label>
                                            <select required class="form-control" id="especialidadeMedico" 
                                            name ="especCadastroMed"
                                            name="especialidadeMedico">
                                                <option >Selecione...</option>
                                                <option>ACUPUNTURA</option>
                                                <option >ADMINISTRAÇÃO EM SAÚDE</option>
                                                <option >ADMINISTRAÇÃO HOSPITALAR</option>
                                                <option >ALERGIA E IMUNOLOGIA</option>
                                                <option >ALERGIA E IMUNOPATOLOGIA</option>
                                                <option >ANATOMIA PATOLÓGICA</option>
                                                <option >ANESTESIOLOGIA</option>
                                                <option >ANGIOLOGIA</option>
                                                <option >ANGIOLOGIA E CIRURGIA VASCULAR</option>
                                                <option >BRONCOESOFAGOLOGIA</option>
                                                <option >CANCEROLOGIA</option>
                                                <option >CANCEROLOGIA/CANCEROLOGIA CIRÚRGICA</option>
                                                <option >CANCEROLOGIA/CANCEROLOGIA PEDIÁTRICA</option>
                                                <option >CARDIOLOGIA</option>
                                                <option >CIRURGIA CARDIOVASCULAR</option>
                                                <option >CIRURGIA DA MÃO</option>
                                                <option >CIRURGIA DE CABEÇA E PESCOÇO</option>
                                                <option >CIRURGIA DIGESTIVA</option>
                                                <option >CIRURGIA DO APARELHO DIGESTIVO</option>
                                                <option >CIRURGIA DO TRAUMA</option>
                                                <option >CIRURGIA GASTROENTEROLÓGICA</option>
                                                <option >CIRURGIA GERAL</option>
                                                <option >CIRURGIA ONCOLÓGICA</option>
                                                <option >CIRURGIA PEDIÁTRICA</option>
                                                <option >CIRURGIA PLÁSTICA</option>
                                                <option >CIRURGIA TORÁCICA</option>
                                                <option >CIRURGIA TORÁXICA</option>
                                                <option >CIRURGIA VASCULAR</option>
                                                <option >CIRURGIA VASCULAR PERIFÉRICA</option>
                                                <option >CITOPATOLOGIA</option>
                                                <option >CLÍNICA MÉDICA</option>
                                                <option >COLOPROCTOLOGIA</option>
                                                <option >DENSITOMETRIA ÓSSEA</option>
                                                <option >DERMATOLOGIA</option>
                                                <option >DIAGNÓSTICO POR IMAGEM</option>
                                                <option >DOENÇAS INFECCIOSAS E PARASITÁRIAS</option>
                                                <option >ELETROENCEFALOGRAFIA</option>
                                                <option >ENDOCRINOLOGIA</option>
                                                <option >ENDOCRINOLOGIA E METABOLOGIA</option>
                                                <option >ENDOSCOPIA</option>
                                                <option >ENDOSCOPIA DIGESTIVA</option>
                                                <option >ENDOSCOPIA PERORAL</option>
                                                <option >ENDOSCOPIA PERORAL VIAS AÉREAS</option>
                                                <option >FISIATRIA</option>
                                                <option >FONIATRIA</option>
                                                <option >GASTROENTEROLOGIA</option>
                                                <option >GENÉTICA CLÍNICA</option>
                                                <option >GENÉTICA LABORATORIAL</option>
                                                <option >GENÉTICA MÉDICA</option>
                                                <option >GERIATRIA</option>
                                                <option >GERIATRIA E GERONTOLOGIA</option>
                                                <option >GINECOLOGIA</option>
                                                <option >GINECOLOGIA E OBSTETRÍCIA</option>
                                                <option >HANSENOLOGIA</option>
                                                <option >HEMATOLOGIA</option>
                                                <option >HEMATOLOGIA E HEMOTERAPIA</option>
                                                <option >HEMOTERAPIA</option>
                                                <option >HEPATOLOGIA</option>
                                                <option >HOMEOPATIA</option>
                                                <option >IMUNOLOGIA CLÍNICA</option>
                                                <option >INFECTOLOGIA</option>
                                                <option >INFORMÁTICA MÉDICA</option>
                                                <option >MASTOLOGIA</option>
                                                <option >MEDICINA DE EMERGÊNCIA</option>
                                                <option >MEDICINA DE FAMÍLIA E COMUNIDADE</option>
                                                <option >MEDICINA DE TRÁFEGO</option>
                                                <option >MEDICINA DO ADOLESCENTE</option>
                                                <option >MEDICINA DO ESPORTE</option>
                                                <option >MEDICINA DO TRABALHO</option>
                                                <option >MEDICINA ESPORTIVA</option>
                                                <option >MEDICINA FÍSICA E REABILITAÇÃO</option>
                                                <option >MEDICINA GERAL COMUNITÁRIA</option>
                                                <option >MEDICINA INTENSIVA</option>
                                                <option >MEDICINA INTERNA OU CLÍNICA MÉDICA</option>
                                                <option >MEDICINA LEGAL</option>
                                                <option >MEDICINA LEGAL E PERÍCIA MÉDICA</option>
                                                <option >MEDICINA NUCLEAR</option>
                                                <option >MEDICINA PREVENTIVA E SOCIAL</option>
                                                <option >MEDICINA SANITÁRIA</option>
                                                <option >NEFROLOGIA</option>
                                                <option >NEUROCIRURGIA</option>
                                                <option >NEUROFISIOLOGIA CLÍNICA</option>
                                                <option >NEUROLOGIA</option>
                                                <option >NEUROLOGIA PEDIÁTRICA</option>
                                                <option >NEUROPEDIATRIA</option>
                                                <option >NUTRIÇÃO PARENTERAL E ENTERAL</option>
                                                <option >NUTROLOGIA</option>
                                                <option >OBSTETRÍCIA</option>
                                                <option >OFTALMOLOGIA</option>
                                                <option >ONCOLOGIA</option>
                                                <option >ONCOLOGIA CLÍNICA</option>
                                                <option >ORTOPEDIA E TRAUMATOLOGIA</option>
                                                <option >OTORRINOLARINGOLOGIA</option>
                                                <option >PATOLOGIA</option>
                                                <option >PATOLOGIA CLÍNICA</option>
                                                <option >PATOLOGIA CLÍNICA/MEDICINA LABORATORIAL</option>
                                                <option >PEDIATRIA</option>
                                                <option >PNEUMOLOGIA</option>
                                                <option >PNEUMOLOGIA E TISIOLOGIA</option>
                                                <option >PROCTOLOGIA</option>
                                                <option >PSIQUIATRIA</option>
                                                <option >PSIQUIATRIA INFANTIL</option>
                                                <option >RADIODIAGNÓSTICO</option>
                                                <option >RADIOLOGIA</option>
                                                <option >RADIOLOGIA E DIAGNÓSTICO POR IMAGEM</option>
                                                <option >RADIOTERAPIA</option>
                                                <option >REUMATOLOGIA</option>
                                                <option >SEXOLOGIA</option>
                                                <option >TERAPIA INTENSIVA</option>
                                                <option >TERAPIA INTENSIVA PEDIÁTRICA</option>
                                                <option >TISIOLOGIA</option>
                                                <option >TOCO-GINECOLOGIA</option>
                                                <option >ULTRASSONOGRAFIA</option>
                                                <option >ULTRASSONOGRAFIA EM GINECOLOGIA E OBSTETRÍCIA</option>
                                                <option >ULTRASSONOGRAFIA GERAL</option>
                                                <option>UROLOGIA</option>
                                                <option>OUTRAS</option>
                                            </select>
                                            </div>


                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6">

                                                <label for="inputCidMed">Cidade</label>
                                                <input type="text" id="inputCidMed" class="form-control" 
                                                name="cidCadastroMed"
                                                placeholder="Digite aqui a cidade..." required>

                                            </div>

                                            <div class="form-group col-sm-4">

                                                <label for="estCadastroMed">Estado</label>
                                                <select id="estCadastroMed" 
                                                name="estCadastroMed"
                                                class="form-control" required>
                                                    <option value ="">Escolha...</option>
                                                    <option value="AC">Acre</option>
                                                    <option value="AL">Alagoas</option>
                                                    <option value="AP">Amapá</option>
                                                    <option value="AM">Amazonas</option>
                                                    <option value="BA">Bahia</option>
                                                    <option value="CE">Ceará</option>
                                                    <option value="DF">Distrito Federal</option>
                                                    <option value="ES">Espírito Santo</option>
                                                    <option value="GO">Goiás</option>
                                                    <option value="MA">Maranhão</option>
                                                    <option value="MT">Mato Grosso</option>
                                                    <option value="MS">Mato Grosso do Sul</option>
                                                    <option value="MG">Minas Gerais</option>
                                                    <option value="PA">Pará</option>
                                                    <option value="PB">Paraíba</option>
                                                    <option value="PR">Paraná</option>
                                                    <option value="PE">Pernambuco</option>
                                                    <option value="PI">Piauí</option>
                                                    <option value="RJ">Rio de Janeiro</option>
                                                    <option value="RN">Rio Grande do Norte</option>
                                                    <option value="RS">Rio Grande do Sul</option>
                                                    <option value="RO">Rondônia</option>
                                                    <option value="RR">Roraima</option>
                                                    <option value="SC">Santa Catarina</option>
                                                    <option value="SP">São Paulo</option>
                                                    <option value="SE">Sergipe</option>
                                                    <option value="TO">Tocantins</option>
                                                </select>

                                            </div>

                                            <div class="form-group col-sm-2">

                                                <label for="cepCadastroMed">CEP</label>
                                                <input type="text" id="cepCadastroMed" 
                                                name="cepCadastroMed"
                                                placeholder="Digite aqui..." class="form-control"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="8"
                                                required>

                                            </div>

                                        </div>

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">
                                                <label for="emailCadastroMed">Email</label>
                                                <input type="email" class="form-control" id="emailCadastroMed" 
                                                name="emailCadastroMed"
                                                aria-describedby="emailHelpMed" placeholder="Digite aqui o email..."
                                                value= "<?php echo $_POST["emailPreCadastro"]?>"
                                                required>
                                                <small id="emailHelpMed" class="form-text text-muted">Nós nunca compartilharemos o e-mail.</small>
                                            </div>
                                            
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroMed">Senha</label>
                                                <input type="password" class="form-control" id="senhaCadastroMed"
                                                name="senhaCadastroMed"
                                                placeholder="Digite a senha..." 
                                                value= "<?php echo $_POST["senhaPreCadastro"]?>" required>
                                            </div>
                                            
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroConfirmMed" >Confirmar Senha</label>
                                                <input type="password" class="form-control"  id="senhaCadastroConfirmMed" placeholder="Confirme a senha..." value= "<?php echo $_POST["senhaPreCadastroConfirmada"]?>" required>

                                                <small id="senhaIncorretaMed" class="form-text text-muted"> 
                                                </small>

                                            </div>

                                        </div>

                                        <div class="form-row justify-content-center">
                                            <div class="form-group">

                                            <input type="hidden" name="tipoCadastro" value="Medico"></input>

                                            <input type="submit" class="btn btn-success" id="continueButtonMed" data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                        </input>
                                            </div>
                                        </div>

                                        <script>
                                            document.getElementById("continueButtonMed").disabled=true;
                                            var senhaMed = document.getElementById("senhaCadastroMed");
                                            var senhaConfirmaMed = document.getElementById("senhaCadastroConfirmMed");

                                            checaSenha();


                                            function checaSenha(){
                                                if(senhaMed.value != senhaConfirmaMed.value){
                                                    document.getElementById("senhaIncorretaMed").innerHTML = "Senha Incorreta";
                                                    senhaConfirmaMed.setCustomValidity("Senha Incorreta!");
                                                    document.getElementById("continueButtonMed").disabled=true;
                                                } else{
                                                    senhaConfirmaMed.setCustomValidity("");
                                                    document.getElementById("senhaIncorretaMed").innerHTML = "";
                                                    document.getElementById("continueButtonMed").disabled=false;
                                                }
                                            }

                                            senhaMed.onchange = checaSenha;
                                            senhaConfirmaMed.onkeyup = checaSenha;
                                        </script>

                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade show" id="nav-item-02" role="tabpanel">

                            <div class="row justify-content-center mb-5">

                                <div class="col-sm-12 col-md-10 col-lg-8">

                                    <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="nomeCadastroLab">Nome Completo:</label>
                                                <input type="text" class="form-control"
                                                name="nomeCadastroLab"
                                                id="nomeCadastroLab" placeholder="Digite aqui o nome completo..." required>

                                            </div>

                                        </div>
                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="endCadastroLab">Endereço</label>
                                                <input type="text" class="form-control"
                                                name="endCadastroLab"
                                                id="endCadastroLab" placeholder="Digite aqui o endereço..." required>

                                            </div>

                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-4">
                                                <label for="telCadastroLab">Telefone</label>
                                                <input type="text" id="telCadastroLab" class="form-control" 
                                                name="telCadastroLab"
                                                placeholder="Digite o telefone aqui..." required>

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="cnpjCadastroLab">CNPJ</label>
                                                <input type="text" id="cnpjCadastroLab" class="form-control" 
                                                name="cnpjCadastroLab"
                                                placeholder="Digite o CNPJ aqui..."
                                                maxlength="14"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="inputExame">Tipo de Exame</label>
                                                <input type="text" id="inputExame"
                                                name="tipoCadastroLab"
                                                placeholder="Digite o tipo de exame aqui..." class="form-control" required>
                                            </div>


                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6">

                                                <label for="inputCidLab">Cidade</label>
                                                <input type="text" id="inputCidLab" class="form-control" 
                                                name="cidCadastroLab"
                                                placeholder="Digite aqui a cidade..." required>

                                            </div>

                                            <div class="form-group col-sm-4">

                                                <label for="cidCadastroLab">Estado</label>
                                                <select id="cidCadastroLab" class="form-control"
                                                name="estCadastroLab" required>
                                                    <option value="">Escolha...</option>
                                                    <option value="AC">Acre</option>
                                                    <option value="AL">Alagoas</option>
                                                    <option value="AP">Amapá</option>
                                                    <option value="AM">Amazonas</option>
                                                    <option value="BA">Bahia</option>
                                                    <option value="CE">Ceará</option>
                                                    <option value="DF">Distrito Federal</option>
                                                    <option value="ES">Espírito Santo</option>
                                                    <option value="GO">Goiás</option>
                                                    <option value="MA">Maranhão</option>
                                                    <option value="MT">Mato Grosso</option>
                                                    <option value="MS">Mato Grosso do Sul</option>
                                                    <option value="MG">Minas Gerais</option>
                                                    <option value="PA">Pará</option>
                                                    <option value="PB">Paraíba</option>
                                                    <option value="PR">Paraná</option>
                                                    <option value="PE">Pernambuco</option>
                                                    <option value="PI">Piauí</option>
                                                    <option value="RJ">Rio de Janeiro</option>
                                                    <option value="RN">Rio Grande do Norte</option>
                                                    <option value="RS">Rio Grande do Sul</option>
                                                    <option value="RO">Rondônia</option>
                                                    <option value="RR">Roraima</option>
                                                    <option value="SC">Santa Catarina</option>
                                                    <option value="SP">São Paulo</option>
                                                    <option value="SE">Sergipe</option>
                                                    <option value="TO">Tocantins</option>
                                                </select>

                                            </div>

                                            <div class="form-group col-sm-2">

                                                <label for="cepCadastroLab">CEP</label>
                                                <input type="text" id="cepCadastroLab" 
                                                name="cepCadastroLab"
                                                placeholder="Digite aqui..." class="form-control"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="8" required>

                                            </div>

                                        </div>

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">
                                                <label for="emailCadastroLab">Email</label>
                                                <input type="email" class="form-control" id="emailCadastroLab" 
                                                name="emailCadastroLab"
                                                aria-describedby="emailHelpLab" placeholder="Digite aqui o email..." required
                                                value= "<?php echo $_POST["emailPreCadastro"]?>">
                                                <small id="emailHelpLab" class="form-text text-muted">Nós nunca compartilharemos o e-mail.</small>
                                            </div>
                                            
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroLab">Senha</label>
                                                <input type="password" class="form-control" id="senhaCadastroLab"
                                                name="senhaCadastroLab"
                                                placeholder="Digite a senha..." 
                                                value= "<?php echo $_POST["senhaPreCadastro"]?>" required>
                                            </div>
                                            
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroConfirmLab" >Confirmar Senha</label>
                                                <input type="password" class="form-control"  id="senhaCadastroConfirmLab" placeholder="Confirme a senha..." value= "<?php echo $_POST["senhaPreCadastroConfirmada"]?>" required>

                                                <small id="senhaIncorretaLab" class="form-text text-muted"> 
                                                </small>

                                            </div>

                                        </div>

                                        <div class="form-row justify-content-center">
                                            <div class="form-group">
                                                <input type="hidden" name="tipoCadastro" value="Laboratorio"></input>

                                                <button type="submit" class="btn btn-success" 
                                                id="continueButtonLab"
                                                data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                                    Enviar
                                                </button>
                                            </div>
                                        </div>

                                        <script>
                                            document.getElementById("continueButtonLab").disabled=true;
                                            var senhaLab = document.getElementById("senhaCadastroLab");
                                            var senhaConfirmaLab = document.getElementById("senhaCadastroConfirmLab");

                                            checaSenha();

                                            function checaSenha(){
                                                if(senhaLab.value != senhaConfirmaLab.value){
                                                    document.getElementById("senhaIncorretaLab").innerHTML = "Senha Incorreta";
                                                    senhaConfirmaLab.setCustomValidity("Senha Incorreta!");
                                                    document.getElementById("continueButtonLab").disabled=true;
                                                } else{
                                                    senhaConfirmaLab.setCustomValidity("");
                                                    document.getElementById("senhaIncorretaLab").innerHTML = "";
                                                    document.getElementById("continueButtonLab").disabled=false;
                                                }
                                            }

                                            senhaLab.onchange = checaSenha;
                                            senhaConfirmaLab.onkeyup = checaSenha;
                                        </script>


                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade show" id="nav-item-03" role="tabpanel">
                            <div class="row justify-content-center mb-5">

                                <div class="col-sm-12 col-md-10 col-lg-8">

                                    <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="nomeCadastroPac">Nome Completo:</label>
                                                <input type="text" class="form-control" 
                                                name="nomeCadastroPac"
                                                id="nomeCadastroPac" placeholder="Digite aqui o nome completo..." required>

                                            </div>

                                        </div>
                                        <div class="form-row">

                                            <div class="form-group col-sm-12">

                                                <label for="endCadastroPac">Endereço</label>
                                                <input type="text" class="form-control" 
                                                name="endCadastroPac"
                                                id="endCadastroPac" placeholder="Digite aqui o endereço..." required>

                                            </div>

                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-4">
                                                <label for="telCadastroPac">Telefone</label>
                                                <input type="text" id="telCadastroPac"
                                                name="telCadastroPac"
                                                class="form-control" placeholder="Digite o telefone aqui..."
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                                

                                            </div>
                                            <div class="form-group col-sm-4">
                                                <label for="cpfCadastroPac">CPF</label>
                                                <input type="text" id="cpfCadastroPac" class="form-control"
                                                name="cpfCadastroPac"
                                                placeholder="Digite o CPF aqui..."
                                                maxlength="11"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="11" required>

                                            </div>
                                            <div class="form-group col-sm-2">
                                                <label for="inputGenero">Genero</label>
                                                <select id="inputGenero" class="form-control"
                                                name="genCadastroPac" required>
                                                    <option value ="">Escolha...</option>
                                                    <option value="M">Masculino</option>
                                                    <option value="F">Feminino</option>
                                                    <option value="O">Outros</option>
                                                    <option value="IDK">Não Identificar</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-sm-2">
                                                <label for="inputIDade">Idade</label>
                                                <input type="text" id="inputIdade" placeholder="Idade" 
                                                name="idadeCadastroPac"
                                                class="form-control"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                            </div>


                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6">

                                                <label for="cidCastroPac">Cidade</label>
                                                <input type="text" id="cidCadastroPac" class="form-control" 
                                                name="cidCadastroPac"
                                                placeholder="Digite aqui a cidade..." required>

                                            </div>

                                            <div class="form-group col-sm-4">

                                                <label for="estCadastroPac">Estado</label>
                                                <select id="estCadastroPac" class="form-control"
                                                name="estCadastroPac" required>
                                                    <option value ="">Escolha...</option>
                                                    <option value="AC">Acre</option>
                                                    <option value="AL">Alagoas</option>
                                                    <option value="AP">Amapá</option>
                                                    <option value="AM">Amazonas</option>
                                                    <option value="BA">Bahia</option>
                                                    <option value="CE">Ceará</option>
                                                    <option value="DF">Distrito Federal</option>
                                                    <option value="ES">Espírito Santo</option>
                                                    <option value="GO">Goiás</option>
                                                    <option value="MA">Maranhão</option>
                                                    <option value="MT">Mato Grosso</option>
                                                    <option value="MS">Mato Grosso do Sul</option>
                                                    <option value="MG">Minas Gerais</option>
                                                    <option value="PA">Pará</option>
                                                    <option value="PB">Paraíba</option>
                                                    <option value="PR">Paraná</option>
                                                    <option value="PE">Pernambuco</option>
                                                    <option value="PI">Piauí</option>
                                                    <option value="RJ">Rio de Janeiro</option>
                                                    <option value="RN">Rio Grande do Norte</option>
                                                    <option value="RS">Rio Grande do Sul</option>
                                                    <option value="RO">Rondônia</option>
                                                    <option value="RR">Roraima</option>
                                                    <option value="SC">Santa Catarina</option>
                                                    <option value="SP">São Paulo</option>
                                                    <option value="SE">Sergipe</option>
                                                    <option value="TO">Tocantins</option>
                                                </select>

                                            </div>

                                            <div class="form-group col-sm-2">

                                                <label for="cepCadastroPac">CEP</label>
                                                <input type="text" id="cepCadastroPac" 
                                                name="cepCadastroPac"
                                                placeholder="Digite aqui..." class="form-control"
                                                onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                                maxlength="8" required>

                                            </div>

                                        </div>

                                        <div class="form-row">

                                            <div class="form-group col-sm-12">
                                                <label for="emailCadastroPac">Email</label>
                                                <input type="email" class="form-control" id="emailCadastroPac" 
                                                name="emailCadastroPac"
                                                aria-describedby="emailHelpPac" placeholder="Digite aqui o email..." required
                                                value= "<?php echo $_POST["emailPreCadastro"]?>">
                                                <small id="emailHelpPac" class="form-text text-muted">Nós nunca compartilharemos o e-mail.</small>
                                            </div>
                                            
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroPac">Senha</label>
                                                <input type="password" class="form-control" id="senhaCadastroPac"
                                                name="senhaCadastroPac" required placeholder="Digite a senha..."
                                                value= "<?php echo $_POST["senhaPreCadastro"]?>">
                                            </div>
                                            
                                            <div class="form-group col-sm-6 text-left">
                                                <label for="senhaCadastroConfirmPac" >Confirmar Senha</label>
                                                <input type="password" class="form-control"  required id="senhaCadastroConfirmPac" placeholder="Confirme a senha..." value= "<?php echo $_POST["senhaPreCadastroConfirmada"]?>">

                                                <small id="senhaIncorretaPac" class="form-text text-muted"> 
                                                </small>

                                            </div>

                                        </div>
                                        
                                        <div class="form-row justify-content-center">
                                            <div class="form-group">
                                                <input type="hidden" name="tipoCadastro" value="Paciente"></input>

                                                <button type="submit" class="btn btn-success" 
                                                id="continueButtonPac"
                                                data-toggle="popover" data-placement="right" data-trigger="hover" title="" data-content="Envie o formulario para analise">
                                                    Enviar
                                                </button>
                                            </div>
                                        </div>

                                        <script>
                                            document.getElementById("continueButtonPac").disabled=true;
                                            var senhaPac = document.getElementById("senhaCadastroPac");
                                            var senhaConfirmaPac = document.getElementById("senhaCadastroConfirmPac");

                                            checaSenha();

                                            function checaSenha(){
                                                if(senhaPac.value != senhaConfirmaPac.value){
                                                    document.getElementById("senhaIncorretaPac").innerHTML = "Senha Incorreta";
                                                    senhaConfirmaPac.setCustomValidity("Senha Incorreta!");
                                                    document.getElementById("continueButtonPac").disabled=true;
                                                } else{
                                                    senhaConfirmaPac.setCustomValidity("");
                                                    document.getElementById("senhaIncorretaPac").innerHTML = "";
                                                    document.getElementById("continueButtonPac").disabled=false;
                                                }
                                            }

                                            senhaPac.onchange = checaSenha;
                                            senhaConfirmaPac.onkeyup = checaSenha;
                                        </script>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    <div class="container">

        
<!-- Footer -->
<div class="container">
        <div class="row mb-5">

            <div class="col-12 mb-3"><hr></div>

            <div class="col-sm-4" style="text-align: justify;">

                <h3>A LifePlan</h3>
                <p>Plano de saúde familiar e individual</p>
                <p>A LifePlan foi fundada em 2020 por 2 estudantes de engenharia da computação, Bryan Galani e Frederico Bender. A LifePlan visa proporcionar o plano de saúde ideal para voçe e sua familia, além de auxiliar o contato entre médico e paciente. Utilize nosso site para realizar consultas e exames. </p>

            </div>
            <div class="col-sm-4">
                <h3>Menu</h3>
                <div class="list-group text-center">
                    <a class="list-group-item list-group-item-action" href="system.php">Sistema</a>

                    <a class="list-group-item list-group-item-action" href="plans.php">Planos</a>

                    <a class="list-group-item list-group-item-action" href="index.php#faleConosco">Fale Conosco</a>

                    <a class="list-group-item list-group-item-action" href="imp.php">Imprensa</a>
                </div>

            </div>
            <div class="col-sm-4">

                <h3>Social</h3>

                <div class="btn-group-vertical btn-block btn-group-lg" role="group">
                    <a class="btn btn-outline-success"  href="https://www.facebook.com/"><i class="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>

                    <a class="btn btn-outline-success" href="https://www.instagram.com/"><i class="fa fa-instagram" aria-hidden="true"></i> Instagram</a>

                    <a class="btn btn-outline-success" href="https://twitter.com/"><i class="fa fa-twitter-square" aria-hidden="true"></i> Twitter</a>
                </div>


            </div>

            <div class="col-12 mt-5">

                <blockquote class="blockquote text-center">

                    <p class="mb-0">"Nada pior para a saúde que viver de aparências e fachadas. São pessoas com muito verniz e pouca raiz. Seu destino é a farmácia, o hospital, a dor."</p>
                    <footer class="blockquote-footer">Drauzio Varella <cite title="Source title">Médico, Cientista e Escritor</cite></footer>

                </blockquote>

            </div>

        </div>
    
    </div>


     <!-- Modal -->
    <div class="modal fade" id="siteModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            

                <div class="modal-header">
                        <h4 class="modal-title w-100 text-center" >Login</h4>

                        <button type="button" class="close text-end" data-dismiss="modal" style="position: absolute; right: 15px;">
                            <span> &times; </span>
                        </button>    
                </div>

                <div class="modal-body">
                    
                   <form method="post" action:" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?> ">
                        <div class="form-group mt-2">
                            <label for="emailLogin"><i class="fa fa-at" aria-hidden="true"></i> Email</label>
                            <input type="email" class="form-control" id="emailLogin" name="emailLoginMod" placeholder="Email">
                        </div>
                        <div class="form-group my-3">
                            <label for="senhaLogin"><i class="fa fa-unlock-alt" aria-hidden="true"></i> Senha</label>
                            <input type="password" class="form-control" id="senhaLogin" name="senhaLoginMod"placeholder="Senha">
                        </div>

                        <div class="form-group text-center mb-2">
                            <button type="submit" class="btn btn-success " style="width:75px;">Entrar</button>
                            <?php echo $botaoSair?>  
                        </div>

                        <input type="submit" style="visibility: hidden; width: 0px; height:0px; text-align:right; position:absolute;" id="hiddenSubmit">

                        <script>
                            function logOut(){
                                document.getElementById("emailLogin").value = 'sairfurg00@furg.br';
                                document.getElementById("senhaLogin").value = 'sairfurg00';
                                document.getElementById("hiddenSubmit").click();
                            }   
                        </script>
                        <div class="form-group my-2">
                            <h5 class="text-center"> Status: <?php echo $_SESSION['statusLogado']?></h5>
                        </div>
                   </form>

                </div>

                <div class="modal-footer">
                    <a href="signUp.php" class="btn btn-success" type="button" role="button">Cadastrar</a>

                    <button type="button" class="btn btn-danger" data-dismiss="modal">Fechar</button>
                </div>

            </div>
        </div>
    </div>

    
    <!-- Optional JavaScript for bootstrap -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="node_modules/jquery/dist/jquery.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.js"></script>
        
    <script>0
        $(function () {
            $('[data-toggle="popover"]').popover()
        })
    </script>


</body>



</html>