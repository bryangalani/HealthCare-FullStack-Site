<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script></script>
    <title>Document</title>
</head>
<body>
    <h1>Hello</h1>

    <?php

    echo "
    Parte 1 - Paginas Simples <br> 
    Conexao PDO, Login Modal <br> <br>   
    ";

    //PDO - phpMyAdmin - SQL
    $server = "localhost:8889";
    $user = "bryan";
    $password = "admin";
    $db = "dados_lifeplan";

    try{
        //Criando conexão
        $db_connec = new PDO("mysql:host=$server", $user, $password);
        $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        //Criando DB e Acessando
        $db_connec->exec("CREATE DATABASE IF NOT EXISTS $db");
        $db_connec =  new PDO("mysql:host=$server;dbname=$db", $user, $password);
        $db_connec->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        //Criando Tabelas base
        $sqlTable_adms = "
        CREATE TABLE IF NOT EXISTS administradores (
            email VARCHAR(80) NOT NULL PRIMARY KEY, 
            senha VARCHAR(120) NOT NULL
        ); 
        ";

        $sqlTable_meds = "
        CREATE TABLE IF NOT EXISTS medicos (
            nome VARCHAR(80) NOT NULL, 
            cidade VARCHAR(40) NOT NULL,
            estado VARCHAR(40) NOT NULL,
            cep VARCHAR(80) NOT NULL,
            endereco VARCHAR(50) NOT NULL,
            telefone VARCHAR(80) NOT NULL,
            email VARCHAR(80) NOT NULL,
            especialidade VARCHAR(80) NOT NULL,
            crm VARCHAR(80) NOT NULL PRIMARY KEY,
            senha VARCHAR(80) NOT NULL
        ); 
        ";

        $sqlTable_labs = "
        CREATE TABLE IF NOT EXISTS laboratorios (
            nome VARCHAR(80) NOT NULL, 
            cidade VARCHAR(40) NOT NULL,
            estado VARCHAR(40) NOT NULL,
            cep VARCHAR(80) NOT NULL,
            endereco VARCHAR(50) NOT NULL,
            telefone VARCHAR(80) NOT NULL,
            email VARCHAR(80) NOT NULL ,
            tipoExame VARCHAR(80) NOT NULL,
            cnpj VARCHAR(20) NOT NULL PRIMARY KEY,
            senha VARCHAR(80) NOT NULL
        ); 
        ";

        $sqlTable_pacs = "
        CREATE TABLE IF NOT EXISTS pacientes (
            nome VARCHAR(80) NOT NULL, 
            cidade VARCHAR(40) NOT NULL,
            estado VARCHAR(40) NOT NULL,
            cep VARCHAR(80) NOT NULL,
            endereco VARCHAR(50) NOT NULL,
            telefone VARCHAR(80) NOT NULL,
            email VARCHAR(80) NOT NULL,
            genero VARCHAR(15) NOT NULL,
            idade INT(4) NOT NULL,
            cpf VARCHAR(80) NOT NULL PRIMARY KEY,
            senha VARCHAR(80) NOT NULL
        ); 
        ";

        $db_connec->exec($sqlTable_adms); 
        $db_connec->exec($sqlTable_meds); 
        $db_connec->exec($sqlTable_labs); 
        $db_connec->exec($sqlTable_pacs); 

        

        // Inserindo dados teste
        $sqlData_adms = "
        INSERT INTO administradores (email, senha) VALUES
        ('admin@furg.br','adm123'),
        ('admina@furg.br', 'admina123');
        ";

        $sqlData_meds = "
        INSERT INTO medicos (nome, cidade, estado, cep, endereco, telefone, email, especialidade, crm, senha) VALUES
        ('Jose Arnaldo','Piracicaba', 'São Paulo', '11222333', 'Rua dos Medicos 01', '19911223344', 'med@furg.br', 'ACUPUNTURA', '1234567', 'med123');
        ";

        $sqlData_labs = "
        INSERT INTO laboratorios (nome, cidade, estado, cep, endereco, telefone, email, tipoExame, cnpj, senha) VALUES
        ('Previlab','Piracicaba', 'São Paulo', '11555333', 'Rua dos Labs 02', '1987654321', 'lab@furg.br', 'Exame de Sangue', '11122233344455', 'lab123');
        ";

        $sqlData_pacs = "
        INSERT INTO pacientes (nome, cidade, estado, cep, endereco, telefone, email, genero, idade, cpf, senha) VALUE
        ('Joao Amado','Piracicaba', 'São Paulo', '13421111', 'Rua dos Pacs 02', '19900123456', 'pac@furg.br', 'Masculino', '21', '11122233344', 'pac123');
        ";

        try{
            $db_connec->exec($sqlData_adms);
            $db_connec->exec($sqlData_meds);
            $db_connec->exec($sqlData_labs);
            $db_connec->exec($sqlData_pacs);
        }catch(PDOException $e1){
            //echo "Erro: " . $e1->getMessage();
        }


        $emailLogin = 'admin@furg.br';
        $senhaLogin = 'adm123';


        for($index = 0; $index <=3 ; $index++){
            switch($index){
                case 0: //adm
                    $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                            echo "Administrador ";

                            $sqlCheck = "SELECT * FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                            $result = $db_connec->query($sqlCheck);
                            
                            $index = 5;
                        }
                    }
                    
                    break;
                case 1: //med
                    
                    $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                            echo "med";

                            $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                            $result = $db_connec->query($sqlCheck);
                            $index = 5;
                        }
                    }
                    
                    break;
                case 2: //lab
                    
                    $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                            echo "lab";

                            $sqlCheck = "SELECT * FROM laboratorios WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                            $result = $db_connec->query($sqlCheck);
                            $index = 5;
                        }
                    }
                    
                    break;
                case 3: //paciente
                    
                    $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                    if($result = $db_connec->query($sqlCheck)){
                        if($result->fetchColumn() > 0){
                            echo "adm";

                            $sqlCheck = "SELECT * FROM pacientes WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

                            $result = $db_connec->query($sqlCheck);
                            $index = 5;
                        }
                    }
                    
            }
        }

        $rows = $result->fetch(PDO::FETCH_ASSOC);
        $emailTeste = $rows['email'];
        print_r($rows);
        echo "<br> Email: " . $emailTeste . "<br>";

    }catch(PDOException $e){
        echo "Erro no banco de dados: " . $e->getMessage();
    }

    echo "
    <br> <br> <br> Parte 2 - Paginas Complexas <br>
    Cadastro pelo Adm (SignUp Data)
    ";

    
    echo "<br> <br> Cadastro de Administrador: <br>";
    
    $emailAdm = "admin@furg.br";
    $senhaAdm = "adm123";
    $jaCadastrado = false;
    //SignUp Adm

    $sqlCheck = "SELECT COUNT(*) FROM administradores WHERE email = '$emailAdm'";

    if($result = $db_connec->query($sqlCheck)){
        if($result->fetchColumn() > 0){

            $sqlCheck = "SELECT * FROM administradores WHERE email = '$emailLogin' AND senha = '$senhaLogin' ";

            $result = $db_connec->query($sqlCheck);
            
            $jaCadastrado = true;
            $statusCadastro = "Negado";
            $statusSubCadastro = "Administrador <b> " . $emailAdm .  " </b> já cadastrado!";
        }

        if(!$jaCadastrado){
            $sqlSign_adm = "
            INSERT INTO administradores (email, senha) VALUE
            (:emailAdm,:senhaAdm)
            ";

            $statement = $db_connec->prepare($sqlSign_adm);
            $statement->execute(
                array(
                'emailAdm' => $emailAdm,
                'senhaAdm' => $senhaAdm
                )
            );

            $jaCadastrado = true;
            $statusCadastro = "Realizado!";
            $statusSubCadastro = "Administrador <b> " . $emailAdm .  " </b> adicionado!";
        }

        echo "Status ADM: " . $statusCadastro ;
    }
    

    //SignUp Medico
    echo "<br> <br> Cadastro de Medicos:  <br>";

    $nomeMed = "A";
    $cidadeMed = "B";
    $estadoMed = "C";
    $cepMed = "11222333";
    $enderecoMed = "Rua C";
    $telefoneMed = "19996843220";
    $emailMed = "meda@furg.br";
    $especialidadeMed = "Acunputura";
    $crmMed = "1234567";
    $senhaMed = "med123";
    $jaCadastrado = false;


    $sqlCheck = "SELECT COUNT(*) FROM medicos WHERE email = '$emailMed'";

    if($result = $db_connec->query($sqlCheck)){
        if($result->fetchColumn() > 0){

            $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailMed'";

            $result = $db_connec->query($sqlCheck);
            
            $jaCadastrado = true;
            $statusCadastro = "Negado";
            $statusSubCadastro = "Médico <b> " . $emailMed .  " </b> já cadastrado!";
        }
        if(!$jaCadastrado){
            $sqlSign_med = "
            INSERT INTO medicos (nome, cidade, estado, cep, endereco, telefone, email, especialidade, crm, senha) VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            ";

            $sqlCheck = "SELECT crm FROM medicos WHERE crm = '$crmMed'";
            $result = $db_connec->query($sqlCheck);
            if($result->fetchColumn() > 0){
                $jaCadastrado = true;
                $statusCadastro = "Negado";
                $statusSubCadastro = "CRM do Médico <b> " . $emailMed .  " </b> já cadastrado!";
            }else{
                $statement = $db_connec->prepare($sqlSign_med);
                $statement->execute(
                    array
                    (
                        $nomeMed,
                        $cidadeMed,
                        $estadoMed, 
                        $cepMed,
                        $enderecoMed,
                        $telefoneMed,
                        $emailMed, 
                        $especialidadeMed,
                        $crmMed, 
                        $senhaMed
                    )
                );
    
                $jaCadastrado = true;
                $statusCadastro = "Realizado!";
                $statusSubCadastro = "Médico <b> " . $emailMed .  " </b> adicionado!";
            }
        }

        echo "Status MED: ". $statusCadastro;
    }

    //SignUp Laboratorio 
    echo "<br> <br> Cadastro de Laboratorios:  <br>";

    $nomeLab = "A";
    $cidadeLab = "B";
    $estadoLab = "C";
    $cepLab = "11111111";
    $enderecoLab = "Rua D";
    $telefoneLab = "1996843220";
    $emailLab = "labA@furg.br";
    $tipoExameLab = "Exame de Sangue";
    $cnpjLab = "11122233344455";
    $senhaLab = "lab123";
    $jaCadastrado = false;

    $sqlCheck = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLab'";

    if($result = $db_connec->query($sqlCheck)){
        if($result->fetchColumn() > 0){

            $sqlCheck = "SELECT * FROM laboratorios WHERE email = '$emailLab'";
            $result = $db_connec->query($sqlCheck);

            $jaCadastrado = true;
            $statusCadastro = "Negado";
            $statusSubCadastro = "Laboratório <b> " . $emailLab .  " </b> já cadastrado!";

        }

        if(!$jaCadastrado){

            $sqlSign_lab = "
            INSERT INTO laboratorios (nome, cidade, estado, cep, endereco, telefone, email, tipoExame, cnpj, senha) VALUES
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            ";

            //check CNPJ
            $sqlCheck = "SELECT cnpj FROM laboratorios WHERE cnpj = '$cnpjLab'";
            $result = $db_connec->query($sqlCheck);
            if($result->fetchColumn() > 0){
                $jaCadastrado = true;
                $statusCadastro = "Negado";
                $statusSubCadastro = "CNPJ do Laboratório <b> " . $emailLab .  " </b> já cadastrado!";
            }else{
                $statement = $db_connec->prepare($sqlSign_lab);
                $statement->execute(
                    array
                    (
                        $nomeLab,
                        $cidadeLab,
                        $estadoLab,
                        $cepLab,
                        $enderecoLab,
                        $telefoneLab,
                        $emailLab,
                        $tipoExameLab,
                        $cnpjLab,
                        $senhaLab
                    )
                );
                $jaCadastrado = true;
                $statusCadastro = "Realizado!";
                $statusSubCadastro = "Laboratório <b> " . $emailLab .  " </b> adicionado!";
            }
        }

        echo "Status LAB: " . $statusCadastro;
    }
    

    //Signup de Paciente
    echo "<br> <br> Cadastro de Pacientes: <br>";

    $nomePac = "A";
    $cidadePac = "B";
    $estadoPac = "C";
    $cepPac = "D";
    $enderecoPac = "E";
    $telefonePac = "1996843220";
    $emailPac = "paca@furg.br";
    $generoPac = "Masculino";
    $idadePac = "21";
    $cpfPac = "11122233344";
    $senhaPac = "pac123";
    $jaCadastrado = false;

    $sqlCheck = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailPac' ";

    if($result = $db_connec->query($sqlCheck)){
        if($result->fetchColumn() > 0){
            $jaCadastrado = true;
            $statusCadastro = "Negado";
            $statusSubCadastro = "Paciente <b> " . $emailPac .  " </b> já cadastrado!";
        }
        if(!$jaCadastrado){

            $sqlSign_pac = "
            INSERT INTO pacientes (nome, cidade, estado, cep, endereco, telefone, email, genero, idade, cpf, senha) VALUE
            (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            ";

            $sqlCheck = "SELECT cpf FROM pacientes WHERE cpf = '$cpfPac' ";
            $result = $db_connec->query($sqlCheck);
            if($result->fetchColumn() > 0){
                $jaCadastrado = true;
                $statusCadastro = "Negado";
                $statusSubCadastro = "CPF do Paciente <b> " . $emailPac .  " </b> já cadastrado!";
            }else{
                $statement = $db_connec->prepare($sqlSign_pac);
                $statement->execute(
                    array
                    (
                        $nomePac,
                        $cidadePac,
                        $estadoPac,
                        $cepPac,
                        $enderecoPac,
                        $telefonePac,
                        $emailPac,
                        $generoPac,
                        $idadePac,
                        $cpfPac,
                        $senhaPac
                    )
                );

                $jaCadastrado = true;
                $statusCadastro = "Realizado!";
                $statusSubCadastro = "Paciente <b> " . $emailPac .  " </b> adicionado!";
            }
        }
        echo "Status PAC: " . $statusCadastro;
    }


    echo "<br> <br> <br> Parte 3 - Perfis <br>
    Adm, Med, Lab e Pac <br> <br>";


    echo "Perfil Administrador <br>";
    /*
    $emailAdm_tempLogado = $_SESSION['emailLogado'];
    $sqlFind_adm = "SELECT COUNT(*) FROM administradores WHERE email = '$emailAdm_tempLogado' ";
    if($result = $db_connec->query($sqlFind_adm)){
        if($result->fetchColumn() > 0){

            //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
            $emailForm = $_POST['emailCadastroAdm'];
            $sqlCheckEmail_adm = "SELECT COUNT(*) FROM administradores WHERE email = '$emailForm'";

            if($result_temp = $db_connec->query($sqlCheckEmail_adm)){
                if($result_temp->fetchColumn() > 0 && $_SESSION['emailLogado'] != $_POST['emailCadastroAdm'] ) {
                    $jaCadastrado = true;
                }
            }
            if(!$jaCadastrado){
                $sqlUpdate_adm = "UPDATE administradores SET email=?, senha=? WHERE email = '$emailAdm_tempLogado' ";
                $stmt = $db_connec->prepare($sqlUpdate_adm);
                $stmt->execute(
                    array
                    (
                        $_POST['emailCadastroAdm'],
                        $_POST['senhaCadastroAdm']
                    )
                );

                $_SESSION['emailLogado'] = $_POST['emailCadastroAdm'];   
            }else{
                $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
            }
        }
    }

    //Mostrar dados atuais na tela
    $emailSessao =  $_SESSION['emailLogado'];
    $sqlGetInfo_admAtual = "SELECT * FROM administradores WHERE email = '$emailSessao' ";
    
    $admLogado = $db_connec->query($sqlGetInfo_admAtual);
    
    $admLogadoInfo = $admLogado->fetch(PDO::FETCH_ASSOC);

    $emailAdm = test_input($admLogadoInfo['email']);
    $senhaAdm = test_input($admLogadoInfo['senha']);
    */

    echo "<br> <br> Perfil Medico: <br>";

    /*
    $emailMed_tempLogado = $_SESSION['emailLogado'];
                $sqlFind_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailMed_tempLogado' ";
                if($result = $db_connec->query($sqlFind_med)){
                    if($result->fetchColumn() > 0){

                        //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                        $emailForm = $_POST['emailCadastroMed'];
                        $sqlCheckEmail_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailForm'";

                        if($result_temp = $db_connec->query($sqlCheckEmail_med)){
                            if($result_temp->fetchColumn() > 0 && $_SESSION['emailLogado'] != $_POST['emailCadastroMed'] ) {
                                $jaCadastrado = true;
                            }
                        }
                        if(!$jaCadastrado){
                            $sqlUpdate_med = "UPDATE medicos SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?,email=?, especialidade=?, crm=?, senha=? WHERE email = '$emailMed_tempLogado' ";

                            $crmMed_temp = $_POST['crmCadastroMed']; 
                            $sqlCheck3 = "SELECT crm FROM medicos WHERE crm = '$crmMed_temp' ";
                            $result3 = $db_connec->query($sqlCheck3);

                            if($result3->fetchColumn() > 0){
                                $statusCadastro = " <b> Negado. </b>";
                                $statusSubCadastro = "CRM do Médico <b> " . $emailMed .  " </b> já cadastrado!";
                            }else{
                            $stmt = $db_connec->prepare($sqlUpdate_med);
                            $stmt->execute(
                                array
                                (
                                    $_POST['nomeCadastroMed'],
                                    $_POST['cidCadastroMed'],
                                    $_POST['estCadastroMed'],
                                    $_POST['cepCadastroMed'],
                                    $_POST['endCadastroMed'],
                                    $_POST['telCadastroMed'],
                                    $_POST['emailCadastroMed'],
                                    $_POST['especCadastroMed'],
                                    $_POST['crmCadastroMed'],
                                    $_POST['senhaCadastroMed']
                                )
                            );

                            $_SESSION['emailLogado'] = $_POST['emailCadastroMed'];   

                            $statusCadastro = "<b> Confirmado. </b>";
                            $statusSubCadastro = "Alteração realizada!";

                            }
                        }else{
                            $statusCadastro = "<b> Negado. </b>";
                            $statusSubCadastro = "Email indisponivel!";
                            $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                        }
                    }
                }

    //Mostrar dados atuais na tela
    $emailSessao =  $_SESSION['emailLogado'];
    $sqlGetInfo_medAtual = "SELECT * FROM medicos WHERE email = '$emailSessao' ";
    
    $medLogado = $db_connec->query($sqlGetInfo_medAtual);
    
    $medLogadoInfo = $medLogado->fetch(PDO::FETCH_ASSOC);

    $nomeMed = test_input($medLogadoInfo['nome']);
    $cidadeMed = test_input($medLogadoInfo['cidade']);
    $estadoMed = test_input($medLogadoInfo['estado']);
    $cepMed = test_input($medLogadoInfo['cep']);
    $endeercoMed = test_input($medLogadoInfo['endereco']);
    $telefoneMed = test_input($medLogadoInfo['telefone']);
    $emailMed = test_input($medLogadoInfo['email']);
    $especialidadeMed = test_input($medLogadoInfo['especialidade']);
    $crmMed = test_input($medLogadoInfo['crm']);
    $senhaMed = test_input($medLogadoInfo['senha']);

    */

    echo "<br> <br> Perfil Laboratorio: <br>";

    /*

    $emailLab_tempLogado = $_SESSION['emailLogado'];
    $sqlFind_lab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLab_tempLogado' ";
    if($result = $db_connec->query($sqlFind_lab)){
        if($result->fetchColumn() > 0){

            //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
            $emailForm = $_POST['emailCadastroLab'];
            $sqlCheckEmail_med = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailForm'";

            if($result_temp = $db_connec->query($sqlCheckEmail_med)){
                if($result_temp->fetchColumn() > 0 && $_SESSION['emailLogado'] != $_POST['emailCadastroLab'] ) {
                    $jaCadastrado = true;
                }
            }
            if(!$jaCadastrado){

                $resultC = $db_connec->query("SELECT * FROM laboratorios WHERE email = '$emailLab_tempLogado' ");
                $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                $cnpjTeste = $rows['cnpj'];
                
                $sqlUpdate_lab = "UPDATE laboratorios SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?, email=?, tipoExame=?, cnpj=?, senha=? WHERE email = '$emailLab_tempLogado' ";

                $cnpjLab_temp = $_POST['cnpjCadastroLab']; 
                $sqlCheck3 = "SELECT cnpj FROM laboratorios WHERE cnpj = '$cnpjLab_temp' ";
                $result3 = $db_connec->query($sqlCheck3);

                if($result3->fetchColumn() > 0 && $cnpjTeste != $_POST['cnpjCadastroLab']){
                    $statusCadastro = " <b> Negado. </b>";
                    $statusSubCadastro = "CNPJ do Laboartório <b> " . $emailLab .  " </b> já cadastrado!";
                }else{
                $stmt = $db_connec->prepare($sqlUpdate_lab);
                $stmt->execute(
                    array
                    (
                        $_POST['nomeCadastroLab'],
                        $_POST['cidCadastroLab'],
                        $_POST['estCadastroLab'],
                        $_POST['cepCadastroLab'],
                        $_POST['endCadastroLab'],
                        $_POST['telCadastroLab'],
                        $_POST['emailCadastroLab'],
                        $_POST['tipoExameCadastroLab'],
                        $_POST['cnpjCadastroLab'],
                        $_POST['senhaCadastroLab']
                    )
                );

                $_SESSION['emailLogado'] = $_POST['emailCadastroLab'];   

                $statusCadastro = "<b> Confirmado. </b>";
                $statusSubCadastro = "Alteração realizada!";

                }
            }else{
                $statusCadastro = "<b> Negado. </b>";
                $statusSubCadastro = "Email indisponivel!";
                $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
            }
        }
    }

    //Mostrar dados atuais na tela
    $emailSessao =  $_SESSION['emailLogado'];
    $sqlGetInfo_labAtual = "SELECT * FROM laboratorios WHERE email = '$emailSessao' ";

    $labLogado = $db_connec->query($sqlGetInfo_labAtual);

    $labLogadoInfo = $labLogado->fetch(PDO::FETCH_ASSOC);

    $nomeLab = test_input($labLogadoInfo['nome']);
    $cidadeLab = test_input($labLogadoInfo['cidade']);
    $estadoLab = test_input($labLogadoInfo['estado']);
    $cepLab = test_input($labLogadoInfo['cep']);
    $endeercoLab = test_input($labLogadoInfo['endereco']);
    $telefoneLab = test_input($labLogadoInfo['telefone']);
    $emailLab = test_input($labLogadoInfo['email']);
    $tipoExameLab = test_input($labLogadoInfo['tipoExame']);
    $cnpjLab = test_input($labLogadoInfo['cnpj']);
    $senhaLab = test_input($labLogadoInfo['senha']);


    */

    echo "<br> <br> Perfil Paciente: <br>";

    /* 
    $emailPac_tempLogado = $_SESSION['emailLogado'];
    $sqlFind_pac = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailPac_tempLogado' ";
    if($result = $db_connec->query($sqlFind_pac)){
        if($result->fetchColumn() > 0){
                        //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
                        $emailForm = $_POST['emailCadastroPac'];
                        $sqlCheckEmail_pac = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailForm'";
            
                        if($result_temp = $db_connec->query($sqlCheckEmail_pac)){
                            if($result_temp->fetchColumn() > 0 && $_SESSION['emailLogado'] != $_POST['emailCadastroPac'] ) {
                                $jaCadastrado = true;
                            }
                        }
                        if(!$jaCadastrado){
            
                            $resultC = $db_connec->query("SELECT * FROM pacientes WHERE email = '$emailPac_tempLogado' ");
                            $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                            $cpfTeste = $rows['cpf'];
                            
                            $sqlUpdate_pac = "UPDATE pacientes SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?, email=?, genero=?, idade=?, cpf=?, senha=? WHERE email = '$emailPac_tempLogado' ";
            
                            $cpfPac_temp = $_POST['cpfCadastroPac']; 
                            $sqlCheck3 = "SELECT cpf FROM pacientes WHERE cpf = '$cpfPac_temp' ";
                            $result3 = $db_connec->query($sqlCheck3);
            
                            if($result3->fetchColumn() > 0 && $cpfTeste != $_POST['cpfCadastroPac']){
                                $statusCadastro = " <b> Negado. </b>";
                                $statusSubCadastro = "CPF do Paciente <b> " . $emailPac .  " </b> já cadastrado!";
                            }else{
                            $stmt = $db_connec->prepare($sqlUpdate_pac);
                            $stmt->execute(
                                array
                                (
                                    $_POST['nomeCadastroPac'],
                                    $_POST['cidCadastroPac'],
                                    $_POST['estCadastroPac'],
                                    $_POST['cepCadastroPac'],
                                    $_POST['endCadastroPac'],
                                    $_POST['telCadastroPac'],
                                    $_POST['emailCadastroPac'],
                                    $_POST['genCadastroPac'],
                                    $_POST['idadeCadastroPac'],
                                    $_POST['cpfCadastroPac'],
                                    $_POST['senhaCadastroPac']
                                )
                            );
            
                            $_SESSION['emailLogado'] = $_POST['emailCadastroPac'];   
            
                            $statusCadastro = "<b> Confirmado. </b>";
                            $statusSubCadastro = "Alteração realizada!";
            
                            }
                        }else{
                            $statusCadastro = "<b> Negado. </b>";
                            $statusSubCadastro = "Email indisponivel!";
                            $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
                        }
                }        
        }

    //Mostrar dados atuais na tela
    $emailSessao =  $_SESSION['emailLogado'];
    $sqlGetInfo_pacAtual = "SELECT * FROM pacientes WHERE email = '$emailSessao' ";

    $pacLogado = $db_connec->query($sqlGetInfo_pacAtual);

    $pacLogadoInfo = $pacLogado->fetch(PDO::FETCH_ASSOC);

    $nomePac = test_input($pacLogadoInfo['nome']);
    $cidadePac = test_input($pacLogadoInfo['cidade']);
    $estadoPac = test_input($pacLogadoInfo['estado']);
    $cepPac = test_input($pacLogadoInfo['cep']);
    $endeercoPac = test_input($pacLogadoInfo['endereco']);
    $telefonePac = test_input($pacLogadoInfo['telefone']);
    $emailPac = test_input($pacLogadoInfo['email']);
    $generoPac = test_input($pacLogadoInfo['genero']);
    $idadePac = test_input($pacLogadoInfo['idade']);
    $cpfPac = test_input($pacLogadoInfo['cpf']);
    $senhaPac = test_input($pacLogadoInfo['senha']);

    */


    echo "<br> <br> Alteração de Cadastros <br> <br>";
    echo "Administrador <br>";


        $sqlGet_ = "SELECT * FROM administradores";
        $result_get = $db_connec->query($sqlGet_);

        $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $column){

            $emailAdm = $column['email'];
            $senhaAdm = $column['senha'];
            echo "$emailAdm " . " $senhaAdm <br>";
        }

    echo "<br> Medicos <br>";

        $sqlGet_ = "SELECT * FROM medicos";
        $result_get = $db_connec->query($sqlGet_);

        $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $column){

            $nomeMed = $column['nome'];
            $cidadeMed = $column['cidade'];
            $estadoMed = $column['estado'];
            $cepMed = $column['cep'];
            $enderecoMed = $column['endereco'];
            $telefoneMed = $column['telefone'];
            $emailMed = $column['email'];
            $especialidadeMed = $column['especialidade'];
            $crmMed = $column['crm'];
            $senhaMed = $column['senha'];

            echo "$nomeMed " . " $emailMed $senhaMed <br>" ;
        }


    echo "<br> Laboratorios <br>";

    $sqlGet_ = "SELECT * FROM laboratorios";
    $result_get = $db_connec->query($sqlGet_);

    $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $column){

        $nomeLab = $column['nome'];
        $cidadeLab = $column['cidade'];
        $estadoLab = $column['estado'];
        $cepLab = $column['cep'];
        $enderecoLab = $column['endereco'];
        $telefoneLab = $column['telefone'];
        $emailLab = $column['email'];
        $tipoExameLab = $column['tipoExame'];
        $cnpjLab = $column['cnpj'];
        $senhaLab = $column['senha'];

        echo "$nomeLab " . " $emailLab $senhaLab <br>" ;
    }

    echo "<br> Pacientes <br>";

    $sqlGet_ = "SELECT * FROM pacientes";
    $result_get = $db_connec->query($sqlGet_);

    $rows = $result_get->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $column){

        $nomePac = $column['nome'];
        $cidadePac = $column['cidade'];
        $estadoPac = $column['estado'];
        $cepPac = $column['cep'];
        $enderecoPac = $column['endereco'];
        $telefonePac = $column['telefone'];
        $emailPac = $column['email'];
        $generoPac = $column['genero'];
        $idadePac = $column['idade'];
        $cpfPac = $column['cpf'];
        $senhaPac = $column['senha'];

        echo "$nomePac " . " $emailPac $senhaPac <br>" ;
    }

    // Segunda Parte
    //ADM 



    $emailForm = $vetorAdministradores[$_POST['indiceDados']]->email;
    $sql_SetFormInfo = "SELECT * FROM administradores WHERE email = '$emailForm' ";
    if($result = $db_connec->query($sql_SetFormInfo)){
        if($result->fetchColumn() > 0){

        }
    }


    //Med

    $emailForm = $vetorMedicos[$_POST['indiceDados']]->email;
    $sql_SetFormInfo = "SELECT * FROM medicos WHERE email = '$emailForm' ";
    if($result = $db_connec->query($sql_SetFormInfo)){
        if($result->fetchColumn() > 0){

        }
    }


    //Lab 

    
    $emailForm = $vetorLaboratorios[$_POST['indiceDados']]->email;
    $sql_SetFormInfo = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailForm' ";
    if($result = $db_connec->query($sql_SetFormInfo)){
        if($result->fetchColumn() > 0){
            

        }
    }

    //Pac

        
    $emailForm = $vetorPacientes[$_POST['indiceDados']]->email;
    $sql_SetFormInfo = "SELECT * FROM pacientes WHERE email = '$emailForm' ";
    if($result = $db_connec->query($sql_SetFormInfo)){
        if($result->fetchColumn() > 0){

        }
    }

    //Atualizar Cadastros
    //ADM

    $emailSelected = $vetorAdministradores[$_SESSION['indiceDados']]->email;
    $sqlFind_adm = "SELECT COUNT(*) FROM administradores WHERE email = '$emailSelected' ";
    if($result = $db_connec->query($sqlFind_adm)){
        if($result->fetchColumn() > 0){
            //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
            $emailForm = $_POST['emailCadastroAdm'];
            $sqlCheckEmail_adm = "SELECT COUNT(*) FROM administradores WHERE email = '$emailForm'";

            if($result_temp = $db_connec->query($sqlCheckEmail_adm)){
                if($result_temp->fetchColumn() > 0 && $emailSelected != $_POST['emailCadastroAdm'] ) {
                    $jaCadastrado = true;
                    $statusSubCadastro = "Email não disponível";
                }
            }
            if(!$jaCadastrado){
                $sqlUpdate_adm = "UPDATE administradores SET email=?, senha=? WHERE email = '$emailSelected' ";
                $stmt = $db_connec->prepare($sqlUpdate_adm);
                $stmt->execute(
                    array
                    (
                        $_POST['emailCadastroAdm'],
                        $_POST['senhaCadastroAdm']
                    )
                );
                $statusSubCadastro = "Administrador Alterado";
            }else{
                $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
            }
        }
    }

    //Med

    $emailSelected_Med = $vetorMedicos[$_SESSION['indiceDados']]->email;
    $sqlFind_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailSelected_Med' ";
    if($result = $db_connec->query($sqlFind_med)){
        if($result->fetchColumn() > 0){

            //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
            $emailForm = $_POST['emailCadastroMed'];
            $sqlCheckEmail_med = "SELECT COUNT(*) FROM medicos WHERE email = '$emailForm'";

            if($result_temp = $db_connec->query($sqlCheckEmail_med)){
                if($result_temp->fetchColumn() > 0 && $emailSelected_Med != $_POST['emailCadastroMed'] ) {
                    $jaCadastrado = true;
                    $statusSubCadastro = "Email não disponível";
                }
            }
            if(!$jaCadastrado){

                $resultC = $db_connec->query("SELECT * FROM medicos WHERE email = '$emailSelected_Med' ");
                $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                $crmTeste = $rows['crm'];

                $sqlUpdate_med = "UPDATE medicos SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?,email=?, especialidade=?, crm=?, senha=? WHERE email = '$emailSelected_Med' ";

                $crmMed_temp = $_POST['crmCadastroMed']; 
                $sqlCheck3 = "SELECT crm FROM medicos WHERE crm = '$crmMed_temp' ";
                $result3 = $db_connec->query($sqlCheck3);

                if($result3->fetchColumn() > 0 && $crmTeste != $_POST['crmCadastroMed']){
                    $statusCadastro = " <b> Negado. </b>";
                    $statusSubCadastro = "CRM do Médico já cadastrado!";
                }else{
                $stmt = $db_connec->prepare($sqlUpdate_med);
                $stmt->execute(
                    array
                    (
                        $_POST['nomeCadastroMed'],
                        $_POST['cidCadastroMed'],
                        $_POST['estCadastroMed'],
                        $_POST['cepCadastroMed'],
                        $_POST['endCadastroMed'],
                        $_POST['telCadastroMed'],
                        $_POST['emailCadastroMed'],
                        $_POST['especCadastroMed'],
                        $_POST['crmCadastroMed'],
                        $_POST['senhaCadastroMed']
                    )
                );

                $statusSubCadastro = "Médico Alterado";

                }
            }else{
                $statusCadastro = "<b> Negado. </b>";
                $statusSubCadastro = "Email indisponivel!";
                $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
            }
        }
    }

    //Lab

    $emailSelected_Lab = $vetorMedicos[$_SESSION['indiceDados']]->email;
    $sqlFind_lab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailSelected_Lab' ";
    if($result = $db_connec->query($sqlFind_lab)){
        if($result->fetchColumn() > 0){

            //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
            $emailForm = $_POST['emailCadastroLab'];
            $sqlCheckEmail_lab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailForm'";

            if($result_temp = $db_connec->query($sqlCheckEmail_lab)){
                if($result_temp->fetchColumn() > 0 && $emailSelected_Lab != $_POST['emailCadastroLab'] ) {
                    $jaCadastrado = true;
                    $statusSubCadastro = "Email não disponível";
                }
            }
            if(!$jaCadastrado){

                $resultC = $db_connec->query("SELECT * FROM laboratorios WHERE email = '$emailSelected_Lab' ");
                $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                $cnpjTeste = $rows['cnpj'];
                
                $sqlUpdate_lab = "UPDATE laboratorios SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?, email=?, tipoExame=?, cnpj=?, senha=? WHERE email = '$emailSelected_Lab' ";

                $cnpjLab_temp = $_POST['cnpjCadastroLab']; 
                $sqlCheck3 = "SELECT cnpj FROM laboratorios WHERE cnpj = '$cnpjLab_temp' ";
                $result3 = $db_connec->query($sqlCheck3);

                if($result3->fetchColumn() > 0 && $cnpjTeste != $_POST['cnpjCadastroLab']){
                    $statusCadastro = " <b> Negado. </b>";
                    $statusSubCadastro = "CNPJ do Laboartório <b> " . $emailLab .  " </b> já cadastrado!";
                }else{
                $stmt = $db_connec->prepare($sqlUpdate_lab);
                $stmt->execute(
                    array
                    (
                        $_POST['nomeCadastroLab'],
                        $_POST['cidCadastroLab'],
                        $_POST['estCadastroLab'],
                        $_POST['cepCadastroLab'],
                        $_POST['endCadastroLab'],
                        $_POST['telCadastroLab'],
                        $_POST['emailCadastroLab'],
                        $_POST['tipoExameCadastroLab'],
                        $_POST['cnpjCadastroLab'],
                        $_POST['senhaCadastroLab']
                    )
                );

                $statusCadastro = "<b> Confirmado. </b>";
                $statusSubCadastro = "Laboratorio Alterado";
                }
            }else{
                $statusCadastro = "<b> Negado. </b>";
                $statusSubCadastro = "Email indisponivel!";
                $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
            }
        }
    }


    //Pac 

    $emailSelected_Pac = $vetorPacientes[$_SESSION['indiceDados']]->email;
    $sqlFind_pac = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailSelected_Pac' ";
    if($result = $db_connec->query($sqlFind_pac))
    {
        if($result->fetchColumn() > 0){
        //Checar se existe outro cadastro com o mesmo email, sem ser o atual logado
        $emailForm = $_POST['emailCadastroPac'];
        $sqlCheckEmail_pac = "SELECT COUNT(*) FROM pacientes WHERE email = '$emailForm'";

            if($result_temp = $db_connec->query($sqlCheckEmail_pac)){
                if($result_temp->fetchColumn() > 0 && $emailSelected_Pac != $_POST['emailCadastroPac'] ) {
                    $jaCadastrado = true;
                    $statusSubCadastro = "Email não disponível";
                }
            }
            if(!$jaCadastrado){

                $resultC = $db_connec->query("SELECT * FROM pacientes WHERE email = '$emailSelected_Pac' ");
                $rows = $resultC->fetch(PDO::FETCH_ASSOC);
                $cpfTeste = $rows['cpf'];
                
                $sqlUpdate_pac = "UPDATE pacientes SET nome=?, cidade=?, estado=?, cep=?, endereco=?, telefone=?, email=?, genero=?, idade=?, cpf=?, senha=? WHERE email = '$emailSelected_Pac' ";

                $cpfPac_temp = $_POST['cpfCadastroPac']; 
                $sqlCheck3 = "SELECT cpf FROM pacientes WHERE cpf = '$cpfPac_temp' ";
                $result3 = $db_connec->query($sqlCheck3);

                if($result3->fetchColumn() > 0 && $cpfTeste != $_POST['cpfCadastroPac']){
                    $statusCadastro = " <b> Negado. </b>";
                    $statusSubCadastro = "CPF do Paciente já cadastrado!";
                }else{
                $stmt = $db_connec->prepare($sqlUpdate_pac);
                $stmt->execute(
                    array
                    (
                        $_POST['nomeCadastroPac'],
                        $_POST['cidCadastroPac'],
                        $_POST['estCadastroPac'],
                        $_POST['cepCadastroPac'],
                        $_POST['endCadastroPac'],
                        $_POST['telCadastroPac'],
                        $_POST['emailCadastroPac'],
                        $_POST['genCadastroPac'],
                        $_POST['idadeCadastroPac'],
                        $_POST['cpfCadastroPac'],
                        $_POST['senhaCadastroPac']
                    )
                );

                $statusCadastro = "<b> Confirmado. </b>";
                $statusSubCadastro = "Alteração realizada!";

                }
            }else{
                    $statusCadastro = "<b> Negado. </b>";
                    $statusSubCadastro = "Email indisponivel!";
                    $emailSubTitle = '<small class="text-muted">*Email não está disponivel.</small>';
            }
        }        
    }

    //Cadastrar Consulta 


    //1 Parte
    $emailMedicoLogado = $_SESSION['emailLogado'];    
    $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailMedicoLogado' ";
    
    $result = $db_connec->query($sqlCheck);
    $rows = $result->fetch(PDO::FETCH_ASSOC);
    $crmMedLogado = $rows['crm'];

    //2 Parte

    $sql_SearchMatch ="SELECT COUNT(*) FROM pacientes WHERE email = '$emailPacNew' AND cpf = '$cpfPacNew' ";

    if($result= $db_connec->query($sql_SearchMatch)){
        if($result->fetchColumn() > 0){
            $match = true;
        }
    }
    if($match){
        $sql_CheckMed = "SELECT COUNT(*) FROM medicos WHERE email = '$emailMedNew' AND crm = '$crmMedNew' ";

        if($result = $db_connec->query($sql_CheckMed)){
            if($result->fetchColumn() > 0){

                $sqlCreate_consulta = "INSERT INTO consultas(emailMed, crmMed, emailPac, cpfPac, motivoConsulta, dataConsulta, obsConsulta, receitaConsulta) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";

                $statement = $db_connec->prepare($sqlCreate_consulta);
                $statement->execute(
                    array
                    (
                        $emailMedNew,
                        $crmMedNew,
                        $emailPacNew, 
                        $cpfPacNew,
                        $motivoConsultaNew,
                        $dataConsultaNew,
                        $obsConsultaNew, 
                        $receitaConsultaNew
                    )
                );

                $statusSubCadastro = "Consulta adicionada!";

            }else{
                $statusSubCadastro = "Dados do Médico incorretos";
            }
        }
    }else{
        $statusSubCadastro = "Dados do Paciente incorretos";
    }

    echo "RESULTA";

    //Parte 3 - Pegar consultas do BD

    $sqlGet_consulta = "SELECT * FROM laboratorios";
    
    $result = $db_connec->query($sqlGet_consulta);
    $rows = $result->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $consulta) {
        $emailMedResponsavel = test_input($consulta['emailMed']); 
        $crmMedResponsavel = test_input($consulta['crmMed']);
        $emailPaciente = test_input($consulta['emailPac']);
        $cpfPaciente = test_input($consulta['cpfPac']);
        $motivoConsulta = test_input($consulta['motivoConsulta']);
        $dataConsulta = test_input($consulta['dataConsulta']);
        $obsConsulta = test_input($consulta['obsConsulta']);
        $receitaConsulta = test_input($consulta['receitaConsulta']);
    }

    $sqlCheck = "SELECT * FROM pacientes WHERE email = '$emailPaciente' ";
    
    $result = $db_connec->query($sqlCheck);
    $rows = $result->fetch(PDO::FETCH_ASSOC);
    $nomePacienteCard = $rows['nome'];



    // Exames 
    //Parte 1 -


    $emailLabLogado = $_SESSION['emailLogado'];    
    $sqlChecka = "SELECT * FROM laboratorios WHERE email = '$emailLabLogado' ";
    
    $resulta = $db_connec->query($sqlChecka);
    $rowsa = $resulta->fetch(PDO::FETCH_ASSOC);
    $cnpjLabLogado = $rowsa['cnpj'];


    //Parte 2

    $sql_SearchMatch ="SELECT COUNT(*) FROM pacientes WHERE email = '$emailPacNew' AND cpf = '$cpfPacNew' ";

    if($result= $db_connec->query($sql_SearchMatch)){
        if($result->fetchColumn() > 0){
            $match = true;
        }
    }

    if($match){
        $sql_CheckLab = "SELECT COUNT(*) FROM laboratorios WHERE email = '$emailLabNew' AND crm = '$cnpjLabNew' ";

        if($result = $db_connec->query($sql_CheckLab)){
            if($result->fetchColumn() > 0){

                $sqlCreate_exame = "INSERT INTO exames(emailLab, cnpjLab, emailPac, cpfPac, motivoExame, dataExame, obsExame, receitaExame) VALUES (?, ?, ?, ?, ?, ?, ?, ?);";

                $statement = $db_connec->prepare($sqlCreate_exame);
                $statement->execute(
                    array
                    (
                        $emailLabNew,
                        $cnpjLabNew,
                        $emailPacNew, 
                        $cpfPacNew,
                        $motivoExameNew,
                        $dataExameNew,
                        $obsExameNew, 
                        $receitaExameNew
                    )
                );
                $statusSubCadastro = "Exame adicionado!";

            }else{
                $statusSubCadastro = "Dados do Laboratório incorretos";
            }
        }
    }else{
        $statusSubCadastro = "Dados do Paciente incorretos";
    }


    //Parte 3


    $sqlGet_exames = "SELECT * FROM exames";
    
    $result = $db_connec->query($sqlGet_exames);
    $rows = $result->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $exame) {
        $emailLabResponsavel = test_input($exame['emailLab']); 
        $cnpjLabResponsavel = test_input($exame['cnpjLab']);
        $emailPaciente = test_input($exame['emailPac']);
        $cpfPaciente = test_input($exame['cpfPac']);
        $motivoExame = test_input($exame['motivoExame']);
        $dataExame = test_input($exame['dataExame']);
        $obsExame = test_input($exame['obsExame']);
        $receitaExame = test_input($exame['receitaExame']);
    }

    $sqlCheck = "SELECT * FROM pacientes WHERE email = '$emailPaciente' ";
    
    $result = $db_connec->query($sqlCheck);
    $rows = $result->fetch(PDO::FETCH_ASSOC);
    $nomePacienteCard = $rows['nome'];




    //PAC 

    //Parte 1
    $emailPacLogado = $_SESSION['emailLogado'];    
    $sqlChecka = "SELECT * FROM pacientes WHERE email = '$emailPacLogado' ";
    
    $resulta = $db_connec->query($sqlChecka);
    $rowsa = $resulta->fetch(PDO::FETCH_ASSOC);
    $cpfPacLogado = $rowsa['cpf'];

    //Parte 2 - Exame

    $sqlGet_exames = "SELECT * FROM exames";
    
    $result = $db_connec->query($sqlGet_exames);
    $rows = $result->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $exame) {
    $emailLabResponsavel = test_input($exame['emailLab']); 
            $cnpjLabResponsavel = test_input($exame['cnpjLab']);
            $emailPaciente = test_input($exame['emailPac']);
            $cpfPaciente = test_input($exame['cpfPac']);
            $motivoExame = test_input($exame['motivoExame']);
            $dataExame = test_input($exame['dataExame']);
            $obsExame = test_input($exame['obsExame']);
            $resultadoExame = test_input($exame['resultadoExame']);
            

    }

    
    $sqlCheck = "SELECT * FROM laboratorios WHERE email = '$emailLabResponsavel' ";
    
    $result = $db_connec->query($sqlCheck);
    $rows = $result->fetch(PDO::FETCH_ASSOC);
    $nomeLabCard = $rows['nome'];


    //Parte 3 - Consulta


    $sqlGet_consulta = "SELECT * FROM consultas";
    
    $result = $db_connec->query($sqlGet_consulta);
    $rows = $result->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $consulta) {
        $emailMedResponsavel = test_input($consulta['emailMed']); 
        $crmMedResponsavel = test_input($consulta['crmMed']);
        $emailPaciente = test_input($consulta['emailPac']);
        $cpfPaciente = test_input($consulta['cpfPac']);
        $motivoConsulta = test_input($consulta['motivoConsulta']);
        $dataConsulta = test_input($consulta['dataConsulta']);
        $obsConsulta = test_input($consulta['obsConsulta']);
        $receitaConsulta = test_input($consulta['receitaConsulta']);
    }

        
    $sqlCheck = "SELECT * FROM medicos WHERE email = '$emailMedResponsavel' ";
    
    $result = $db_connec->query($sqlCheck);
    $rows = $result->fetch(PDO::FETCH_ASSOC);
    $nomeMedCard = $rows['nome'];
    
    ?>



</body>

</html>